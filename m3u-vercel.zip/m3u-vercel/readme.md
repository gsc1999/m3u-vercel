# Vercel पर M3U लिंक डेप्लॉय करें

1. Vercel पर नया प्रोजेक्ट बनाएँ।
2. ENV वेरिएबल्स सेट करें:
   - `IPTV_USER` = your_username
   - `IPTV_PASS` = your_password
3. ZIP फ़ाइल अपलोड करें और डेप्लॉय करें।
4. अपना M3U लिंक यूज़ करें:  
   `https://your-project.vercel.app/api/iptv`