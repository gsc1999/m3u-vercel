export default async function handler(req, res) {
  try {
    // ENV Variables से यूजरनेम/पासवर्ड लें
    const user = process.env.IPTV_USER;
    const pass = process.env.IPTV_PASS;
    
    const sourceUrl = `http://astv.life:8080/get.php?username=${user}&password=${pass}&type=m3u_plus`;
    const response = await fetch(sourceUrl);
    const data = await response.text();

    res.setHeader("Content-Type", "application/vnd.apple.mpegurl");
    res.status(200).send(data);
  } catch (error) {
    res.status(500).send("Error: " + error.message);
  }
}