export default async function handler(req, res) {
  try {
    // Dropbox का Direct M3U लिंक
    const dropboxUrl = "https://www.dropbox.com/scl/fi/mevqzk7x0jh8atysryxj0/playlist.m3u.m3u?rlkey=4urxztml936ohds5xvij7a812&st=nrhlr1hj&dl=1";

    // Dropbox से डेटा फ़ेच करें
    const response = await fetch(dropboxUrl);
    const data = await response.text();

    // हेडर सेट करें
    res.setHeader("Content-Type", "application/vnd.apple.mpegurl");
    res.send(data);
  } catch (error) {
    res.status(500).send("Error: " + error.message);
  }
}