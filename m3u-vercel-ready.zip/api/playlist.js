export default function handler(req, res) {
  res.setHeader("Content-Type", "application/x-mpegURL");
  res.status(200).send(`#EXTM3U
#EXTM3U
#EXTINF:-1 tvg-id="humtv.pk" tvg-name="PK | HUM TV HD" tvg-logo="https://www.lyngsat.com/logo/tv/hh/hum_tv_pk.png" group-title="PAKISTAN ➾ DRAMA",PK | HUM TV HD
http://ip96.uk:8080/shakeelmirza/4110440/110034
#EXTINF:-1 tvg-id="arydigital.pk" tvg-name="PK | ARY DIGITAL HD" tvg-logo="https://www.lyngsat.com/logo/tv/aa/ary_digital_asia.png" group-title="PAKISTAN ➾ DRAMA",PK | ARY DIGITAL HD
http://ip96.uk:8080/shakeelmirza/4110440/110038
#EXTINF:-1 tvg-id="geotv.pk" tvg-name="PK | GEO ENTERTAINMENT HD" tvg-logo="https://www.lyngsat.com/logo/tv/gg/geo_tv_me.png" group-title="PAKISTAN ➾ DRAMA",PK | GEO ENTERTAINMENT HD
http://ip96.uk:8080/shakeelmirza/4110440/110041
#EXTINF:-1 tvg-id="Bol Entertainment.pk" tvg-name="PK | BOL ENTERTAINMENT HD" tvg-logo="https://www.lyngsat.com/logo/tv/bb/bol-entertainment-pk.png" group-title="PAKISTAN ➾ DRAMA",PK | BOL ENTERTAINMENT HD
http://ip96.uk:8080/shakeelmirza/4110440/110044
#EXTINF:-1 tvg-id="" tvg-name="PK | EXPRESS ENTERTAINMENT HD" tvg-logo="https://www.lyngsat.com/logo/tv/ee/express_entertainment_pk.png" group-title="PAKISTAN ➾ DRAMA",PK | EXPRESS ENTERTAINMENT HD
http://ip96.uk:8080/shakeelmirza/4110440/110047
#EXTINF:-1 tvg-id="" tvg-name="PK | ARY ZINDAGI" tvg-logo="https://www.lyngsat.com/logo/tv/aa/ary_zindagi_pk.png" group-title="PAKISTAN ➾ DRAMA",PK | ARY ZINDAGI
http://ip96.uk:8080/shakeelmirza/4110440/110049
#EXTINF:-1 tvg-id="" tvg-name="PK | GEO KAHANI" tvg-logo="https://www.lyngsat.com/logo/tv/gg/geo_kahani_pk.png" group-title="PAKISTAN ➾ DRAMA",PK | GEO KAHANI
http://ip96.uk:8080/shakeelmirza/4110440/110052
#EXTINF:-1 tvg-id="" tvg-name="PK | AAJ ENTERTAINMENT" tvg-logo="https://www.lyngsat.com/logo/tv/aa/aaj_entertainment_pk.png" group-title="PAKISTAN ➾ DRAMA",PK | AAJ ENTERTAINMENT
http://ip96.uk:8080/shakeelmirza/4110440/110055
#EXTINF:-1 tvg-id="" tvg-name="PK | HUM SITARY" tvg-logo="https://www.lyngsat.com/logo/tv/hh/hum-sitaray-pk.png" group-title="PAKISTAN ➾ DRAMA",PK | HUM SITARY
http://ip96.uk:8080/shakeelmirza/4110440/110058
#EXTINF:-1 tvg-id="" tvg-name="PK | A PLUS HD" tvg-logo="https://www.lyngsat.com/logo/tv/aa/a-plus-pk.png" group-title="PAKISTAN ➾ DRAMA",PK | A PLUS HD
http://ip96.uk:8080/shakeelmirza/4110440/110062
#EXTINF:-1 tvg-id="" tvg-name="PK | ATV HD" tvg-logo="https://www.lyngsat.com/logo/tv/aa/atv-pk.png" group-title="PAKISTAN ➾ DRAMA",PK | ATV HD
http://ip96.uk:8080/shakeelmirza/4110440/110065
#EXTINF:-1 tvg-id="" tvg-name="PK | PTV HOME " tvg-logo="https://www.lyngsat.com/logo/tv/pp/ptv-home-pk.png" group-title="PAKISTAN ➾ DRAMA",PK | PTV HOME 
http://ip96.uk:8080/shakeelmirza/4110440/110067
#EXTINF:-1 tvg-id="" tvg-name="PK | PLAY TV" tvg-logo="https://www.lyngsat.com/logo/tv/pp/play-entertainment-pk.png" group-title="PAKISTAN ➾ DRAMA",PK | PLAY TV
http://ip96.uk:8080/shakeelmirza/4110440/110068
#EXTINF:-1 tvg-id="" tvg-name="PK | ARY QTV HD" tvg-logo="https://www.lyngsat.com/logo/tv/aa/ary_qtv.png" group-title="PAKISTAN ➾ DRAMA",PK | ARY QTV HD
http://ip96.uk:8080/shakeelmirza/4110440/110071
#EXTINF:-1 tvg-id="" tvg-name="PK | SAB TV HD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/sab-tv-pk.png" group-title="PAKISTAN ➾ DRAMA",PK | SAB TV HD
http://ip96.uk:8080/shakeelmirza/4110440/110075
#EXTINF:-1 tvg-id="" tvg-name="PK | AAN TV HD" tvg-logo="https://www.lyngsat.com/logo/tv/aa/aan-tv-pk.png" group-title="PAKISTAN ➾ DRAMA",PK | AAN TV HD
http://ip96.uk:8080/shakeelmirza/4110440/110076
#EXTINF:-1 tvg-id="" tvg-name="PK | URDU 1 HD " tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRaQZeEyawlNdVjokVYB6X9Yv2XmV7z-tCcgA&usqp=CAU" group-title="PAKISTAN ➾ DRAMA",PK | URDU 1 HD 
http://ip96.uk:8080/shakeelmirza/4110440/110078
#EXTINF:-1 tvg-id="" tvg-name="PK | MUN TV" tvg-logo="https://www.lyngsat.com/logo/tv/mm/mun-tv-pk.png" group-title="PAKISTAN ➾ DRAMA",PK | MUN TV
http://ip96.uk:8080/shakeelmirza/4110440/110079
#EXTINF:-1 tvg-id="" tvg-name="PK | KTN TV" tvg-logo="https://www.lyngsat.com/logo/tv/kk/ktn_tv_pk.png" group-title="PAKISTAN ➾ DRAMA",PK | KTN TV
http://ip96.uk:8080/shakeelmirza/4110440/110081
#EXTINF:-1 tvg-id="" tvg-name="PK | PASHTO 1 TV" tvg-logo="" group-title="PAKISTAN ➾ DRAMA",PK | PASHTO 1 TV
http://ip96.uk:8080/shakeelmirza/4110440/110084
#EXTINF:-1 tvg-id="" tvg-name="PK | SINDH TV" tvg-logo="https://www.lyngsat.com/logo/tv/ss/sindh_tv.png" group-title="PAKISTAN ➾ DRAMA",PK | SINDH TV
http://ip96.uk:8080/shakeelmirza/4110440/110090
#EXTINF:-1 tvg-id="" tvg-name="PK | AUR LIVE" tvg-logo="https://www.lyngsat.com/logo/tv/aa/aur-life-hd-pk.png" group-title="PAKISTAN ➾ DRAMA",PK | AUR LIVE
http://ip96.uk:8080/shakeelmirza/4110440/110091
#EXTINF:-1 tvg-id="" tvg-name="PK | SEE TV HD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/see_tv_pk_hd.png" group-title="PAKISTAN ➾ DRAMA",PK | SEE TV HD
http://ip96.uk:8080/shakeelmirza/4110440/110093
#EXTINF:-1 tvg-id="" tvg-name="PK | GREEN TV" tvg-logo="https://www.lyngsat.com/logo/tv/gg/green-entertainment-pk.png" group-title="PAKISTAN ➾ DRAMA",PK | GREEN TV
http://ip96.uk:8080/shakeelmirza/4110440/110094
#EXTINF:-1 tvg-id="" tvg-name="PK |  WASEB TV" tvg-logo="https://www.lyngsat.com/logo/tv/ww/waseb_tv.png" group-title="PAKISTAN ➾ DRAMA",PK |  WASEB TV
http://ip96.uk:8080/shakeelmirza/4110440/110095
#EXTINF:-1 tvg-id="" tvg-name="PK | FILMAX" tvg-logo="https://www.lyngsat.com/logo/tv/ff/filmax_pk.png" group-title="PAKISTAN ➾ DRAMA",PK | FILMAX
http://ip96.uk:8080/shakeelmirza/4110440/110100
#EXTINF:-1 tvg-id="" tvg-name="PK | ARUJ" tvg-logo="" group-title="PAKISTAN ➾ DRAMA",PK | ARUJ
http://ip96.uk:8080/shakeelmirza/4110440/110102
#EXTINF:-1 tvg-id="" tvg-name="PK | LTN FAMILY" tvg-logo="" group-title="PAKISTAN ➾ DRAMA",PK | LTN FAMILY
http://ip96.uk:8080/shakeelmirza/4110440/110103
#EXTINF:-1 tvg-id="" tvg-name="PK | FILMAZIA" tvg-logo="https://www.lyngsat.com/logo/tv/ff/filmazia_pk.png" group-title="PAKISTAN ➾ DRAMA",PK | FILMAZIA
http://ip96.uk:8080/shakeelmirza/4110440/110107
#EXTINF:-1 tvg-id="" tvg-name="PK | FILM WORLD" tvg-logo="https://www.lyngsat.com/logo/tv/ff/film-world-pk.png" group-title="PAKISTAN ➾ DRAMA",PK | FILM WORLD
http://ip96.uk:8080/shakeelmirza/4110440/110114
#EXTINF:-1 tvg-id="" tvg-name="PK | KHYBER TV" tvg-logo="https://www.lyngsat.com/logo/tv/kk/khyber-middle-east-tv-pk.png" group-title="PAKISTAN ➾ DRAMA",PK | KHYBER TV
http://ip96.uk:8080/shakeelmirza/4110440/189484
#EXTINF:-1 tvg-id="" tvg-name="PK | INPLUS" tvg-logo="" group-title="PAKISTAN ➾ DRAMA",PK | INPLUS
http://ip96.uk:8080/shakeelmirza/4110440/190764
#EXTINF:-1 tvg-id="" tvg-name="PK | APNA TV" tvg-logo="" group-title="PAKISTAN ➾ DRAMA",PK | APNA TV
http://ip96.uk:8080/shakeelmirza/4110440/190765
#EXTINF:-1 tvg-id="" tvg-name="PK | A 1 TV" tvg-logo="" group-title="PAKISTAN ➾ DRAMA",PK | A 1 TV
http://ip96.uk:8080/shakeelmirza/4110440/190766
#EXTINF:-1 tvg-id="" tvg-name="PK | KAY 2" tvg-logo="" group-title="PAKISTAN ➾ DRAMA",PK | KAY 2
http://ip96.uk:8080/shakeelmirza/4110440/453389
#EXTINF:-1 tvg-id="" tvg-name="PK | TV ONE" tvg-logo="" group-title="PAKISTAN ➾ DRAMA",PK | TV ONE
http://ip96.uk:8080/shakeelmirza/4110440/456660
#EXTINF:-1 tvg-id="" tvg-name="PK | HUM EUROPE HD" tvg-logo="" group-title="PAKISTAN ➾ DRAMA",PK | HUM EUROPE HD
http://ip96.uk:8080/shakeelmirza/4110440/480443
#EXTINF:-1 tvg-id="" tvg-name="DK: V Sport Golf" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/845f246ff9105ba49eec3b6d1c00c427.png" group-title="GOLF➾SPORTS",DK: V Sport Golf
http://ip96.uk:8080/shakeelmirza/4110440/333168
#EXTINF:-1 tvg-id="" tvg-name="SE: V Sport Golf" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/0de9b5c2e3ed2fc0346a675d5bfde849.png" group-title="GOLF➾SPORTS",SE: V Sport Golf
http://ip96.uk:8080/shakeelmirza/4110440/333100
#EXTINF:-1 tvg-id="" tvg-name="CZ: Golf Channel" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/5aa846ad8e3b339954183db98908c80a.png" group-title="GOLF➾SPORTS",CZ: Golf Channel
http://ip96.uk:8080/shakeelmirza/4110440/332957
#EXTINF:-1 tvg-id="" tvg-name="NL: Ziggo Sport Golf" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/afe050374551a2767019f331cf74dc05.png" group-title="GOLF➾SPORTS",NL: Ziggo Sport Golf
http://ip96.uk:8080/shakeelmirza/4110440/303691
#EXTINF:-1 tvg-id="" tvg-name="PL: Golf Channel" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/5901f5d9b6bb1640c6e7e8a1b44e138e.png" group-title="GOLF➾SPORTS",PL: Golf Channel
http://ip96.uk:8080/shakeelmirza/4110440/316237
#EXTINF:-1 tvg-id="" tvg-name="LA: Golf Channel" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/2f7cf34df9b0ceec221e79a887171cf9.png" group-title="GOLF➾SPORTS",LA: Golf Channel
http://ip96.uk:8080/shakeelmirza/4110440/303346
#EXTINF:-1 tvg-id="" tvg-name="EX-YU: Sport Klub Golf" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/913be3dd5506bb664db6b276ae3131be.png" group-title="GOLF➾SPORTS",EX-YU: Sport Klub Golf
http://ip96.uk:8080/shakeelmirza/4110440/303042
#EXTINF:-1 tvg-id="" tvg-name="FR: GOLF+" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/3d5b56071d971d8a599b10a1899d5d3a.png" group-title="GOLF➾SPORTS",FR: GOLF+
http://ip96.uk:8080/shakeelmirza/4110440/301901
#EXTINF:-1 tvg-id="" tvg-name="FR: Golf Channel" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/004c3db0072c16475396c8bc5757637e.png" group-title="GOLF➾SPORTS",FR: Golf Channel
http://ip96.uk:8080/shakeelmirza/4110440/301900
#EXTINF:-1 tvg-id="" tvg-name="DE: Sky Sport Golf" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/4563870d73aeb6a4e7dc80094393537e.png" group-title="GOLF➾SPORTS",DE: Sky Sport Golf
http://ip96.uk:8080/shakeelmirza/4110440/293494
#EXTINF:-1 tvg-id="" tvg-name="NL | ZIGGO SPORT  GOLF" tvg-logo="https://i.imgur.com/VJy6Mjs.png" group-title="GOLF➾SPORTS",NL | ZIGGO SPORT  GOLF
http://ip96.uk:8080/shakeelmirza/4110440/187438
#EXTINF:-1 tvg-id="" tvg-name="UK: Sky Sports Golf" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/5acb0ff26afa4f347663d42261af36bf.png" group-title="GOLF➾SPORTS",UK: Sky Sports Golf
http://ip96.uk:8080/shakeelmirza/4110440/290420
#EXTINF:-1 tvg-id="" tvg-name="ZA: SuperSport Golf" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/a20c92d13ce602ec324ff03b209ed0c2.png" group-title="GOLF➾SPORTS",ZA: SuperSport Golf
http://ip96.uk:8080/shakeelmirza/4110440/290338
#EXTINF:-1 tvg-id="" tvg-name="US: Golf Kingdom" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="GOLF➾SPORTS",US: Golf Kingdom
http://ip96.uk:8080/shakeelmirza/4110440/291057
#EXTINF:-1 tvg-id="" tvg-name="IT: Sky Sport Golf" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-01/c261a5ce9a1cba8b6aaea018f04dcf84.png" group-title="GOLF➾SPORTS",IT: Sky Sport Golf
http://ip96.uk:8080/shakeelmirza/4110440/293283
#EXTINF:-1 tvg-id="" tvg-name="US: Golf Channel / NBC Golf" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/5164471a041a09ae2a58dbfc5978f766.png" group-title="GOLF➾SPORTS",US: Golf Channel / NBC Golf
http://ip96.uk:8080/shakeelmirza/4110440/291617
#EXTINF:-1 tvg-id="" tvg-name="NZ | SKY SPORTS CRICKET FHD" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSGblnHUtV4s3-_Xsa4X3AUO3pKnjfoFoZRxA&usqp=CAU" group-title="CRICKET ➾",NZ | SKY SPORTS CRICKET FHD
http://ip96.uk:8080/shakeelmirza/4110440/250199
#EXTINF:-1 tvg-id="" tvg-name="PK | ARY SPORTS HD" tvg-logo="https://www.lyngsat.com/logo/tv/aa/a-sports-pk.png" group-title="CRICKET ➾",PK | ARY SPORTS HD
http://ip96.uk:8080/shakeelmirza/4110440/190767
#EXTINF:-1 tvg-id="" tvg-name="AF | SUPER SPORTS CRICKET " tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/5b9d9ddbf95526d59c2fdd6725253646.png" group-title="CRICKET ➾",AF | SUPER SPORTS CRICKET 
http://ip96.uk:8080/shakeelmirza/4110440/53044
#EXTINF:-1 tvg-id="" tvg-name="IN | 18 SPORTS HD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/sports-18-in.png" group-title="CRICKET ➾",IN | 18 SPORTS HD
http://ip96.uk:8080/shakeelmirza/4110440/52077
#EXTINF:-1 tvg-id="" tvg-name="PK | GEO SUPER HD" tvg-logo="https://www.lyngsat.com/logo/tv/gg/geo_super.png" group-title="CRICKET ➾",PK | GEO SUPER HD
http://ip96.uk:8080/shakeelmirza/4110440/52080
#EXTINF:-1 tvg-id="" tvg-name="IN | SONY TEN 1 HD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/sony-sports-ten-1-in.png" group-title="CRICKET ➾",IN | SONY TEN 1 HD
http://ip96.uk:8080/shakeelmirza/4110440/52083
#EXTINF:-1 tvg-id="" tvg-name="IN | SONY TEN 2 HD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/sony-sports-ten-2-in.png" group-title="CRICKET ➾",IN | SONY TEN 2 HD
http://ip96.uk:8080/shakeelmirza/4110440/52085
#EXTINF:-1 tvg-id="" tvg-name="IN | SONY TEN 3 HD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/sony-sports-ten-3-in.png" group-title="CRICKET ➾",IN | SONY TEN 3 HD
http://ip96.uk:8080/shakeelmirza/4110440/52086
#EXTINF:-1 tvg-id="" tvg-name="IN | STAR SPORTS 1 HD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/star-sports-1-hk-in.png" group-title="CRICKET ➾",IN | STAR SPORTS 1 HD
http://ip96.uk:8080/shakeelmirza/4110440/52094
#EXTINF:-1 tvg-id="" tvg-name="IN | STAR SPORTS 2 HD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/star-sports-2-hk-in.png" group-title="CRICKET ➾",IN | STAR SPORTS 2 HD
http://ip96.uk:8080/shakeelmirza/4110440/52096
#EXTINF:-1 tvg-id="" tvg-name="IN | STAR SPORTS SELECT 1 HD" tvg-logo="https://i.ibb.co/rbgvLYd/Star-Sports-Select-1-X-Vision.png" group-title="CRICKET ➾",IN | STAR SPORTS SELECT 1 HD
http://ip96.uk:8080/shakeelmirza/4110440/52098
#EXTINF:-1 tvg-id="" tvg-name="IN | STAR SPORTS SELECT 2 HD" tvg-logo="https://i.ibb.co/dPP0vQS/Star-Sports-Select-2-X-Vision.png" group-title="CRICKET ➾",IN | STAR SPORTS SELECT 2 HD
http://ip96.uk:8080/shakeelmirza/4110440/52100
#EXTINF:-1 tvg-id="" tvg-name="IN | TEN SPORTS HD" tvg-logo="https://www.lyngsat.com/logo/tv/tt/ten_sports_in_pakistan.png" group-title="CRICKET ➾",IN | TEN SPORTS HD
http://ip96.uk:8080/shakeelmirza/4110440/52106
#EXTINF:-1 tvg-id="" tvg-name="PK | ARY SPORTS SD." tvg-logo="https://www.lyngsat.com/logo/tv/aa/a-sports-pk.png" group-title="CRICKET ➾",PK | ARY SPORTS SD.
http://ip96.uk:8080/shakeelmirza/4110440/62393
#EXTINF:-1 tvg-id="" tvg-name="IN | STAR SPORTS 1 HINDI HD " tvg-logo="" group-title="CRICKET ➾",IN | STAR SPORTS 1 HINDI HD 
http://ip96.uk:8080/shakeelmirza/4110440/90342
#EXTINF:-1 tvg-id="" tvg-name="PK | PTV SPORTS SD" tvg-logo="https://www.lyngsat.com/logo/tv/pp/ptv_sports_pk.png" group-title="CRICKET ➾",PK | PTV SPORTS SD
http://ip96.uk:8080/shakeelmirza/4110440/250211
#EXTINF:-1 tvg-id="" tvg-name="IN | FAST SPORTS " tvg-logo="https://www.lyngsat.com/logo/tv/ff/fast-sports-pk.png" group-title="CRICKET ➾",IN | FAST SPORTS 
http://ip96.uk:8080/shakeelmirza/4110440/277207
#EXTINF:-1 tvg-id="" tvg-name="IN | EURO SPORTS" tvg-logo="https://filex.vip:443/images/_HmHo_P7L3IdYO67j5S70HslD6BC0k2Qu3MvF_Z5NnMpGtOkRH9y6nHeUNQPJ4hBYp97V9EwNXSBxlnUbmxOiw.png" group-title="CRICKET ➾",IN | EURO SPORTS
http://ip96.uk:8080/shakeelmirza/4110440/297577
#EXTINF:-1 tvg-id="" tvg-name="PK | PTV SPORTS HD" tvg-logo="" group-title="CRICKET ➾",PK | PTV SPORTS HD
http://ip96.uk:8080/shakeelmirza/4110440/453434
#EXTINF:-1 tvg-id="" tvg-name="IN | SONY TEN 5 HD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/sony-sports-ten-5-in.png" group-title="CRICKET ➾",IN | SONY TEN 5 HD
http://ip96.uk:8080/shakeelmirza/4110440/453435
#EXTINF:-1 tvg-id="" tvg-name="AU | FOX CRICKET 501" tvg-logo="" group-title="CRICKET ➾",AU | FOX CRICKET 501
http://ip96.uk:8080/shakeelmirza/4110440/247166
#EXTINF:-1 tvg-id="" tvg-name="IN | ASTRO CRICKET" tvg-logo="" group-title="CRICKET ➾",IN | ASTRO CRICKET
http://ip96.uk:8080/shakeelmirza/4110440/451415
#EXTINF:-1 tvg-id="" tvg-name="BD | T SPORTS" tvg-logo="http://filex.tv:8080/images/1adcf489ec18dfcb479c92b2a480425e.png" group-title="CRICKET ➾",BD | T SPORTS
http://ip96.uk:8080/shakeelmirza/4110440/111409
#EXTINF:-1 tvg-id="" tvg-name="IN | WILLOW CRICKET HD" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/b8b56a633aad6900e1565ed87811f342.png" group-title="CRICKET ➾",IN | WILLOW CRICKET HD
http://ip96.uk:8080/shakeelmirza/4110440/52109
#EXTINF:-1 tvg-id="" tvg-name="IN | DD SPORTS" tvg-logo="" group-title="CRICKET ➾",IN | DD SPORTS
http://ip96.uk:8080/shakeelmirza/4110440/479719
#EXTINF:-1 tvg-id="" tvg-name="Fight Network HD" tvg-logo="https://rolextv.asia:443/images/Kanmk96vTt-hjZj_mC4RcPttLMlmeeoOsTOSXqs4fWXm360tfVL4n72DiGcqnmJjqlD8PjQkmsQNK8224v75EalJHpFgXqwnpCu5KE6XCx6pRHU2igaYsgQfCMiPpuhXgxJcEPZFgACF2YF30XqWIvZ9IzaoTmqJV9n2K446tYo.png" group-title="WWE UFC FIGHT 24/7",Fight Network HD
http://ip96.uk:8080/shakeelmirza/4110440/497653
#EXTINF:-1 tvg-id="" tvg-name="FIGHT BOX HD" tvg-logo="https://rolextv.asia:443/images/COkEO-FWL6Un57bQno1oDDZsiBeWCSjxPVZv0hLJ3dRoJ56OCVEV-wls_k7ITDz7yDFD0aKDPytwBEYOSUE3Fg.png" group-title="WWE UFC FIGHT 24/7",FIGHT BOX HD
http://ip96.uk:8080/shakeelmirza/4110440/497654
#EXTINF:-1 tvg-id="" tvg-name=" CRICKET 01" tvg-logo="https://upload.wikimedia.org/wikipedia/en/1/18/2025_IPL_logo.png" group-title="IPL (2025)", CRICKET 01
http://ip96.uk:8080/shakeelmirza/4110440/141872
#EXTINF:-1 tvg-id="" tvg-name="CRICKET 02" tvg-logo="https://upload.wikimedia.org/wikipedia/en/1/18/2025_IPL_logo.png" group-title="IPL (2025)",CRICKET 02
http://ip96.uk:8080/shakeelmirza/4110440/191878
#EXTINF:-1 tvg-id="" tvg-name="CRICKET 03" tvg-logo="https://upload.wikimedia.org/wikipedia/en/1/18/2025_IPL_logo.png" group-title="IPL (2025)",CRICKET 03
http://ip96.uk:8080/shakeelmirza/4110440/178637
#EXTINF:-1 tvg-id="" tvg-name="CRICKET 04" tvg-logo="https://upload.wikimedia.org/wikipedia/en/1/18/2025_IPL_logo.png" group-title="IPL (2025)",CRICKET 04
http://ip96.uk:8080/shakeelmirza/4110440/191879
#EXTINF:-1 tvg-id="" tvg-name="CRICKET 05" tvg-logo="https://upload.wikimedia.org/wikipedia/en/1/18/2025_IPL_logo.png" group-title="IPL (2025)",CRICKET 05
http://ip96.uk:8080/shakeelmirza/4110440/141723
#EXTINF:-1 tvg-id="" tvg-name="CRICKET 06" tvg-logo="https://upload.wikimedia.org/wikipedia/en/1/18/2025_IPL_logo.png" group-title="IPL (2025)",CRICKET 06
http://ip96.uk:8080/shakeelmirza/4110440/191819
#EXTINF:-1 tvg-id="" tvg-name="IN | STAR SPORTS 1 HINDI FHD" tvg-logo="" group-title="CRICKET ➾ VIP",IN | STAR SPORTS 1 HINDI FHD
http://ip96.uk:8080/shakeelmirza/4110440/500837
#EXTINF:-1 tvg-id="" tvg-name="IN | STAR SPORTS 5 FHD" tvg-logo="" group-title="CRICKET ➾ VIP",IN | STAR SPORTS 5 FHD
http://ip96.uk:8080/shakeelmirza/4110440/500838
#EXTINF:-1 tvg-id="" tvg-name="PSL 1" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQULPvHh65CW7OCxnVlzrXZzIAf3bE_AU4Pfg&usqp=CAU" group-title="PSL (2025)",PSL 1
http://ip96.uk:8080/shakeelmirza/4110440/500846
#EXTINF:-1 tvg-id="" tvg-name="PSL 2" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQULPvHh65CW7OCxnVlzrXZzIAf3bE_AU4Pfg&usqp=CAU" group-title="PSL (2025)",PSL 2
http://ip96.uk:8080/shakeelmirza/4110440/500847
#EXTINF:-1 tvg-id="" tvg-name="PSL 3" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQULPvHh65CW7OCxnVlzrXZzIAf3bE_AU4Pfg&usqp=CAU" group-title="PSL (2025)",PSL 3
http://ip96.uk:8080/shakeelmirza/4110440/500848
#EXTINF:-1 tvg-id="" tvg-name="PSL 4" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQULPvHh65CW7OCxnVlzrXZzIAf3bE_AU4Pfg&usqp=CAU" group-title="PSL (2025)",PSL 4
http://ip96.uk:8080/shakeelmirza/4110440/500849
#EXTINF:-1 tvg-id="zeetvhd.in" tvg-name="IN | ZEE TV HD" tvg-logo="https://www.lyngsat.com/logo/tv/zz/zee-tv-in.png" group-title="INDIAN ➾ ENTERTAINMENT",IN | ZEE TV HD
http://ip96.uk:8080/shakeelmirza/4110440/13
#EXTINF:-1 tvg-id="sonyhd.in" tvg-name="IN | SONY SET HD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/set_in.png" group-title="INDIAN ➾ ENTERTAINMENT",IN | SONY SET HD
http://ip96.uk:8080/shakeelmirza/4110440/15
#EXTINF:-1 tvg-id="STAR Plus HD" tvg-name="IN | STAR PLUS HD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/star-plus-hk.png" group-title="INDIAN ➾ ENTERTAINMENT",IN | STAR PLUS HD
http://ip96.uk:8080/shakeelmirza/4110440/17
#EXTINF:-1 tvg-id="Colors HD" tvg-name="IN | COLORS HD" tvg-logo="https://www.lyngsat.com/logo/tv/cc/colors-in.png" group-title="INDIAN ➾ ENTERTAINMENT",IN | COLORS HD
http://ip96.uk:8080/shakeelmirza/4110440/19
#EXTINF:-1 tvg-id="Star Bharat HD" tvg-name="IN | STAR BHARAT HD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/star-bharat-hk-in.png" group-title="INDIAN ➾ ENTERTAINMENT",IN | STAR BHARAT HD
http://ip96.uk:8080/shakeelmirza/4110440/21
#EXTINF:-1 tvg-id="andtvhd.in" tvg-name="IN | & TV HD" tvg-logo="https://www.lyngsat.com/logo/tv/aa/and_tv_in.png" group-title="INDIAN ➾ ENTERTAINMENT",IN | & TV HD
http://ip96.uk:8080/shakeelmirza/4110440/23
#EXTINF:-1 tvg-id="SONY SAB HD" tvg-name="IN| SONY SAB HD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/sony-sab-tv-in.png" group-title="INDIAN ➾ ENTERTAINMENT",IN| SONY SAB HD
http://ip96.uk:8080/shakeelmirza/4110440/25
#EXTINF:-1 tvg-id="stargoldselecthd.in" tvg-name="IN | STAR GOLD SELECT HD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/star_gold_in_select_hd.png" group-title="INDIAN ➾ ENTERTAINMENT",IN | STAR GOLD SELECT HD
http://ip96.uk:8080/shakeelmirza/4110440/28
#EXTINF:-1 tvg-id="stargoldhd.in" tvg-name="IN | STAR GOLD HD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/star-gold-hd-india-in.png" group-title="INDIAN ➾ ENTERTAINMENT",IN | STAR GOLD HD
http://ip96.uk:8080/shakeelmirza/4110440/29
#EXTINF:-1 tvg-id="Star Gold 2 HD" tvg-name="IN | STAR GOLD 2 HD" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/c/cc/Star_Gold_2.svg/1376px-Star_Gold_2.svg.png" group-title="INDIAN ➾ ENTERTAINMENT",IN | STAR GOLD 2 HD
http://ip96.uk:8080/shakeelmirza/4110440/31
#EXTINF:-1 tvg-id="SONY MAX 2" tvg-name="IN | SONY MAX 2 HD" tvg-logo="http://jiotv.catchup.cdn.jio.com/dare_images/images/Sony_MAX2.png" group-title="INDIAN ➾ ENTERTAINMENT",IN | SONY MAX 2 HD
http://ip96.uk:8080/shakeelmirza/4110440/32
#EXTINF:-1 tvg-id="SONY MAX HD" tvg-name="IN | SONY MAX HD" tvg-logo="http://filex.tv:8080/images/93a3eb73578a3d9fc24502ad866b1d7f.png" group-title="INDIAN ➾ ENTERTAINMENT",IN | SONY MAX HD
http://ip96.uk:8080/shakeelmirza/4110440/33
#EXTINF:-1 tvg-id="andpictureshd.in" tvg-name="IN | & PICTURES HD" tvg-logo="http://filex.tv:8080/images/06ae3d7e2037a51f743e3b718f5f70e9.png" group-title="INDIAN ➾ ENTERTAINMENT",IN | & PICTURES HD
http://ip96.uk:8080/shakeelmirza/4110440/35
#EXTINF:-1 tvg-id="zeecinemaindiahd.in" tvg-name="IN | ZEE CINEMA HD" tvg-logo="http://jiotv.catchup.cdn.jio.com/dare_images/images/Zee_Cinema_HD.png" group-title="INDIAN ➾ ENTERTAINMENT",IN | ZEE CINEMA HD
http://ip96.uk:8080/shakeelmirza/4110440/37
#EXTINF:-1 tvg-id="Colors Cineplex Superhits" tvg-name="IN | COLORS CINEPLEX SUPERHIT" tvg-logo="http://filex.tv:8080/images/c540853bcc71d20eb039cfa614b4b900.png" group-title="INDIAN ➾ ENTERTAINMENT",IN | COLORS CINEPLEX SUPERHIT
http://ip96.uk:8080/shakeelmirza/4110440/43
#EXTINF:-1 tvg-id="Zee Action" tvg-name="IN | ZEE ACTION HD" tvg-logo="http://jiotv.catchup.cdn.jio.com/dare_images/images/Zee_Action.png" group-title="INDIAN ➾ ENTERTAINMENT",IN | ZEE ACTION HD
http://ip96.uk:8080/shakeelmirza/4110440/50
#EXTINF:-1 tvg-id="colorsrishtey.in" tvg-name="IN | COLORS RISHTE HD" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRrYYOBNUSNFkPvXP7wOCSbKt45IULkf6e66Q&usqp=CAU" group-title="INDIAN ➾ ENTERTAINMENT",IN | COLORS RISHTE HD
http://ip96.uk:8080/shakeelmirza/4110440/52
#EXTINF:-1 tvg-id="zeeanmolcinema.in" tvg-name="IN | ZEE ANMOL CINEMA HD" tvg-logo="http://jiotv.catchup.cdn.jio.com/dare_images/images/Zee_Anmol_Cinema.png" group-title="INDIAN ➾ ENTERTAINMENT",IN | ZEE ANMOL CINEMA HD
http://ip96.uk:8080/shakeelmirza/4110440/54
#EXTINF:-1 tvg-id="andflixhd.in" tvg-name="IN | & FLIX HD" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQuANx7s-Dxxy35uMqXRag0lUXvXhc19y7DCw&usqp=CAU" group-title="INDIAN ➾ ENTERTAINMENT",IN | & FLIX HD
http://ip96.uk:8080/shakeelmirza/4110440/55
#EXTINF:-1 tvg-id="" tvg-name="IN | SONY PAL HD" tvg-logo="http://sagraecdnems06.cdnsrv.jio.com/jiotv.catchup.cdn.jio.com/dare_images/images/Sony_Pal.png" group-title="INDIAN ➾ ENTERTAINMENT",IN | SONY PAL HD
http://ip96.uk:8080/shakeelmirza/4110440/56
#EXTINF:-1 tvg-id="" tvg-name="IN | COLOUR CINEPLEX BOLLYWOOD HD" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQu18Rs2fkZ8b_AmXmYEOsxiQlicYY9n4ukgQ&usqp=CAU" group-title="INDIAN ➾ ENTERTAINMENT",IN | COLOUR CINEPLEX BOLLYWOOD HD
http://ip96.uk:8080/shakeelmirza/4110440/58
#EXTINF:-1 tvg-id="" tvg-name="IN | B4U MOVIE HD" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQL-ajdmye9QnGBqgEjmP6TiNTkV7trgw2jwQ&usqp=CAU" group-title="INDIAN ➾ ENTERTAINMENT",IN | B4U MOVIE HD
http://ip96.uk:8080/shakeelmirza/4110440/60
#EXTINF:-1 tvg-id="" tvg-name="IN | SONY PIX HD" tvg-logo="http://filex.tv:8080/images/de357c9c796e9a5761b57088271d7a06.png" group-title="INDIAN ➾ ENTERTAINMENT",IN | SONY PIX HD
http://ip96.uk:8080/shakeelmirza/4110440/75
#EXTINF:-1 tvg-id="" tvg-name="IN | STAR UTSAV HD" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2024-08/0745eefbd8a17542003f01bf22735da0.png" group-title="INDIAN ➾ ENTERTAINMENT",IN | STAR UTSAV HD
http://ip96.uk:8080/shakeelmirza/4110440/103
#EXTINF:-1 tvg-id="" tvg-name="IN | MOVIE NOW HD" tvg-logo="https://i.imgur.com/LP27MEL.png" group-title="INDIAN ➾ ENTERTAINMENT",IN | MOVIE NOW HD
http://ip96.uk:8080/shakeelmirza/4110440/113
#EXTINF:-1 tvg-id="" tvg-name="IN | STAR MOVIES HD" tvg-logo="https://imagesstartv.whatsonindia.com/dasimages/channel/landscape/100x75/d3ZNcauZ.png" group-title="INDIAN ➾ ENTERTAINMENT",IN | STAR MOVIES HD
http://ip96.uk:8080/shakeelmirza/4110440/52223
#EXTINF:-1 tvg-id="" tvg-name="IN | STAR MOVIES SELECT ENGLISH HD" tvg-logo="https://tvscheduleindia.com/assets/brand/channels/i7ifGMFv.png" group-title="INDIAN ➾ ENTERTAINMENT",IN | STAR MOVIES SELECT ENGLISH HD
http://ip96.uk:8080/shakeelmirza/4110440/52225
#EXTINF:-1 tvg-id="" tvg-name="IN | ENTER 10 MOVIE HD" tvg-logo="" group-title="INDIAN ➾ ENTERTAINMENT",IN | ENTER 10 MOVIE HD
http://ip96.uk:8080/shakeelmirza/4110440/52231
#EXTINF:-1 tvg-id="" tvg-name="IN | BIG MAGIC HD" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/7/7b/BIG_Magic_Logo.jpg" group-title="INDIAN ➾ ENTERTAINMENT",IN | BIG MAGIC HD
http://ip96.uk:8080/shakeelmirza/4110440/52404
#EXTINF:-1 tvg-id="" tvg-name="IN | & PRIVE HD" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRMeDsn6WxeHhO_0LNmydM3Vw0qGoWREJtIxw&usqp=CAU" group-title="INDIAN ➾ ENTERTAINMENT",IN | & PRIVE HD
http://ip96.uk:8080/shakeelmirza/4110440/53043
#EXTINF:-1 tvg-id="" tvg-name="IN | COLORS INFINITY HD" tvg-logo="" group-title="INDIAN ➾ ENTERTAINMENT",IN | COLORS INFINITY HD
http://ip96.uk:8080/shakeelmirza/4110440/87330
#EXTINF:-1 tvg-id="" tvg-name="IN | PTC PUNJABI HD" tvg-logo="" group-title="INDIAN ➾ ENTERTAINMENT",IN | PTC PUNJABI HD
http://ip96.uk:8080/shakeelmirza/4110440/131564
#EXTINF:-1 tvg-id="" tvg-name="IN | PTC SIMRAN HD" tvg-logo="" group-title="INDIAN ➾ ENTERTAINMENT",IN | PTC SIMRAN HD
http://ip96.uk:8080/shakeelmirza/4110440/131565
#EXTINF:-1 tvg-id="" tvg-name="IN | SHEMAROO TV HD" tvg-logo="" group-title="INDIAN ➾ ENTERTAINMENT",IN | SHEMAROO TV HD
http://ip96.uk:8080/shakeelmirza/4110440/142889
#EXTINF:-1 tvg-id="" tvg-name="IN | STAR GOLD THRILLS HD" tvg-logo="" group-title="INDIAN ➾ ENTERTAINMENT",IN | STAR GOLD THRILLS HD
http://ip96.uk:8080/shakeelmirza/4110440/189473
#EXTINF:-1 tvg-id="" tvg-name="IN | STAR GOLD ROMANCE HD" tvg-logo="" group-title="INDIAN ➾ ENTERTAINMENT",IN | STAR GOLD ROMANCE HD
http://ip96.uk:8080/shakeelmirza/4110440/189474
#EXTINF:-1 tvg-id="" tvg-name="IN | MANORANJAN TV" tvg-logo="" group-title="INDIAN ➾ ENTERTAINMENT",IN | MANORANJAN TV
http://ip96.uk:8080/shakeelmirza/4110440/453382
#EXTINF:-1 tvg-id="" tvg-name="IN | FOOD FOOD" tvg-logo="" group-title="INDIAN ➾ ENTERTAINMENT",IN | FOOD FOOD
http://ip96.uk:8080/shakeelmirza/4110440/495596
#EXTINF:-1 tvg-id="" tvg-name="IN | ZEE CAFE HD" tvg-logo="http://103.184.192.164:5001/jtvimage/Zee_Cafe_HD.png" group-title="INDIAN ➾ ENTERTAINMENT",IN | ZEE CAFE HD
http://ip96.uk:8080/shakeelmirza/4110440/279284
#EXTINF:-1 tvg-id="" tvg-name="IN | ZEE CLASSIC" tvg-logo="" group-title="INDIAN ➾ ENTERTAINMENT",IN | ZEE CLASSIC
http://ip96.uk:8080/shakeelmirza/4110440/496178
#EXTINF:-1 tvg-id="" tvg-name="IN | SONY SET FHD 1" tvg-logo="https://filex.vip:443/images/ch7z1jaOyxxTknrelOaX7HQQ_3DW_fDah88toS_7bKhqRLOTv6Z6jHPiwLycPZs8puHwOaPuAWMkcU0S4363y5k9FPZzqkvHy4fsUk9CRXU.png" group-title="INDIAN ➾ ENTERTAINMENT",IN | SONY SET FHD 1
http://ip96.uk:8080/shakeelmirza/4110440/496689
#EXTINF:-1 tvg-id="" tvg-name="IN | SONY SET FHD 2" tvg-logo="https://filex.vip:443/images/ch7z1jaOyxxTknrelOaX7HQQ_3DW_fDah88toS_7bKhqRLOTv6Z6jHPiwLycPZs8puHwOaPuAWMkcU0S4363y5k9FPZzqkvHy4fsUk9CRXU.png" group-title="INDIAN ➾ ENTERTAINMENT",IN | SONY SET FHD 2
http://ip96.uk:8080/shakeelmirza/4110440/496681
#EXTINF:-1 tvg-id="" tvg-name="IN: Asianet News" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/3c1f85ac8e5ec5f6339c6da0c47b7103.png" group-title="INDIAN ➾ NEWS",IN: Asianet News
http://ip96.uk:8080/shakeelmirza/4110440/497242
#EXTINF:-1 tvg-id="" tvg-name="IN: Asianet News Tamil" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-04/fd3d465946186166f84982cd2312c198.png" group-title="INDIAN ➾ NEWS",IN: Asianet News Tamil
http://ip96.uk:8080/shakeelmirza/4110440/497243
#EXTINF:-1 tvg-id="" tvg-name="IN: Asianet Suvarna News" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/bb181f1491b27a4fd709f97c80c00476.jpg" group-title="INDIAN ➾ NEWS",IN: Asianet Suvarna News
http://ip96.uk:8080/shakeelmirza/4110440/497244
#EXTINF:-1 tvg-id="" tvg-name="IN: Bansal News" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/cd73513ab34fd0e22bf7d4f7cbedf62d.png" group-title="INDIAN ➾ NEWS",IN: Bansal News
http://ip96.uk:8080/shakeelmirza/4110440/497245
#EXTINF:-1 tvg-id="" tvg-name="IN: CNBC Awaaz" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/34add1edff1f19b30b0b9e22d41407de.png" group-title="INDIAN ➾ NEWS",IN: CNBC Awaaz
http://ip96.uk:8080/shakeelmirza/4110440/497246
#EXTINF:-1 tvg-id="" tvg-name="IN: CNBC Bajar" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/388ce1e6457a331d9a68d5c59634c584.png" group-title="INDIAN ➾ NEWS",IN: CNBC Bajar
http://ip96.uk:8080/shakeelmirza/4110440/497247
#EXTINF:-1 tvg-id="" tvg-name="IN: CNBC TV 18" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/65a23d8e6f37fb9b6ba3f94b958dcdbf.png" group-title="INDIAN ➾ NEWS",IN: CNBC TV 18
http://ip96.uk:8080/shakeelmirza/4110440/497248
#EXTINF:-1 tvg-id="" tvg-name="IN: CNN News 18" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="INDIAN ➾ NEWS",IN: CNN News 18
http://ip96.uk:8080/shakeelmirza/4110440/497249
#EXTINF:-1 tvg-id="" tvg-name="IN: CVR News" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/6446fd446279b4d4f2be40b52412b27a.png" group-title="INDIAN ➾ NEWS",IN: CVR News
http://ip96.uk:8080/shakeelmirza/4110440/497250
#EXTINF:-1 tvg-id="" tvg-name="IN: DD India" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/a532a1f64e91ea4ead84ff678e1592b1.png" group-title="INDIAN ➾ NEWS",IN: DD India
http://ip96.uk:8080/shakeelmirza/4110440/497251
#EXTINF:-1 tvg-id="" tvg-name="IN: DD Malayalam" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/e5e64952c42751c286c68c293eed2006.png" group-title="INDIAN ➾ NEWS",IN: DD Malayalam
http://ip96.uk:8080/shakeelmirza/4110440/497252
#EXTINF:-1 tvg-id="" tvg-name="IN: DD News" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/a9182065b952abc2263ed53af8259479.png" group-title="INDIAN ➾ NEWS",IN: DD News
http://ip96.uk:8080/shakeelmirza/4110440/497253
#EXTINF:-1 tvg-id="" tvg-name="IN: ET Now" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/ad76cd879232d530ba344e17e4d4b993.png" group-title="INDIAN ➾ NEWS",IN: ET Now
http://ip96.uk:8080/shakeelmirza/4110440/497254
#EXTINF:-1 tvg-id="" tvg-name="IN: Good News Today" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-07/93df1e40abe657816295c7ed4593603f.jpeg" group-title="INDIAN ➾ NEWS",IN: Good News Today
http://ip96.uk:8080/shakeelmirza/4110440/497255
#EXTINF:-1 tvg-id="" tvg-name="IN: India News" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/a8d0958a45ea16ecea0e9a41ae42c836.png" group-title="INDIAN ➾ NEWS",IN: India News
http://ip96.uk:8080/shakeelmirza/4110440/497256
#EXTINF:-1 tvg-id="" tvg-name="IN: India News Rajasthan" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-09/73c0e20cdd20df22aa69088931c3b4c7.jpeg" group-title="INDIAN ➾ NEWS",IN: India News Rajasthan
http://ip96.uk:8080/shakeelmirza/4110440/497257
#EXTINF:-1 tvg-id="" tvg-name="IN: India Today" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/605a6f1ad45e50c8dec82884a85c9a8a.png" group-title="INDIAN ➾ NEWS",IN: India Today
http://ip96.uk:8080/shakeelmirza/4110440/497258
#EXTINF:-1 tvg-id="" tvg-name="IN: India TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/3aa3d8bc970ec9ab9ca530865a4907ac.png" group-title="INDIAN ➾ NEWS",IN: India TV
http://ip96.uk:8080/shakeelmirza/4110440/497259
#EXTINF:-1 tvg-id="" tvg-name="IN: K News India" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/a3d43a0a5ebce9e53b2d5f9a3b3d22eb.png" group-title="INDIAN ➾ NEWS",IN: K News India
http://ip96.uk:8080/shakeelmirza/4110440/497260
#EXTINF:-1 tvg-id="" tvg-name="IN: Khabrain Abhi Tak" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-02/19f39f51241dbfe565f8453726154f68.png" group-title="INDIAN ➾ NEWS",IN: Khabrain Abhi Tak
http://ip96.uk:8080/shakeelmirza/4110440/497261
#EXTINF:-1 tvg-id="" tvg-name="IN: Lok Sabha TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/f0ee5348027146b4c16b1af3413f28d1.png" group-title="INDIAN ➾ NEWS",IN: Lok Sabha TV
http://ip96.uk:8080/shakeelmirza/4110440/497262
#EXTINF:-1 tvg-id="" tvg-name="IN: Mathrubhumi News" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-02/123a158b16c60c67026dbbd608850123.png" group-title="INDIAN ➾ NEWS",IN: Mathrubhumi News
http://ip96.uk:8080/shakeelmirza/4110440/497263
#EXTINF:-1 tvg-id="" tvg-name="IN: Media One" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/6da706192ed41078abbdf6bdb0d86fe0.png" group-title="INDIAN ➾ NEWS",IN: Media One
http://ip96.uk:8080/shakeelmirza/4110440/497264
#EXTINF:-1 tvg-id="" tvg-name="IN: NDTV 24X7" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-12/496f59ed3a3addec09ad8af54fd489dc.png" group-title="INDIAN ➾ NEWS",IN: NDTV 24X7
http://ip96.uk:8080/shakeelmirza/4110440/497265
#EXTINF:-1 tvg-id="" tvg-name="IN: NDTV India" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/b13c4d6511c08a518cdc7e53c36575be.png" group-title="INDIAN ➾ NEWS",IN: NDTV India
http://ip96.uk:8080/shakeelmirza/4110440/497266
#EXTINF:-1 tvg-id="" tvg-name="IN: News 7 Tamil" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/caa7e4145e5997cc3fe36f9c5ba20b31.png" group-title="INDIAN ➾ NEWS",IN: News 7 Tamil
http://ip96.uk:8080/shakeelmirza/4110440/497267
#EXTINF:-1 tvg-id="" tvg-name="IN: News 18 Gujarati" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/8da29f88c2ceeb8c6cffaed52a7bd94d.png" group-title="INDIAN ➾ NEWS",IN: News 18 Gujarati
http://ip96.uk:8080/shakeelmirza/4110440/497268
#EXTINF:-1 tvg-id="" tvg-name="IN: News 18 Kannada" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-07/9a820c7972512f179fbfedff4a2d256a.png" group-title="INDIAN ➾ NEWS",IN: News 18 Kannada
http://ip96.uk:8080/shakeelmirza/4110440/497269
#EXTINF:-1 tvg-id="" tvg-name="IN: News 18 Lokmat" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/6cfbf36a04bc0a192795eb6be6dbdb3b.png" group-title="INDIAN ➾ NEWS",IN: News 18 Lokmat
http://ip96.uk:8080/shakeelmirza/4110440/497270
#EXTINF:-1 tvg-id="" tvg-name="IN: News 18 Malayalam" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-02/868f9af6f14d9f113a17eccd28a7655c.png" group-title="INDIAN ➾ NEWS",IN: News 18 Malayalam
http://ip96.uk:8080/shakeelmirza/4110440/497271
#EXTINF:-1 tvg-id="" tvg-name="IN: News 18 Punjab" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-07/c05f054b4189eb8fad513a19ca970078.jpeg" group-title="INDIAN ➾ NEWS",IN: News 18 Punjab
http://ip96.uk:8080/shakeelmirza/4110440/497272
#EXTINF:-1 tvg-id="" tvg-name="IN: News 18 Tamil" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/20fab0bad66f91a6abf2e72938071f9e.png" group-title="INDIAN ➾ NEWS",IN: News 18 Tamil
http://ip96.uk:8080/shakeelmirza/4110440/497273
#EXTINF:-1 tvg-id="" tvg-name="IN: News 18 Uttar Pradesh & Uttarakhand" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-02/334e08c69dd06a94653eca3c8fdea2f9.png" group-title="INDIAN ➾ NEWS",IN: News 18 Uttar Pradesh & Uttarakhand
http://ip96.uk:8080/shakeelmirza/4110440/497274
#EXTINF:-1 tvg-id="" tvg-name="IN: News 24" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/b6c52d4dbc0413e8d5b596d8bddad2e3.png" group-title="INDIAN ➾ NEWS",IN: News 24
http://ip96.uk:8080/shakeelmirza/4110440/497275
#EXTINF:-1 tvg-id="" tvg-name="IN: Puthiya Thalaimurai" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-02/10ee58a7d3bfab98c84935de70beef73.png" group-title="INDIAN ➾ NEWS",IN: Puthiya Thalaimurai
http://ip96.uk:8080/shakeelmirza/4110440/497276
#EXTINF:-1 tvg-id="" tvg-name="IN: Raj News" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-09/0180a7757679a7804d6ee75ec4c8791e.png" group-title="INDIAN ➾ NEWS",IN: Raj News
http://ip96.uk:8080/shakeelmirza/4110440/497277
#EXTINF:-1 tvg-id="" tvg-name="IN: Reporter" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/99680f1a9114d00686a9f812a69f002d.png" group-title="INDIAN ➾ NEWS",IN: Reporter
http://ip96.uk:8080/shakeelmirza/4110440/497278
#EXTINF:-1 tvg-id="" tvg-name="IN: Republic TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/da4f866180422b1db1f1132c046b5a16.png" group-title="INDIAN ➾ NEWS",IN: Republic TV
http://ip96.uk:8080/shakeelmirza/4110440/497279
#EXTINF:-1 tvg-id="" tvg-name="IN: Sadhna Plus News" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/d0f409b84422ab1ee589ae7188ebc911.png" group-title="INDIAN ➾ NEWS",IN: Sadhna Plus News
http://ip96.uk:8080/shakeelmirza/4110440/497280
#EXTINF:-1 tvg-id="" tvg-name="IN: Sahara Samay" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-03/9696bf3cb4acfd9d63e8628d515e824a.jpg" group-title="INDIAN ➾ NEWS",IN: Sahara Samay
http://ip96.uk:8080/shakeelmirza/4110440/497281
#EXTINF:-1 tvg-id="" tvg-name="IN: Samachar Plus Rajasthan" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-07/1950c7ecb83a5302231a1c556eef1ebd.png" group-title="INDIAN ➾ NEWS",IN: Samachar Plus Rajasthan
http://ip96.uk:8080/shakeelmirza/4110440/497282
#EXTINF:-1 tvg-id="" tvg-name="IN: Sun News" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-04/1f7e6af71c53b1b7853876efa23acb64.png" group-title="INDIAN ➾ NEWS",IN: Sun News
http://ip96.uk:8080/shakeelmirza/4110440/497283
#EXTINF:-1 tvg-id="" tvg-name="IN: Times Now" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/5958ed44028a113a0503a1ada6c6d6fa.png" group-title="INDIAN ➾ NEWS",IN: Times Now
http://ip96.uk:8080/shakeelmirza/4110440/497284
#EXTINF:-1 tvg-id="" tvg-name="IN: TV 9 Gujarati" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/5d788e159275192ad8fe55974d48064b.png" group-title="INDIAN ➾ NEWS",IN: TV 9 Gujarati
http://ip96.uk:8080/shakeelmirza/4110440/497285
#EXTINF:-1 tvg-id="" tvg-name="IN: TV 9 Kannada" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-12/f653a845a780d18eb98c4f6d4f569e85.png" group-title="INDIAN ➾ NEWS",IN: TV 9 Kannada
http://ip96.uk:8080/shakeelmirza/4110440/497286
#EXTINF:-1 tvg-id="" tvg-name="IN: TV 9 Marathi" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/11adf97a1f11e433ee0133750c6f8eb5.svg" group-title="INDIAN ➾ NEWS",IN: TV 9 Marathi
http://ip96.uk:8080/shakeelmirza/4110440/497287
#EXTINF:-1 tvg-id="" tvg-name="IN: TV 9 Telugu" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/ced277da5096e518641e52e606876d47.png" group-title="INDIAN ➾ NEWS",IN: TV 9 Telugu
http://ip96.uk:8080/shakeelmirza/4110440/497288
#EXTINF:-1 tvg-id="" tvg-name="IN: V6 News" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/ab8b937fcb8eeac0eacaefbc8b7b5f8b.png" group-title="INDIAN ➾ NEWS",IN: V6 News
http://ip96.uk:8080/shakeelmirza/4110440/497289
#EXTINF:-1 tvg-id="" tvg-name="IN: Zee 24 Ghanta" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/c8f1da0128e2eec1a1f93811e761f7d8.png" group-title="INDIAN ➾ NEWS",IN: Zee 24 Ghanta
http://ip96.uk:8080/shakeelmirza/4110440/497290
#EXTINF:-1 tvg-id="" tvg-name="IN: Zee 24 Kalak" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/8df915e2607e4ae07918bc72a56f1d3f.png" group-title="INDIAN ➾ NEWS",IN: Zee 24 Kalak
http://ip96.uk:8080/shakeelmirza/4110440/497291
#EXTINF:-1 tvg-id="" tvg-name="IN: Zee News" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/59f3fa24fe411768bb5e776b6b0ec11d.png" group-title="INDIAN ➾ NEWS",IN: Zee News
http://ip96.uk:8080/shakeelmirza/4110440/497292
#EXTINF:-1 tvg-id="" tvg-name="IN: ZEE Rajasthan News" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-09/ea34dd159c2aaa97823f79c17456583f.svg" group-title="INDIAN ➾ NEWS",IN: ZEE Rajasthan News
http://ip96.uk:8080/shakeelmirza/4110440/497293
#EXTINF:-1 tvg-id="" tvg-name="IN | M TV" tvg-logo="" group-title="IN ➾ MUSIC VIP",IN | M TV
http://ip96.uk:8080/shakeelmirza/4110440/122825
#EXTINF:-1 tvg-id="" tvg-name="IN | BINDAS MUSIC" tvg-logo="" group-title="IN ➾ MUSIC VIP",IN | BINDAS MUSIC
http://ip96.uk:8080/shakeelmirza/4110440/123312
#EXTINF:-1 tvg-id="" tvg-name="IN | ZOOM MUSIC HD" tvg-logo="https://www.lyngsat.com/logo/tv/zz/zoom_tv_in.png" group-title="IN ➾ MUSIC VIP",IN | ZOOM MUSIC HD
http://ip96.uk:8080/shakeelmirza/4110440/246679
#EXTINF:-1 tvg-id="" tvg-name="IN | M TV MUSIC HD" tvg-logo="https://www.lyngsat.com/logo/tv/mm/mtv-us.png" group-title="IN ➾ MUSIC VIP",IN | M TV MUSIC HD
http://ip96.uk:8080/shakeelmirza/4110440/246680
#EXTINF:-1 tvg-id="" tvg-name="IN | 8XM MUSIC HD" tvg-logo="https://www.lyngsat.com/logo/tv/num/8x_music_pk.png" group-title="IN ➾ MUSIC VIP",IN | 8XM MUSIC HD
http://ip96.uk:8080/shakeelmirza/4110440/246684
#EXTINF:-1 tvg-id="" tvg-name="JALWA MUSIC HD" tvg-logo="https://www.lyngsat.com/logo/tv/jj/jalwa_tv_pk.png" group-title="IN ➾ MUSIC VIP",JALWA MUSIC HD
http://ip96.uk:8080/shakeelmirza/4110440/246685
#EXTINF:-1 tvg-id="" tvg-name="ARY MUSIC HD" tvg-logo="https://www.lyngsat.com/logo/tv/aa/ary_musik.png" group-title="IN ➾ MUSIC VIP",ARY MUSIC HD
http://ip96.uk:8080/shakeelmirza/4110440/246686
#EXTINF:-1 tvg-id="" tvg-name="IN | ANIMAL PLANET 4K" tvg-logo="https://1000logos.net/wp-content/uploads/2023/01/Animal-Planet-logo.png" group-title="IN ➾ ALL DISCOVERY",IN | ANIMAL PLANET 4K
http://ip96.uk:8080/shakeelmirza/4110440/246720
#EXTINF:-1 tvg-id="" tvg-name="IN | HISTORY 4k" tvg-logo="https://www.lyngsat.com/logo/tv/hh/history_us.png" group-title="IN ➾ ALL DISCOVERY",IN | HISTORY 4k
http://ip96.uk:8080/shakeelmirza/4110440/246722
#EXTINF:-1 tvg-id="" tvg-name="IN | NAT GEO WILD 4K" tvg-logo="https://seeklogo.com/images/N/nat-geo-wild-logo-CFB1305DCD-seeklogo.com.png" group-title="IN ➾ ALL DISCOVERY",IN | NAT GEO WILD 4K
http://ip96.uk:8080/shakeelmirza/4110440/246728
#EXTINF:-1 tvg-id="" tvg-name="IN | BBC EARTH 4K" tvg-logo="https://www.lyngsat.com/logo/tv/bb/bbc-earth-uk.png" group-title="IN ➾ ALL DISCOVERY",IN | BBC EARTH 4K
http://ip96.uk:8080/shakeelmirza/4110440/246730
#EXTINF:-1 tvg-id="" tvg-name="IN | TLC 4K" tvg-logo="https://seeklogo.com/images/T/tlc-logo-774E9A4AB6-seeklogo.com.png" group-title="IN ➾ ALL DISCOVERY",IN | TLC 4K
http://ip96.uk:8080/shakeelmirza/4110440/246732
#EXTINF:-1 tvg-id="" tvg-name="IN | DISCOVERY 4K" tvg-logo="http://14.192.144.8:80/images/a281ac3e2b560404c8ca6b83f1855d5b.png" group-title="IN ➾ ALL DISCOVERY",IN | DISCOVERY 4K
http://ip96.uk:8080/shakeelmirza/4110440/246734
#EXTINF:-1 tvg-id="" tvg-name="IN | DISCOVERY SCIENCE 4K" tvg-logo="http://14.192.144.8:80/images/8a0b663405956121afd3fbae92f56a76.png" group-title="IN ➾ ALL DISCOVERY",IN | DISCOVERY SCIENCE 4K
http://ip96.uk:8080/shakeelmirza/4110440/246736
#EXTINF:-1 tvg-id="" tvg-name="IN | INVESTIGATION DISCOVERY 4K" tvg-logo="http://14.192.144.8:80/images/100aa2bc3a141d7f3bc7c1a4cdd39cd5.png" group-title="IN ➾ ALL DISCOVERY",IN | INVESTIGATION DISCOVERY 4K
http://ip96.uk:8080/shakeelmirza/4110440/246738
#EXTINF:-1 tvg-id="" tvg-name="IN | NATIONAL GEO 4K" tvg-logo="http://webotv.asia:80/images/e990a04b9b6c0178d787ddc066e997b4.png" group-title="IN ➾ ALL DISCOVERY",IN | NATIONAL GEO 4K
http://ip96.uk:8080/shakeelmirza/4110440/246740
#EXTINF:-1 tvg-id="" tvg-name="USA | OUT DOOR HD" tvg-logo="https://www.lyngsat-logo.com/logo/tv/oo/outdoor-channel-us.png" group-title="IN ➾ ALL DISCOVERY",USA | OUT DOOR HD
http://ip96.uk:8080/shakeelmirza/4110440/246746
#EXTINF:-1 tvg-id="" tvg-name="RELAXON" tvg-logo="" group-title="IN ➾ ALL DISCOVERY",RELAXON
http://ip96.uk:8080/shakeelmirza/4110440/451499
#EXTINF:-1 tvg-id="" tvg-name="IN | CARTOON NET WORK" tvg-logo="https://i.imgur.com/mXgp2qD.png" group-title="IN ➾ KIDS",IN | CARTOON NET WORK
http://ip96.uk:8080/shakeelmirza/4110440/5
#EXTINF:-1 tvg-id="" tvg-name="IN | Nick Jr" tvg-logo="https://images.pluto.tv/channels/5f121460b73ac6000719fbaf/colorLogoPNG.png" group-title="IN ➾ KIDS",IN | Nick Jr
http://ip96.uk:8080/shakeelmirza/4110440/9
#EXTINF:-1 tvg-id="" tvg-name="IN | Nick HD +" tvg-logo="http://103.184.192.164:5001/jtvimage/Nick_HD_Plus.png" group-title="IN ➾ KIDS",IN | Nick HD +
http://ip96.uk:8080/shakeelmirza/4110440/11
#EXTINF:-1 tvg-id="" tvg-name="IN | Pogo (hindi)" tvg-logo="https://www.lyngsat.com/logo/tv/pp/pogo-in.png" group-title="IN ➾ KIDS",IN | Pogo (hindi)
http://ip96.uk:8080/shakeelmirza/4110440/320
#EXTINF:-1 tvg-id="" tvg-name="IN | Hangama" tvg-logo="https://www.lyngsat.com/logo/tv/hh/hungama.png" group-title="IN ➾ KIDS",IN | Hangama
http://ip96.uk:8080/shakeelmirza/4110440/123826
#EXTINF:-1 tvg-id="" tvg-name="IN | DISNEY JUNIOR HINDI" tvg-logo="" group-title="IN ➾ KIDS",IN | DISNEY JUNIOR HINDI
http://ip96.uk:8080/shakeelmirza/4110440/123848
#EXTINF:-1 tvg-id="" tvg-name="IN | DISNEY CHANNEL" tvg-logo="https://logos-world.net/wp-content/uploads/2021/08/Disney-Channel-Logo-700x394.png" group-title="IN ➾ KIDS",IN | DISNEY CHANNEL
http://ip96.uk:8080/shakeelmirza/4110440/246763
#EXTINF:-1 tvg-id="" tvg-name="IN | DISCOVERY KIDS" tvg-logo="https://www.lyngsat.com/logo/tv/dd/discovery-kids-asia-us.png" group-title="IN ➾ KIDS",IN | DISCOVERY KIDS
http://ip96.uk:8080/shakeelmirza/4110440/246765
#EXTINF:-1 tvg-id="" tvg-name="IN | SONIC NICK HD" tvg-logo="https://www.lyngsat.com/logo/tv/nn/nickelodeon_sonic_us.png" group-title="IN ➾ KIDS",IN | SONIC NICK HD
http://ip96.uk:8080/shakeelmirza/4110440/246767
#EXTINF:-1 tvg-id="" tvg-name="IN | DISNEY JUNIOR HD" tvg-logo="https://www.lyngsat.com/logo/tv/dd/disney_junior_us.png" group-title="IN ➾ KIDS",IN | DISNEY JUNIOR HD
http://ip96.uk:8080/shakeelmirza/4110440/246769
#EXTINF:-1 tvg-id="" tvg-name="IN | NICK HD" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/8/85/New_Nick_Logo_2015.png" group-title="IN ➾ KIDS",IN | NICK HD
http://ip96.uk:8080/shakeelmirza/4110440/246770
#EXTINF:-1 tvg-id="" tvg-name="IN | KIDS ZONE HD" tvg-logo="https://www.lyngsat.com/logo/tv/kk/kidzoneplus-pakistan-ee-pk.png" group-title="IN ➾ KIDS",IN | KIDS ZONE HD
http://ip96.uk:8080/shakeelmirza/4110440/246774
#EXTINF:-1 tvg-id="" tvg-name="IN | PLANET FUN HD" tvg-logo="https://www.lyngsat.com/logo/tv/pp/planet-fun-uk.png" group-title="IN ➾ KIDS",IN | PLANET FUN HD
http://ip96.uk:8080/shakeelmirza/4110440/246775
#EXTINF:-1 tvg-id="" tvg-name="IN | HOORA TV HD" tvg-logo="https://www.lyngsat.com/logo/tv/hh/hoora-tv-uk.png" group-title="IN ➾ KIDS",IN | HOORA TV HD
http://ip96.uk:8080/shakeelmirza/4110440/246778
#EXTINF:-1 tvg-id="" tvg-name="PK | QURAN MUJEED HD" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQqIunp2uh2ml7qunCMxZMnnK0LlcU5J3trYduXFFfpeU1swjI2yuY0h3g&s=10" group-title="PK ➾ ISLAMIC",PK | QURAN MUJEED HD
http://ip96.uk:8080/shakeelmirza/4110440/311
#EXTINF:-1 tvg-id="" tvg-name="PK | MAKKAH TV HD" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTa0DMYfuiDHfvabUsLdD9zSym0_0sFzvv0HQ&s" group-title="PK ➾ ISLAMIC",PK | MAKKAH TV HD
http://ip96.uk:8080/shakeelmirza/4110440/52112
#EXTINF:-1 tvg-id="" tvg-name="PK | NOOR TV HD" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQNW5YcMFmUmCkVaFvHjMjRHPYsI79RYDpoAA&usqp=CAU" group-title="PK ➾ ISLAMIC",PK | NOOR TV HD
http://ip96.uk:8080/shakeelmirza/4110440/141305
#EXTINF:-1 tvg-id="" tvg-name="PK | SAUDI SUNNAH HD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/sunna-tv-sa.png" group-title="PK ➾ ISLAMIC",PK | SAUDI SUNNAH HD
http://ip96.uk:8080/shakeelmirza/4110440/247145
#EXTINF:-1 tvg-id="" tvg-name="PK | MADANI CHANNEL HD" tvg-logo="https://www.lyngsat.com/logo/tv/mm/madani-channel-pk.png" group-title="PK ➾ ISLAMIC",PK | MADANI CHANNEL HD
http://ip96.uk:8080/shakeelmirza/4110440/247146
#EXTINF:-1 tvg-id="" tvg-name="PK | AHLEBAIT TV HD" tvg-logo="https://www.lyngsat.com/logo/tv/aa/ahlebait.png" group-title="PK ➾ ISLAMIC",PK | AHLEBAIT TV HD
http://ip96.uk:8080/shakeelmirza/4110440/247148
#EXTINF:-1 tvg-id="" tvg-name="PK | HADI TV HD" tvg-logo="https://en.haditv.co.uk/pics/logo.png" group-title="PK ➾ ISLAMIC",PK | HADI TV HD
http://ip96.uk:8080/shakeelmirza/4110440/247149
#EXTINF:-1 tvg-id="" tvg-name="PK | ARY QTV HD" tvg-logo="https://www.lyngsat.com/logo/tv/aa/ary_qtv.png" group-title="PK ➾ ISLAMIC",PK | ARY QTV HD
http://ip96.uk:8080/shakeelmirza/4110440/247150
#EXTINF:-1 tvg-id="" tvg-name="PK | PEACE TV URDU HD" tvg-logo="https://www.lyngsat.com/logo/tv/pp/peace_tv_ae_urdu.png" group-title="PK ➾ ISLAMIC",PK | PEACE TV URDU HD
http://ip96.uk:8080/shakeelmirza/4110440/247151
#EXTINF:-1 tvg-id="" tvg-name="PK | PEACE TV ENG HD" tvg-logo="https://www.lyngsat.com/logo/tv/pp/peace-tv-english-ae.png" group-title="PK ➾ ISLAMIC",PK | PEACE TV ENG HD
http://ip96.uk:8080/shakeelmirza/4110440/247152
#EXTINF:-1 tvg-id="" tvg-name="PK | PAIGHAM TV URDU HD" tvg-logo="https://www.lyngsat.com/logo/tv/pp/paigham_tv_pk.png" group-title="PK ➾ ISLAMIC",PK | PAIGHAM TV URDU HD
http://ip96.uk:8080/shakeelmirza/4110440/247153
#EXTINF:-1 tvg-id="" tvg-name="PK | MUNTAZIR TV HD" tvg-logo="https://www.lyngsat.com/logo/tv/mm/muntazar-tv-pk.png" group-title="PK ➾ ISLAMIC",PK | MUNTAZIR TV HD
http://ip96.uk:8080/shakeelmirza/4110440/247154
#EXTINF:-1 tvg-id="" tvg-name="PK | HADI TV 1" tvg-logo="" group-title="PK ➾ ISLAMIC",PK | HADI TV 1
http://ip96.uk:8080/shakeelmirza/4110440/451418
#EXTINF:-1 tvg-id="" tvg-name="PK | KARBALA TV HD" tvg-logo="https://www.lyngsat.com/logo/tv/kk/karbala_satellite_channel.png" group-title="PK ➾ ISLAMIC",PK | KARBALA TV HD
http://ip96.uk:8080/shakeelmirza/4110440/247147
#EXTINF:-1 tvg-id="" tvg-name="BLOOMBERG-HD" tvg-logo="" group-title="INTERNATIONAL ➾ NEWS",BLOOMBERG-HD
http://ip96.uk:8080/shakeelmirza/4110440/276156
#EXTINF:-1 tvg-id="92 News.pk" tvg-name="PK | 92 NEWS HD" tvg-logo="https://www.lyngsat.com/logo/tv/num/92-news-pk.png" group-title="PAKISTAN ➾ NEWS",PK | 92 NEWS HD
http://ip96.uk:8080/shakeelmirza/4110440/52035
#EXTINF:-1 tvg-id="Bol News.pk" tvg-name="PK | BOL NEWS HD" tvg-logo="https://www.lyngsat.com/logo/tv/bb/bol_news_pk.png" group-title="PAKISTAN ➾ NEWS",PK | BOL NEWS HD
http://ip96.uk:8080/shakeelmirza/4110440/52037
#EXTINF:-1 tvg-id="Express News.pk" tvg-name="PK | EXPRESS NEWS HD" tvg-logo="https://www.lyngsat.com/logo/tv/ee/express-news-pk.png" group-title="PAKISTAN ➾ NEWS",PK | EXPRESS NEWS HD
http://ip96.uk:8080/shakeelmirza/4110440/52039
#EXTINF:-1 tvg-id="Geo News.pk" tvg-name="PK | GEO NEWS HD" tvg-logo="https://www.lyngsat.com/logo/tv/gg/geo_tv_me.png" group-title="PAKISTAN ➾ NEWS",PK | GEO NEWS HD
http://ip96.uk:8080/shakeelmirza/4110440/52041
#EXTINF:-1 tvg-id="ARY News.pk" tvg-name="PK | ARY NEWS HD" tvg-logo="https://www.lyngsat.com/logo/tv/aa/ary_news_asia.png" group-title="PAKISTAN ➾ NEWS",PK | ARY NEWS HD
http://ip96.uk:8080/shakeelmirza/4110440/52043
#EXTINF:-1 tvg-id="Aaj News.pk" tvg-name="PK | AAJ NEWS" tvg-logo="https://www.lyngsat-logo.com/logo/tv/aa/aaj_tv_news.png" group-title="PAKISTAN ➾ NEWS",PK | AAJ NEWS
http://ip96.uk:8080/shakeelmirza/4110440/52044
#EXTINF:-1 tvg-id="Samaa News.pk" tvg-name="PK | SAMAA NEWS" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTWsYR2EoaMEqmvdZL8l8vC4nKRi5SJtmNKmQ&usqp=CAU" group-title="PAKISTAN ➾ NEWS",PK | SAMAA NEWS
http://ip96.uk:8080/shakeelmirza/4110440/52045
#EXTINF:-1 tvg-id="City 41.pk" tvg-name="PK | CITY 41 NEWS" tvg-logo="https://www.lyngsat.com/logo/tv/cc/city_41_tv.png" group-title="PAKISTAN ➾ NEWS",PK | CITY 41 NEWS
http://ip96.uk:8080/shakeelmirza/4110440/52051
#EXTINF:-1 tvg-id="City 42.pk" tvg-name="PK | CITY 42 NEWS" tvg-logo="https://www.lyngsat.com/logo/tv/cc/city_42_tv.png" group-title="PAKISTAN ➾ NEWS",PK | CITY 42 NEWS
http://ip96.uk:8080/shakeelmirza/4110440/52052
#EXTINF:-1 tvg-id="Lahore News.pk" tvg-name="PK | LAHORE NEWS HD" tvg-logo="https://www.lyngsat.com/logo/tv/ll/lahore_news_pk.png" group-title="PAKISTAN ➾ NEWS",PK | LAHORE NEWS HD
http://ip96.uk:8080/shakeelmirza/4110440/52056
#EXTINF:-1 tvg-id="Sindh TV News.pk" tvg-name="PK | SINDH NEWS " tvg-logo="https://www.lyngsat.com/logo/tv/ss/sindh_tv_news.png" group-title="PAKISTAN ➾ NEWS",PK | SINDH NEWS 
http://ip96.uk:8080/shakeelmirza/4110440/52057
#EXTINF:-1 tvg-id="GNN.pk" tvg-name="PK | GNN NEWS" tvg-logo="https://www.lyngsat.com/logo/tv/gg/gourmet-news-network-pk.png" group-title="PAKISTAN ➾ NEWS",PK | GNN NEWS
http://ip96.uk:8080/shakeelmirza/4110440/52058
#EXTINF:-1 tvg-id="Lahore Rang.pk" tvg-name="PK | LAHORE RANG" tvg-logo="https://www.lyngsat.com/logo/tv/ll/lahore-rang-pk.png" group-title="PAKISTAN ➾ NEWS",PK | LAHORE RANG
http://ip96.uk:8080/shakeelmirza/4110440/52060
#EXTINF:-1 tvg-id="Dawn News.pk" tvg-name="PK | DAWN NEWS" tvg-logo="https://www.lyngsat.com/logo/tv/dd/dawn_news_pk.png" group-title="PAKISTAN ➾ NEWS",PK | DAWN NEWS
http://ip96.uk:8080/shakeelmirza/4110440/52061
#EXTINF:-1 tvg-id="Dunya News.pk" tvg-name="PK | DUNIYA NEWS HD" tvg-logo="https://www.lyngsat.com/logo/tv/dd/dunya_news_tv_pk.png" group-title="PAKISTAN ➾ NEWS",PK | DUNIYA NEWS HD
http://ip96.uk:8080/shakeelmirza/4110440/52066
#EXTINF:-1 tvg-id="News One.pk" tvg-name="PK | NEWS ONE HD" tvg-logo="https://www.lyngsat.com/logo/tv/nn/news-one-pk.png" group-title="PAKISTAN ➾ NEWS",PK | NEWS ONE HD
http://ip96.uk:8080/shakeelmirza/4110440/52068
#EXTINF:-1 tvg-id="24 Channel.pk" tvg-name="PK | 24 NEWS HD" tvg-logo="https://www.lyngsat.com/logo/tv/cc/channel_24_pk.png" group-title="PAKISTAN ➾ NEWS",PK | 24 NEWS HD
http://ip96.uk:8080/shakeelmirza/4110440/52070
#EXTINF:-1 tvg-id="" tvg-name="PK | ABB TAK NEWS HD" tvg-logo="https://www.lyngsat.com/logo/tv/aa/abb_takk_pk.png" group-title="PAKISTAN ➾ NEWS",PK | ABB TAK NEWS HD
http://ip96.uk:8080/shakeelmirza/4110440/52071
#EXTINF:-1 tvg-id="" tvg-name="PK | PTV NEWS HD" tvg-logo="https://www.lyngsat.com/logo/tv/pp/ptv_news_pk.png" group-title="PAKISTAN ➾ NEWS",PK | PTV NEWS HD
http://ip96.uk:8080/shakeelmirza/4110440/52073
#EXTINF:-1 tvg-id="" tvg-name="PK | VSH NEWS" tvg-logo="" group-title="PAKISTAN ➾ NEWS",PK | VSH NEWS
http://ip96.uk:8080/shakeelmirza/4110440/52074
#EXTINF:-1 tvg-id="" tvg-name="PK | ROHI TV" tvg-logo="" group-title="PAKISTAN ➾ NEWS",PK | ROHI TV
http://ip96.uk:8080/shakeelmirza/4110440/52075
#EXTINF:-1 tvg-id="" tvg-name="PK | PUBLIC NEWS HD" tvg-logo="https://www.lyngsat.com/logo/tv/pp/public-news-pk.png" group-title="PAKISTAN ➾ NEWS",PK | PUBLIC NEWS HD
http://ip96.uk:8080/shakeelmirza/4110440/52226
#EXTINF:-1 tvg-id="" tvg-name="PK | TV2DAY" tvg-logo="" group-title="PAKISTAN ➾ NEWS",PK | TV2DAY
http://ip96.uk:8080/shakeelmirza/4110440/52227
#EXTINF:-1 tvg-id="" tvg-name="PK | HUM NEWS HD" tvg-logo="https://www.lyngsat.com/logo/tv/hh/hum-news-pk.png" group-title="PAKISTAN ➾ NEWS",PK | HUM NEWS HD
http://ip96.uk:8080/shakeelmirza/4110440/71178
#EXTINF:-1 tvg-id="" tvg-name="PK | METRO 1 NEWS" tvg-logo="" group-title="PAKISTAN ➾ NEWS",PK | METRO 1 NEWS
http://ip96.uk:8080/shakeelmirza/4110440/79852
#EXTINF:-1 tvg-id="" tvg-name="PK | KHYBER NEWS " tvg-logo="https://www.lyngsat.com/logo/tv/kk/khyber-news-pk.png" group-title="PAKISTAN ➾ NEWS",PK | KHYBER NEWS 
http://ip96.uk:8080/shakeelmirza/4110440/189485
#EXTINF:-1 tvg-id="" tvg-name="PK | SUCH NEWS" tvg-logo="" group-title="PAKISTAN ➾ NEWS",PK | SUCH NEWS
http://ip96.uk:8080/shakeelmirza/4110440/190144
#EXTINF:-1 tvg-id="" tvg-name="PK | ABN NWES HD" tvg-logo="" group-title="PAKISTAN ➾ NEWS",PK | ABN NWES HD
http://ip96.uk:8080/shakeelmirza/4110440/395096
#EXTINF:-1 tvg-id="" tvg-name="PK | CAPITAL NEWS" tvg-logo="" group-title="PAKISTAN ➾ NEWS",PK | CAPITAL NEWS
http://ip96.uk:8080/shakeelmirza/4110440/453158
#EXTINF:-1 tvg-id="" tvg-name="PK | NEO NEWS" tvg-logo="" group-title="PAKISTAN ➾ NEWS",PK | NEO NEWS
http://ip96.uk:8080/shakeelmirza/4110440/453383
#EXTINF:-1 tvg-id="" tvg-name="PK | GEO TEZ" tvg-logo="" group-title="PAKISTAN ➾ NEWS",PK | GEO TEZ
http://ip96.uk:8080/shakeelmirza/4110440/453385
#EXTINF:-1 tvg-id="" tvg-name="PK | VENUS NEWS" tvg-logo="" group-title="PAKISTAN ➾ NEWS",PK | VENUS NEWS
http://ip96.uk:8080/shakeelmirza/4110440/453386
#EXTINF:-1 tvg-id="" tvg-name="PK | WASEEB NEWS" tvg-logo="" group-title="PAKISTAN ➾ NEWS",PK | WASEEB NEWS
http://ip96.uk:8080/shakeelmirza/4110440/453388
#EXTINF:-1 tvg-id="" tvg-name="PK | K 21 NEWS" tvg-logo="" group-title="PAKISTAN ➾ NEWS",PK | K 21 NEWS
http://ip96.uk:8080/shakeelmirza/4110440/477746
#EXTINF:-1 tvg-id="" tvg-name="PK | CITY 21 NEWS" tvg-logo="" group-title="PAKISTAN ➾ NEWS",PK | CITY 21 NEWS
http://ip96.uk:8080/shakeelmirza/4110440/496973
#EXTINF:-1 tvg-id="" tvg-name="PK | 365 NEWS" tvg-logo="" group-title="PAKISTAN ➾ NEWS",PK | 365 NEWS
http://ip96.uk:8080/shakeelmirza/4110440/497542
#EXTINF:-1 tvg-id="" tvg-name="NL: 100%" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/bffcc3c709c2bd40611789a39eeaaa3b.png" group-title="Netherlands ➾ LifeStyle",NL: 100%
http://ip96.uk:8080/shakeelmirza/4110440/303553
#EXTINF:-1 tvg-id="" tvg-name="NL: AT 5" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/123ba982d5078b8e977adb6975c32847.png" group-title="Netherlands ➾ LifeStyle",NL: AT 5
http://ip96.uk:8080/shakeelmirza/4110440/303554
#EXTINF:-1 tvg-id="" tvg-name="NL: BBC First" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/0f1a360dbab999c2296a5b13e88a03f8.png" group-title="Netherlands ➾ LifeStyle",NL: BBC First
http://ip96.uk:8080/shakeelmirza/4110440/303555
#EXTINF:-1 tvg-id="" tvg-name="NL: Den Haag FM" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/5c5e2751644fed235c34f050491298a8.jpg" group-title="Netherlands ➾ LifeStyle",NL: Den Haag FM
http://ip96.uk:8080/shakeelmirza/4110440/303556
#EXTINF:-1 tvg-id="" tvg-name="NL: E!" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/9035544c803330fe1f310c1b8f2cb815.png" group-title="Netherlands ➾ LifeStyle",NL: E!
http://ip96.uk:8080/shakeelmirza/4110440/303557
#EXTINF:-1 tvg-id="" tvg-name="NL: Family 7" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/525b1fc36ef97d6279a9f10e8c0a1ed6.jpg" group-title="Netherlands ➾ LifeStyle",NL: Family 7
http://ip96.uk:8080/shakeelmirza/4110440/303558
#EXTINF:-1 tvg-id="" tvg-name="NL: FashionTV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-04/e7f4e403d0e813039d2341de729e35fe.jpg" group-title="Netherlands ➾ LifeStyle",NL: FashionTV
http://ip96.uk:8080/shakeelmirza/4110440/303559
#EXTINF:-1 tvg-id="" tvg-name="NL: FOX" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/98b8b417ca9318e67a9df00f63a49f01.png" group-title="Netherlands ➾ LifeStyle",NL: FOX
http://ip96.uk:8080/shakeelmirza/4110440/303560
#EXTINF:-1 tvg-id="" tvg-name="NL: Ideaal TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/a930874c646f5168ecb1fee26dc540ff.jpg" group-title="Netherlands ➾ LifeStyle",NL: Ideaal TV
http://ip96.uk:8080/shakeelmirza/4110440/303561
#EXTINF:-1 tvg-id="" tvg-name="NL: L1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/f2b5af462e47983e30dc5f5a13b1054d.png" group-title="Netherlands ➾ LifeStyle",NL: L1
http://ip96.uk:8080/shakeelmirza/4110440/303562
#EXTINF:-1 tvg-id="" tvg-name="NL: LOE TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/8734feeb5a7abd0a7d6b4a164b18f004.jpg" group-title="Netherlands ➾ LifeStyle",NL: LOE TV
http://ip96.uk:8080/shakeelmirza/4110440/303563
#EXTINF:-1 tvg-id="" tvg-name="NL: Net 5" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/3e7f9d6ad4d64b12323025bc1de68657.png" group-title="Netherlands ➾ LifeStyle",NL: Net 5
http://ip96.uk:8080/shakeelmirza/4110440/303564
#EXTINF:-1 tvg-id="" tvg-name="NL: NPO 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/93f0a511998e056a7c6c3e0fc3b49673.png" group-title="Netherlands ➾ LifeStyle",NL: NPO 1
http://ip96.uk:8080/shakeelmirza/4110440/303565
#EXTINF:-1 tvg-id="" tvg-name="NL: NPO 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/8e260f4f8c5b9194e6ea1870eb092245.png" group-title="Netherlands ➾ LifeStyle",NL: NPO 2
http://ip96.uk:8080/shakeelmirza/4110440/303566
#EXTINF:-1 tvg-id="" tvg-name="NL: NPO 3" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/22353ca0f895530a66d74cd71014ac94.png" group-title="Netherlands ➾ LifeStyle",NL: NPO 3
http://ip96.uk:8080/shakeelmirza/4110440/303567
#EXTINF:-1 tvg-id="" tvg-name="NL: NPO Extra 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/fd239dea33f16d1d850a4c4fbccb2709.png" group-title="Netherlands ➾ LifeStyle",NL: NPO Extra 1
http://ip96.uk:8080/shakeelmirza/4110440/303568
#EXTINF:-1 tvg-id="" tvg-name="NL: NPO Extra 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/a5c0eb4b7353ae40f2748d2c0b7f71cf.png" group-title="Netherlands ➾ LifeStyle",NL: NPO Extra 2
http://ip96.uk:8080/shakeelmirza/4110440/303569
#EXTINF:-1 tvg-id="" tvg-name="NL: OMROEP Brabant Radio" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-04/24333db82fead7c4efd5bb777175caa0.png" group-title="Netherlands ➾ LifeStyle",NL: OMROEP Brabant Radio
http://ip96.uk:8080/shakeelmirza/4110440/303570
#EXTINF:-1 tvg-id="" tvg-name="NL: OMROEP Brabant TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/3b1f45f9d6d30001001524fe07ae6078.png" group-title="Netherlands ➾ LifeStyle",NL: OMROEP Brabant TV
http://ip96.uk:8080/shakeelmirza/4110440/303571
#EXTINF:-1 tvg-id="" tvg-name="NL: RTL 4" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/0c8359f78ac722feb59712b7dbd7873f.png" group-title="Netherlands ➾ LifeStyle",NL: RTL 4
http://ip96.uk:8080/shakeelmirza/4110440/303572
#EXTINF:-1 tvg-id="" tvg-name="NL: RTL 5" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/db64fc6382c1c93587793d587ee08e61.png" group-title="Netherlands ➾ LifeStyle",NL: RTL 5
http://ip96.uk:8080/shakeelmirza/4110440/303573
#EXTINF:-1 tvg-id="" tvg-name="NL: RTL 8" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/cc528acd39a10ee0efb97f3c838d785d.png" group-title="Netherlands ➾ LifeStyle",NL: RTL 8
http://ip96.uk:8080/shakeelmirza/4110440/303574
#EXTINF:-1 tvg-id="" tvg-name="NL: RTV Amstelveen" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/7e570ad54806dac6629a35e83e747d7f.png" group-title="Netherlands ➾ LifeStyle",NL: RTV Amstelveen
http://ip96.uk:8080/shakeelmirza/4110440/303575
#EXTINF:-1 tvg-id="" tvg-name="NL: RTV Utrecht" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/d2a386193b75dc9d6797024f8b699741.png" group-title="Netherlands ➾ LifeStyle",NL: RTV Utrecht
http://ip96.uk:8080/shakeelmirza/4110440/303576
#EXTINF:-1 tvg-id="" tvg-name="NL: Salto 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/ca3ed9579a9dfe548b6ae8b9edd13446.png" group-title="Netherlands ➾ LifeStyle",NL: Salto 2
http://ip96.uk:8080/shakeelmirza/4110440/303577
#EXTINF:-1 tvg-id="" tvg-name="NL: SBS 6" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/8b9164e03bf9918e3224ea255d406bdb.png" group-title="Netherlands ➾ LifeStyle",NL: SBS 6
http://ip96.uk:8080/shakeelmirza/4110440/303578
#EXTINF:-1 tvg-id="" tvg-name="NL: SBS 9" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/6f259f52b792c3e705c190ba38f0416e.png" group-title="Netherlands ➾ LifeStyle",NL: SBS 9
http://ip96.uk:8080/shakeelmirza/4110440/303579
#EXTINF:-1 tvg-id="" tvg-name="NL: Star Channel" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Netherlands ➾ LifeStyle",NL: Star Channel
http://ip96.uk:8080/shakeelmirza/4110440/303580
#EXTINF:-1 tvg-id="" tvg-name="NL: TLC" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/9d921b0c063eecb2791636b6805bbc36.png" group-title="Netherlands ➾ LifeStyle",NL: TLC
http://ip96.uk:8080/shakeelmirza/4110440/303581
#EXTINF:-1 tvg-id="" tvg-name="NL: Travel Channel" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/5b8884450c102f2f0a63b04acb4a071d.png" group-title="Netherlands ➾ LifeStyle",NL: Travel Channel
http://ip96.uk:8080/shakeelmirza/4110440/303582
#EXTINF:-1 tvg-id="" tvg-name="NL: Travelxp" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-04/0081b5ba5a801942fa8477fc2f46143a.png" group-title="Netherlands ➾ LifeStyle",NL: Travelxp
http://ip96.uk:8080/shakeelmirza/4110440/303583
#EXTINF:-1 tvg-id="" tvg-name="NL: TV Ellef" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/8d897502ba79702984bf8120a3aff272.jpg" group-title="Netherlands ➾ LifeStyle",NL: TV Ellef
http://ip96.uk:8080/shakeelmirza/4110440/303584
#EXTINF:-1 tvg-id="" tvg-name="NL: TV Gelderland" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/1e1e42736ba1ccc940bad9962383565b.png" group-title="Netherlands ➾ LifeStyle",NL: TV Gelderland
http://ip96.uk:8080/shakeelmirza/4110440/303585
#EXTINF:-1 tvg-id="" tvg-name="NL: TV Oranje" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/3fae7a97cc432425071d92872f79c2fc.png" group-title="Netherlands ➾ LifeStyle",NL: TV Oranje
http://ip96.uk:8080/shakeelmirza/4110440/303586
#EXTINF:-1 tvg-id="" tvg-name="NL: 192 TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/f5667b9f3d2325f4fd3a189882794f86.png" group-title="Netherlands ➾ Music",NL: 192 TV
http://ip96.uk:8080/shakeelmirza/4110440/303587
#EXTINF:-1 tvg-id="" tvg-name="NL: Dance Television" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/45bd5ef29fe4b037291ee0da3f9295e6.png" group-title="Netherlands ➾ Music",NL: Dance Television
http://ip96.uk:8080/shakeelmirza/4110440/303588
#EXTINF:-1 tvg-id="" tvg-name="NL: MTV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/9a1c4d99aeabcc79410136e126394b86.png" group-title="Netherlands ➾ Music",NL: MTV
http://ip96.uk:8080/shakeelmirza/4110440/303589
#EXTINF:-1 tvg-id="" tvg-name="NL: MTV 90s" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2024-03/c31fea88f41d76e67d7d5087e298714c.jpg" group-title="Netherlands ➾ Music",NL: MTV 90s
http://ip96.uk:8080/shakeelmirza/4110440/303590
#EXTINF:-1 tvg-id="" tvg-name="NL: NickMusic" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/e2ddbfcd63a23f3e5184537fc9b6eb2b.png" group-title="Netherlands ➾ Music",NL: NickMusic
http://ip96.uk:8080/shakeelmirza/4110440/303591
#EXTINF:-1 tvg-id="" tvg-name="NL: RTV Maastricht" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/eaca7adfd8de319516f58a9377c0289c.png" group-title="Netherlands ➾ Music",NL: RTV Maastricht
http://ip96.uk:8080/shakeelmirza/4110440/303592
#EXTINF:-1 tvg-id="" tvg-name="NL: Salto Brasa Music" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/6e3926a730821d5cc6bc358dea335ae6.jpg" group-title="Netherlands ➾ Music",NL: Salto Brasa Music
http://ip96.uk:8080/shakeelmirza/4110440/303593
#EXTINF:-1 tvg-id="" tvg-name="NL: Slam" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/28b2c4d0befe4cd2819a23793dc9299c.png" group-title="Netherlands ➾ Music",NL: Slam
http://ip96.uk:8080/shakeelmirza/4110440/303594
#EXTINF:-1 tvg-id="" tvg-name="NL: Stingray Djazz" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/910f79800349d39aeebb3eb7777dc83b.png" group-title="Netherlands ➾ Music",NL: Stingray Djazz
http://ip96.uk:8080/shakeelmirza/4110440/303595
#EXTINF:-1 tvg-id="" tvg-name="NL: TV 538" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/41f24a4fe5fbeed7c3bfb1c6e3989365.png" group-title="Netherlands ➾ Music",NL: TV 538
http://ip96.uk:8080/shakeelmirza/4110440/303596
#EXTINF:-1 tvg-id="" tvg-name="NL: TV Noord" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/92e944d9769eca7309e19f78e5753f2d.png" group-title="Netherlands ➾ Music",NL: TV Noord
http://ip96.uk:8080/shakeelmirza/4110440/303597
#EXTINF:-1 tvg-id="" tvg-name="NL: Xite" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/08e0f3fc7bb2f2dd60a0fc1c4de69b21.png" group-title="Netherlands ➾ Music",NL: Xite
http://ip96.uk:8080/shakeelmirza/4110440/303598
#EXTINF:-1 tvg-id="" tvg-name="NL: 24 Kitchen" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/48fc951ba8625b250aaa89c3437b84f2.png" group-title="Netherlands ➾ Kids",NL: 24 Kitchen
http://ip96.uk:8080/shakeelmirza/4110440/303599
#EXTINF:-1 tvg-id="" tvg-name="NL: Baby TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/9d2ae2b0dd6e5b3545ab6d448e88f6bf.png" group-title="Netherlands ➾ Kids",NL: Baby TV
http://ip96.uk:8080/shakeelmirza/4110440/303600
#EXTINF:-1 tvg-id="" tvg-name="NL: Cartoonito" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-10/e5c5d73b6cdf974715cfb94d34b2bed7.svg" group-title="Netherlands ➾ Kids",NL: Cartoonito
http://ip96.uk:8080/shakeelmirza/4110440/303601
#EXTINF:-1 tvg-id="" tvg-name="NL: Disney Channel" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/9c99903730dcdd4202c8e2e14d9dfe3f.png" group-title="Netherlands ➾ Kids",NL: Disney Channel
http://ip96.uk:8080/shakeelmirza/4110440/303602
#EXTINF:-1 tvg-id="" tvg-name="NL: Disney Junior" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-01/8a91f712ecb8d6dbf56807d350172b04.png" group-title="Netherlands ➾ Kids",NL: Disney Junior
http://ip96.uk:8080/shakeelmirza/4110440/303603
#EXTINF:-1 tvg-id="" tvg-name="NL: Disney XD" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-01/cc5555cc94d474813edd2c5249a8f28a.png" group-title="Netherlands ➾ Kids",NL: Disney XD
http://ip96.uk:8080/shakeelmirza/4110440/303604
#EXTINF:-1 tvg-id="" tvg-name="NL: Duck TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/034b531c3e84f23ee277f826c3601ad1.png" group-title="Netherlands ➾ Kids",NL: Duck TV
http://ip96.uk:8080/shakeelmirza/4110440/303605
#EXTINF:-1 tvg-id="" tvg-name="NL: JimJam" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-04/9c8e5c87bb2b4c4a2f49d3329ebfa7bd.png" group-title="Netherlands ➾ Kids",NL: JimJam
http://ip96.uk:8080/shakeelmirza/4110440/303606
#EXTINF:-1 tvg-id="" tvg-name="NL: Nick Junior" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/e3993a8c6820eebd356320b3bb31949b.png" group-title="Netherlands ➾ Kids",NL: Nick Junior
http://ip96.uk:8080/shakeelmirza/4110440/303607
#EXTINF:-1 tvg-id="" tvg-name="NL: nickelodeon" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/f743eb5388e637bb20cbffb86681f3a7.png" group-title="Netherlands ➾ Kids",NL: nickelodeon
http://ip96.uk:8080/shakeelmirza/4110440/303608
#EXTINF:-1 tvg-id="" tvg-name="NL: Nicktoons" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/0c6810f05d683ea65466c31bfd5d8e8d.png" group-title="Netherlands ➾ Kids",NL: Nicktoons
http://ip96.uk:8080/shakeelmirza/4110440/303609
#EXTINF:-1 tvg-id="" tvg-name="NL: RTL Telekids" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/89b27a29046e9c6c52f785033cdc0e1e.jpg" group-title="Netherlands ➾ Kids",NL: RTL Telekids
http://ip96.uk:8080/shakeelmirza/4110440/303610
#EXTINF:-1 tvg-id="" tvg-name="NL: ANIMAL PLANET" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/a944b99e2459d9afe3ffdebd250cf9e6.png" group-title="Netherlands ➾ Nature",NL: ANIMAL PLANET
http://ip96.uk:8080/shakeelmirza/4110440/303611
#EXTINF:-1 tvg-id="" tvg-name="NL: Love Nature" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/8f0acca6449fd92e3d6e781404972e64.png" group-title="Netherlands ➾ Nature",NL: Love Nature
http://ip96.uk:8080/shakeelmirza/4110440/303612
#EXTINF:-1 tvg-id="" tvg-name="NL: NAT GEO Wild" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/87b97295a8979f02e78e291c0dc601d6.png" group-title="Netherlands ➾ Nature",NL: NAT GEO Wild
http://ip96.uk:8080/shakeelmirza/4110440/303613
#EXTINF:-1 tvg-id="" tvg-name="NL: BVN" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/f68c48332018b9bacc7edc5a360ec041.png" group-title="Netherlands",NL: BVN
http://ip96.uk:8080/shakeelmirza/4110440/303614
#EXTINF:-1 tvg-id="" tvg-name="NL: GO TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-07/f0665c2c2880059c5a13b00429239004.png" group-title="Netherlands",NL: GO TV
http://ip96.uk:8080/shakeelmirza/4110440/303615
#EXTINF:-1 tvg-id="" tvg-name="NL: Insight" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/cb0425ed069f89a61b5fc085bb968763.png" group-title="Netherlands",NL: Insight
http://ip96.uk:8080/shakeelmirza/4110440/303616
#EXTINF:-1 tvg-id="" tvg-name="NL: Jin TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-12/92de79b14657c1f963432fca7295df0c.png" group-title="Netherlands",NL: Jin TV
http://ip96.uk:8080/shakeelmirza/4110440/303617
#EXTINF:-1 tvg-id="" tvg-name="NL: Meer TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-06/af3b4646046a63475e89bd99c2e313d9.jpg" group-title="Netherlands",NL: Meer TV
http://ip96.uk:8080/shakeelmirza/4110440/303618
#EXTINF:-1 tvg-id="" tvg-name="NL: NPO Zapp" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Netherlands",NL: NPO Zapp
http://ip96.uk:8080/shakeelmirza/4110440/303619
#EXTINF:-1 tvg-id="" tvg-name="NL: OMROEP Flevoland TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/304ad0ac5810f2396984e9a39acad88a.png" group-title="Netherlands",NL: OMROEP Flevoland TV
http://ip96.uk:8080/shakeelmirza/4110440/303620
#EXTINF:-1 tvg-id="" tvg-name="NL: OMROEP Fryslan TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/9e04a4015ef21a0e1c83984a768722d3.png" group-title="Netherlands",NL: OMROEP Fryslan TV
http://ip96.uk:8080/shakeelmirza/4110440/303621
#EXTINF:-1 tvg-id="" tvg-name="NL: OMROEP Hulst TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/9125dec192f2e4768755b2f7c401b56f.jpg" group-title="Netherlands",NL: OMROEP Hulst TV
http://ip96.uk:8080/shakeelmirza/4110440/303622
#EXTINF:-1 tvg-id="" tvg-name="NL: OMROEP P&M TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/0343c4e9f71451fb456bbe601da323ff.png" group-title="Netherlands",NL: OMROEP P&M TV
http://ip96.uk:8080/shakeelmirza/4110440/303623
#EXTINF:-1 tvg-id="" tvg-name="NL: OMROEP Tilburg" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Netherlands",NL: OMROEP Tilburg
http://ip96.uk:8080/shakeelmirza/4110440/303624
#EXTINF:-1 tvg-id="" tvg-name="NL: OMROEP West" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/3dfe496811599e75dae7f8757f1ee956.png" group-title="Netherlands",NL: OMROEP West
http://ip96.uk:8080/shakeelmirza/4110440/303625
#EXTINF:-1 tvg-id="" tvg-name="NL: OMROEP Zeeland TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/8f7d909e2c69494275d5edaf5fcff0ec.png" group-title="Netherlands",NL: OMROEP Zeeland TV
http://ip96.uk:8080/shakeelmirza/4110440/303626
#EXTINF:-1 tvg-id="" tvg-name="NL: Omrop Fryslân TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-10/e8e00aed7858474306d219ba51ec044e.svg" group-title="Netherlands",NL: Omrop Fryslân TV
http://ip96.uk:8080/shakeelmirza/4110440/303627
#EXTINF:-1 tvg-id="" tvg-name="NL: ORTS" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-04/63759785b600ab4fc58068bf4610213c.png" group-title="Netherlands",NL: ORTS
http://ip96.uk:8080/shakeelmirza/4110440/303628
#EXTINF:-1 tvg-id="" tvg-name="NL: Out TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/fb65344582a88c41423ff99832dc20c3.jpg" group-title="Netherlands",NL: Out TV
http://ip96.uk:8080/shakeelmirza/4110440/303629
#EXTINF:-1 tvg-id="" tvg-name="NL: Pebble TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/87e9d6b2647bbc733411179683a3897b.jpg" group-title="Netherlands",NL: Pebble TV
http://ip96.uk:8080/shakeelmirza/4110440/303630
#EXTINF:-1 tvg-id="" tvg-name="NL: Qmusic" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-04/51e6c79dae9887ac62f40e679af727b2.png" group-title="Netherlands",NL: Qmusic
http://ip96.uk:8080/shakeelmirza/4110440/303631
#EXTINF:-1 tvg-id="" tvg-name="NL: Radio 350" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/40a0091411f39473f4ba9bbc5c78fc82.jpg" group-title="Netherlands",NL: Radio 350
http://ip96.uk:8080/shakeelmirza/4110440/303632
#EXTINF:-1 tvg-id="" tvg-name="NL: Radio VOS FM" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-06/27811304041ce72da3b6ebd1f31d64a4.jpg" group-title="Netherlands",NL: Radio VOS FM
http://ip96.uk:8080/shakeelmirza/4110440/303633
#EXTINF:-1 tvg-id="" tvg-name="NL: Redbox ACTIE 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-07/db55aa4a3d0b9358fe25a95c49ac2b87.jpg" group-title="Netherlands",NL: Redbox ACTIE 1
http://ip96.uk:8080/shakeelmirza/4110440/303634
#EXTINF:-1 tvg-id="" tvg-name="NL: Redbox ACTIE 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-07/6e75838d15d7b0cc1e5b10bba657ff7f.jpg" group-title="Netherlands",NL: Redbox ACTIE 2
http://ip96.uk:8080/shakeelmirza/4110440/303635
#EXTINF:-1 tvg-id="" tvg-name="NL: Redbox ACTIE 3" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-07/a9509a1032c6d24b61bb7bd03ebb7a83.jpg" group-title="Netherlands",NL: Redbox ACTIE 3
http://ip96.uk:8080/shakeelmirza/4110440/303636
#EXTINF:-1 tvg-id="" tvg-name="NL: Redbox ANIMATIE 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-07/2ead34d1bee12c2a497f693332b621ab.jpg" group-title="Netherlands",NL: Redbox ANIMATIE 1
http://ip96.uk:8080/shakeelmirza/4110440/303637
#EXTINF:-1 tvg-id="" tvg-name="NL: Redbox ANIMATIE 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-07/a927733542cbaa2484e066e4620e00c7.jpg" group-title="Netherlands",NL: Redbox ANIMATIE 2
http://ip96.uk:8080/shakeelmirza/4110440/303638
#EXTINF:-1 tvg-id="" tvg-name="NL: Redbox ANIMATIE 3" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-07/67e754f274bdde359e2bf66d4788e5dd.jpg" group-title="Netherlands",NL: Redbox ANIMATIE 3
http://ip96.uk:8080/shakeelmirza/4110440/303639
#EXTINF:-1 tvg-id="" tvg-name="NL: Redbox CONCERT" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-07/f7d22f30c9c715aa99e213cacf09b5bd.jpg" group-title="Netherlands",NL: Redbox CONCERT
http://ip96.uk:8080/shakeelmirza/4110440/303640
#EXTINF:-1 tvg-id="" tvg-name="NL: Redbox DRAMATIC 1" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Netherlands",NL: Redbox DRAMATIC 1
http://ip96.uk:8080/shakeelmirza/4110440/303641
#EXTINF:-1 tvg-id="" tvg-name="NL: Redbox HORROR 1" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Netherlands",NL: Redbox HORROR 1
http://ip96.uk:8080/shakeelmirza/4110440/303642
#EXTINF:-1 tvg-id="" tvg-name="NL: Redbox HORROR 2" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Netherlands",NL: Redbox HORROR 2
http://ip96.uk:8080/shakeelmirza/4110440/303643
#EXTINF:-1 tvg-id="" tvg-name="NL: Redbox NIEUWE FILMS" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Netherlands",NL: Redbox NIEUWE FILMS
http://ip96.uk:8080/shakeelmirza/4110440/303644
#EXTINF:-1 tvg-id="" tvg-name="NL: Redbox sci-fi 1" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Netherlands",NL: Redbox sci-fi 1
http://ip96.uk:8080/shakeelmirza/4110440/303645
#EXTINF:-1 tvg-id="" tvg-name="NL: Redbox sci-fi 2" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Netherlands",NL: Redbox sci-fi 2
http://ip96.uk:8080/shakeelmirza/4110440/303646
#EXTINF:-1 tvg-id="" tvg-name="NL: Redbox TEKEN FILM" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Netherlands",NL: Redbox TEKEN FILM
http://ip96.uk:8080/shakeelmirza/4110440/303647
#EXTINF:-1 tvg-id="" tvg-name="NL: Redbox THRILLER 2" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Netherlands",NL: Redbox THRILLER 2
http://ip96.uk:8080/shakeelmirza/4110440/303648
#EXTINF:-1 tvg-id="" tvg-name="NL: Redbox THRILLER 3" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Netherlands",NL: Redbox THRILLER 3
http://ip96.uk:8080/shakeelmirza/4110440/303649
#EXTINF:-1 tvg-id="" tvg-name="NL: Regio TV Nieuws" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/17d5b0a02568bd15449bddfdbc003469.jpg" group-title="Netherlands",NL: Regio TV Nieuws
http://ip96.uk:8080/shakeelmirza/4110440/303650
#EXTINF:-1 tvg-id="" tvg-name="NL: RTL" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Netherlands",NL: RTL
http://ip96.uk:8080/shakeelmirza/4110440/303651
#EXTINF:-1 tvg-id="" tvg-name="NL: RTL Zwee" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-07/558c4327ac44b5e63cde06e663277888.svg" group-title="Netherlands",NL: RTL Zwee
http://ip96.uk:8080/shakeelmirza/4110440/303652
#EXTINF:-1 tvg-id="" tvg-name="NL: RTV Arnhem" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/f25d087f6c95f259d8c6dc9053b70389.jpg" group-title="Netherlands",NL: RTV Arnhem
http://ip96.uk:8080/shakeelmirza/4110440/303653
#EXTINF:-1 tvg-id="" tvg-name="NL: RTV Dordrecht" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/c023856ebd4fdd99423cacc9585f2bc7.png" group-title="Netherlands",NL: RTV Dordrecht
http://ip96.uk:8080/shakeelmirza/4110440/303654
#EXTINF:-1 tvg-id="" tvg-name="NL: RTV NOF 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/072caff996526eca89d630627f709cc1.jpg" group-title="Netherlands",NL: RTV NOF 1
http://ip96.uk:8080/shakeelmirza/4110440/303655
#EXTINF:-1 tvg-id="" tvg-name="NL: RTV Noordoost Friesland" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/70886fea426d50d5cb39744f1b48c193.jpg" group-title="Netherlands",NL: RTV Noordoost Friesland
http://ip96.uk:8080/shakeelmirza/4110440/303656
#EXTINF:-1 tvg-id="" tvg-name="NL: RTV Purmerend" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/ebdfc3dbfd218ca0325381af1994c717.jpg" group-title="Netherlands",NL: RTV Purmerend
http://ip96.uk:8080/shakeelmirza/4110440/303657
#EXTINF:-1 tvg-id="" tvg-name="NL: RTV Rijnstreek TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/05c4e184d055fae06488063bdc7f2bda.png" group-title="Netherlands",NL: RTV Rijnstreek TV
http://ip96.uk:8080/shakeelmirza/4110440/303658
#EXTINF:-1 tvg-id="" tvg-name="NL: RTV Slingeland" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/1779ee337d47cc9c6657670061d0f2fc.jpg" group-title="Netherlands",NL: RTV Slingeland
http://ip96.uk:8080/shakeelmirza/4110440/303659
#EXTINF:-1 tvg-id="" tvg-name="NL: Salto MA Live" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Netherlands",NL: Salto MA Live
http://ip96.uk:8080/shakeelmirza/4110440/303660
#EXTINF:-1 tvg-id="" tvg-name="NL: Samen1 TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/ec0e0bc20a473a09b8f216f59dd4a7c2.jpg" group-title="Netherlands",NL: Samen1 TV
http://ip96.uk:8080/shakeelmirza/4110440/303661
#EXTINF:-1 tvg-id="" tvg-name="NL: Stingray Lite TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-06/46db2960cd91ec0e7d38f60bb33e3321.png" group-title="Netherlands",NL: Stingray Lite TV
http://ip96.uk:8080/shakeelmirza/4110440/303662
#EXTINF:-1 tvg-id="" tvg-name="NL: Streek TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/f6fb57ec7c6088b9d9811f0a352149c1.png" group-title="Netherlands",NL: Streek TV
http://ip96.uk:8080/shakeelmirza/4110440/303663
#EXTINF:-1 tvg-id="" tvg-name="NL: TV Oost" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/80a8059507db7a71a4bf60ad441295f5.png" group-title="Netherlands",NL: TV Oost
http://ip96.uk:8080/shakeelmirza/4110440/303664
#EXTINF:-1 tvg-id="" tvg-name="NL: TV Rijnmond" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/f16bc7c8169775b26a161eeb9c28b894.png" group-title="Netherlands",NL: TV Rijnmond
http://ip96.uk:8080/shakeelmirza/4110440/303665
#EXTINF:-1 tvg-id="" tvg-name="NL: UStad" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/371ae590fbd3c697bc552cac7f4ee24c.jpg" group-title="Netherlands",NL: UStad
http://ip96.uk:8080/shakeelmirza/4110440/303666
#EXTINF:-1 tvg-id="" tvg-name="NL: Vechtdal TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/a3ab41419cf1128fd54e73178073310e.jpg" group-title="Netherlands",NL: Vechtdal TV
http://ip96.uk:8080/shakeelmirza/4110440/303667
#EXTINF:-1 tvg-id="" tvg-name="NL: WOS TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/47a9390ad3820a6f0273a9017a532930.jpg" group-title="Netherlands",NL: WOS TV
http://ip96.uk:8080/shakeelmirza/4110440/303668
#EXTINF:-1 tvg-id="" tvg-name="NL: Xon" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/6666c720a4fa72d14164d84cd8aba4b9.png" group-title="Netherlands",NL: Xon
http://ip96.uk:8080/shakeelmirza/4110440/303669
#EXTINF:-1 tvg-id="" tvg-name="NL: Cartoon Network" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/7adf096442e7c93d2660b9edf0681524.png" group-title="Netherlands ➾ Movie",NL: Cartoon Network
http://ip96.uk:8080/shakeelmirza/4110440/303670
#EXTINF:-1 tvg-id="" tvg-name="NL: CBS Reality" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/0de7f64b35817bd2529f4277ab304614.png" group-title="Netherlands ➾ Movie",NL: CBS Reality
http://ip96.uk:8080/shakeelmirza/4110440/303671
#EXTINF:-1 tvg-id="" tvg-name="NL: Comedy Central" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/6332625a1321173def84b86366f405a3.png" group-title="Netherlands ➾ Movie",NL: Comedy Central
http://ip96.uk:8080/shakeelmirza/4110440/303672
#EXTINF:-1 tvg-id="" tvg-name="NL: FILM1 Action" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/bbb72019afc0bb68a1e0cb169cbe9658.png" group-title="Netherlands ➾ Movie",NL: FILM1 Action
http://ip96.uk:8080/shakeelmirza/4110440/303673
#EXTINF:-1 tvg-id="" tvg-name="NL: FILM1 Drama" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/1438b65b7e70594a2b2d3b87c8198282.png" group-title="Netherlands ➾ Movie",NL: FILM1 Drama
http://ip96.uk:8080/shakeelmirza/4110440/303674
#EXTINF:-1 tvg-id="" tvg-name="NL: FILM1 Family" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/9df201e38997c3ae43d52277386dc1eb.png" group-title="Netherlands ➾ Movie",NL: FILM1 Family
http://ip96.uk:8080/shakeelmirza/4110440/303675
#EXTINF:-1 tvg-id="" tvg-name="NL: FILM1 Premiere" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/f97197873fd9f68fc7a291e3667e66cf.png" group-title="Netherlands ➾ Movie",NL: FILM1 Premiere
http://ip96.uk:8080/shakeelmirza/4110440/303676
#EXTINF:-1 tvg-id="" tvg-name="NL: HBO 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/e848f0d0f5cb26c64e8e6f971d62b570.png" group-title="Netherlands ➾ Movie",NL: HBO 2
http://ip96.uk:8080/shakeelmirza/4110440/303677
#EXTINF:-1 tvg-id="" tvg-name="NL: HBO 3" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/989860110b8b97df80269375b3b86b20.png" group-title="Netherlands ➾ Movie",NL: HBO 3
http://ip96.uk:8080/shakeelmirza/4110440/303678
#EXTINF:-1 tvg-id="" tvg-name="NL: RTL 7" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/21bc983e3f69f052ec62e1ae72ccb0bd.png" group-title="Netherlands ➾ Movie",NL: RTL 7
http://ip96.uk:8080/shakeelmirza/4110440/303679
#EXTINF:-1 tvg-id="" tvg-name="NL: RTL Crime" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/7b46d3a86ac7b184b8347652fc7d3887.png" group-title="Netherlands ➾ Movie",NL: RTL Crime
http://ip96.uk:8080/shakeelmirza/4110440/303680
#EXTINF:-1 tvg-id="" tvg-name="NL: RTL Lounge" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/1ed56734e24a7ce281c601503cf6c57a.png" group-title="Netherlands ➾ Movie",NL: RTL Lounge
http://ip96.uk:8080/shakeelmirza/4110440/303681
#EXTINF:-1 tvg-id="" tvg-name="NL: ESPN" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/fba7aa6abb3a938d6d2da99a29f57a8c.png" group-title="Netherlands ➾ Sports",NL: ESPN
http://ip96.uk:8080/shakeelmirza/4110440/303682
#EXTINF:-1 tvg-id="" tvg-name="NL: ESPN 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/f8d4dbda121c0cfc982516038b068e70.png" group-title="Netherlands ➾ Sports",NL: ESPN 2
http://ip96.uk:8080/shakeelmirza/4110440/303683
#EXTINF:-1 tvg-id="" tvg-name="NL: ESPN 3" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/60f126e910a86dc97e8c75e0e799fad0.png" group-title="Netherlands ➾ Sports",NL: ESPN 3
http://ip96.uk:8080/shakeelmirza/4110440/303684
#EXTINF:-1 tvg-id="" tvg-name="NL: ESPN 4" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/25459a2e8dd1ae1419024458ee7d4418.png" group-title="Netherlands ➾ Sports",NL: ESPN 4
http://ip96.uk:8080/shakeelmirza/4110440/303685
#EXTINF:-1 tvg-id="" tvg-name="NL: Eurosport 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/d5e361ea894402e5f0a3d02825e0c1c6.png" group-title="Netherlands ➾ Sports",NL: Eurosport 1
http://ip96.uk:8080/shakeelmirza/4110440/303686
#EXTINF:-1 tvg-id="" tvg-name="NL: Eurosport 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/7bea1ec666c4776b520707139174f0c6.png" group-title="Netherlands ➾ Sports",NL: Eurosport 2
http://ip96.uk:8080/shakeelmirza/4110440/303687
#EXTINF:-1 tvg-id="" tvg-name="NL: Extreme Sports Channel" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/aa0fc79ca9161e91df4ca4c235feb2d6.png" group-title="Netherlands ➾ Sports",NL: Extreme Sports Channel
http://ip96.uk:8080/shakeelmirza/4110440/303688
#EXTINF:-1 tvg-id="" tvg-name="NL: Ziggo Sport" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Netherlands ➾ Sports",NL: Ziggo Sport
http://ip96.uk:8080/shakeelmirza/4110440/303689
#EXTINF:-1 tvg-id="" tvg-name="NL: Ziggo Sport Docu" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/addd41b3b4e714bc55d097a2d477fbdd.jpg" group-title="Netherlands ➾ Sports",NL: Ziggo Sport Docu
http://ip96.uk:8080/shakeelmirza/4110440/303690
#EXTINF:-1 tvg-id="" tvg-name="NL: Ziggo Sport Racing" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/478f67bb97135c0385065d63c872a9a5.png" group-title="Netherlands ➾ Sports",NL: Ziggo Sport Racing
http://ip96.uk:8080/shakeelmirza/4110440/303692
#EXTINF:-1 tvg-id="" tvg-name="NL: Ziggo Sport Select" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/d1bfb1240f4d7a3afa266815fff73b64.png" group-title="Netherlands ➾ Sports",NL: Ziggo Sport Select
http://ip96.uk:8080/shakeelmirza/4110440/303693
#EXTINF:-1 tvg-id="" tvg-name="NL: Ziggo Sport Tennis" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/51e38af8161b067a2fbcba9d806eab67.png" group-title="Netherlands ➾ Sports",NL: Ziggo Sport Tennis
http://ip96.uk:8080/shakeelmirza/4110440/303694
#EXTINF:-1 tvg-id="" tvg-name="NL: Ziggo Sport Voetbal" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/e58e720485579902f5b43088a245d978.png" group-title="Netherlands ➾ Sports",NL: Ziggo Sport Voetbal
http://ip96.uk:8080/shakeelmirza/4110440/303695
#EXTINF:-1 tvg-id="" tvg-name="NL: Crime+ Investigation" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/e8abe1e40f845ca66fe7a8891c0c2cc3.png" group-title="Netherlands ➾ Documentary",NL: Crime+ Investigation
http://ip96.uk:8080/shakeelmirza/4110440/303696
#EXTINF:-1 tvg-id="" tvg-name="NL: Discovery Science" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/52c988727efb4d35bd19747f5b0da223.png" group-title="Netherlands ➾ Documentary",NL: Discovery Science
http://ip96.uk:8080/shakeelmirza/4110440/303697
#EXTINF:-1 tvg-id="" tvg-name="NL: Discovery World" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/95e83794b755b0154e9757a375be0fe9.png" group-title="Netherlands ➾ Documentary",NL: Discovery World
http://ip96.uk:8080/shakeelmirza/4110440/303698
#EXTINF:-1 tvg-id="" tvg-name="NL: History" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/17617c30b8b3d361d14ae777adc8e6ac.png" group-title="Netherlands ➾ Documentary",NL: History
http://ip96.uk:8080/shakeelmirza/4110440/303699
#EXTINF:-1 tvg-id="" tvg-name="NL: Investigation Discovery" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/b0ebe4fbb7f984273063d65c3ae8946b.png" group-title="Netherlands ➾ Documentary",NL: Investigation Discovery
http://ip96.uk:8080/shakeelmirza/4110440/303700
#EXTINF:-1 tvg-id="" tvg-name="NL: NAT GEO" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/bc00af729a5e1c577361ae06ebba02dd.png" group-title="Netherlands ➾ Documentary",NL: NAT GEO
http://ip96.uk:8080/shakeelmirza/4110440/303701
#EXTINF:-1 tvg-id="" tvg-name="NL: NPO Nieuws" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/3f447a7ac4eaf4488a3726318024d041.png" group-title="Netherlands ➾ News",NL: NPO Nieuws
http://ip96.uk:8080/shakeelmirza/4110440/303702
#EXTINF:-1 tvg-id="" tvg-name="NL: NPO Politiek" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/3ceb32c8b193b3a0d16717bae9dccc1d.png" group-title="Netherlands ➾ News",NL: NPO Politiek
http://ip96.uk:8080/shakeelmirza/4110440/303703
#EXTINF:-1 tvg-id="" tvg-name="NL: ONS" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/eb830bf9ca66e3f2a9a11086ddc76214.png" group-title="Netherlands ➾ News",NL: ONS
http://ip96.uk:8080/shakeelmirza/4110440/303704
#EXTINF:-1 tvg-id="" tvg-name="NL: Open Rotterdam" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/1ab2f05f9123678952e81c65d5f87b8e.jpg" group-title="Netherlands ➾ News",NL: Open Rotterdam
http://ip96.uk:8080/shakeelmirza/4110440/303705
#EXTINF:-1 tvg-id="" tvg-name="NL: RTL Z" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/6f6a1e92e1e20ca67fb90f478d0d9f70.png" group-title="Netherlands ➾ News",NL: RTL Z
http://ip96.uk:8080/shakeelmirza/4110440/303706
#EXTINF:-1 tvg-id="" tvg-name="NL: RTV Connect TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/c16deb741d3f6d1c60b7bddc3d85e652.png" group-title="Netherlands ➾ News",NL: RTV Connect TV
http://ip96.uk:8080/shakeelmirza/4110440/303707
#EXTINF:-1 tvg-id="" tvg-name="NL: RTV Drenthe" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/a70eaa8e35ec82deee2b160a75b9f426.png" group-title="Netherlands ➾ News",NL: RTV Drenthe
http://ip96.uk:8080/shakeelmirza/4110440/303708
#EXTINF:-1 tvg-id="" tvg-name="NL: RTV Noord Extra" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-04/675d9e2010797b2686bb3cc3847b9f7c.png" group-title="Netherlands ➾ News",NL: RTV Noord Extra
http://ip96.uk:8080/shakeelmirza/4110440/303709
#EXTINF:-1 tvg-id="" tvg-name="NL: ZuidWest TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/82fb3c852e2f8d0160a1ff29dd729636.jpg" group-title="Netherlands ➾ News",NL: ZuidWest TV
http://ip96.uk:8080/shakeelmirza/4110440/303710
#EXTINF:-1 tvg-id="" tvg-name="SI: Baby TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/1ea5b49b2a1aa244a44b7fa624d19cab.png" group-title="Slovenia",SI: Baby TV
http://ip96.uk:8080/shakeelmirza/4110440/500228
#EXTINF:-1 tvg-id="" tvg-name="SI: Brio" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/1b73884e5a8a3749363d0cb595a2966f.png" group-title="Slovenia",SI: Brio
http://ip96.uk:8080/shakeelmirza/4110440/500229
#EXTINF:-1 tvg-id="" tvg-name="SI: Diva" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/06ff13a9796c02e03f4275b705f55dd2.png" group-title="Slovenia",SI: Diva
http://ip96.uk:8080/shakeelmirza/4110440/500230
#EXTINF:-1 tvg-id="" tvg-name="SI: Epic Drama" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/7d5937d868c3a8d229720bd402cbc6ff.png" group-title="Slovenia",SI: Epic Drama
http://ip96.uk:8080/shakeelmirza/4110440/500231
#EXTINF:-1 tvg-id="" tvg-name="SI: Eurosport 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/1609aae69ac2fbfdab0fbc5de966a322.png" group-title="Slovenia",SI: Eurosport 2
http://ip96.uk:8080/shakeelmirza/4110440/500232
#EXTINF:-1 tvg-id="" tvg-name="SI: Exodus TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/aea29a3b73acefd8097fca1d57784806.jpg" group-title="Slovenia",SI: Exodus TV
http://ip96.uk:8080/shakeelmirza/4110440/500233
#EXTINF:-1 tvg-id="" tvg-name="SI: Gold" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-04/0af03f88d2c2129d1a82752233647b4b.png" group-title="Slovenia",SI: Gold
http://ip96.uk:8080/shakeelmirza/4110440/500234
#EXTINF:-1 tvg-id="" tvg-name="SI: GTV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/7d657495529544d8580653011f55f83b.jpg" group-title="Slovenia",SI: GTV
http://ip96.uk:8080/shakeelmirza/4110440/500235
#EXTINF:-1 tvg-id="" tvg-name="SI: HBO" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/5995321dbdd11f674d161aa301756cdb.png" group-title="Slovenia",SI: HBO
http://ip96.uk:8080/shakeelmirza/4110440/500236
#EXTINF:-1 tvg-id="" tvg-name="SI: HBO 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/7b86efb375bf1d609579215965ca2bc5.png" group-title="Slovenia",SI: HBO 2
http://ip96.uk:8080/shakeelmirza/4110440/500237
#EXTINF:-1 tvg-id="" tvg-name="SI: Kanal A" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/5ce2c2fca508e549a9114b834689eb21.png" group-title="Slovenia",SI: Kanal A
http://ip96.uk:8080/shakeelmirza/4110440/500238
#EXTINF:-1 tvg-id="" tvg-name="SI: MMC TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-04/113cb66d5fc4342c2009ae7e3b617a43.jpeg" group-title="Slovenia",SI: MMC TV
http://ip96.uk:8080/shakeelmirza/4110440/500239
#EXTINF:-1 tvg-id="" tvg-name="SI: N1 SLOVENSKA" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Slovenia",SI: N1 SLOVENSKA
http://ip96.uk:8080/shakeelmirza/4110440/500240
#EXTINF:-1 tvg-id="" tvg-name="SI: Nova 24 TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/29ff516bc19e685b0f3f825648957f5f.png" group-title="Slovenia",SI: Nova 24 TV
http://ip96.uk:8080/shakeelmirza/4110440/500241
#EXTINF:-1 tvg-id="" tvg-name="SI: Oto" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/7b33ab5df196365034d68a501641169d.png" group-title="Slovenia",SI: Oto
http://ip96.uk:8080/shakeelmirza/4110440/500242
#EXTINF:-1 tvg-id="" tvg-name="SI: Planet Eva" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/539a14f93dcd3480017afda10530c83e.jpg" group-title="Slovenia",SI: Planet Eva
http://ip96.uk:8080/shakeelmirza/4110440/500243
#EXTINF:-1 tvg-id="" tvg-name="SI: Planet TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/77fa1035422b34879222b4327fc52781.jpg" group-title="Slovenia",SI: Planet TV
http://ip96.uk:8080/shakeelmirza/4110440/500244
#EXTINF:-1 tvg-id="" tvg-name="SI: Pop Kino" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-09/83a1bee1bab80283fa8189dcc2acfc5c.png" group-title="Slovenia",SI: Pop Kino
http://ip96.uk:8080/shakeelmirza/4110440/500245
#EXTINF:-1 tvg-id="" tvg-name="SI: Pop TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/e39bd7b8055e2702ab183377e4e7def0.png" group-title="Slovenia",SI: Pop TV
http://ip96.uk:8080/shakeelmirza/4110440/500246
#EXTINF:-1 tvg-id="" tvg-name="SI: Sport Klub 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/41fc4a842069711f567566194b20eb61.png" group-title="Slovenia",SI: Sport Klub 1
http://ip96.uk:8080/shakeelmirza/4110440/500247
#EXTINF:-1 tvg-id="" tvg-name="SI: Sport Klub 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/e2bba67ad81133a03dfda6bb8275463a.png" group-title="Slovenia",SI: Sport Klub 2
http://ip96.uk:8080/shakeelmirza/4110440/500248
#EXTINF:-1 tvg-id="" tvg-name="SI: Sport Klub 3" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/db7d048247fc315beb9fc4c8627982bf.png" group-title="Slovenia",SI: Sport Klub 3
http://ip96.uk:8080/shakeelmirza/4110440/500249
#EXTINF:-1 tvg-id="" tvg-name="SI: Sport Klub 4" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-10/b941cc4cd2c00de473ec507a99c959e7.jpg" group-title="Slovenia",SI: Sport Klub 4
http://ip96.uk:8080/shakeelmirza/4110440/500250
#EXTINF:-1 tvg-id="" tvg-name="SI: Sport Klub 5" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Slovenia",SI: Sport Klub 5
http://ip96.uk:8080/shakeelmirza/4110440/500251
#EXTINF:-1 tvg-id="" tvg-name="SI: Sport Klub Golf" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-10/ae9aa3e191f7b342791dc7259fea9e86.png" group-title="Slovenia",SI: Sport Klub Golf
http://ip96.uk:8080/shakeelmirza/4110440/500252
#EXTINF:-1 tvg-id="" tvg-name="SI: SPORT TV 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/85f882164e1d5497fc1810d06fd4cdc1.png" group-title="Slovenia",SI: SPORT TV 1
http://ip96.uk:8080/shakeelmirza/4110440/500253
#EXTINF:-1 tvg-id="" tvg-name="SI: SPORT TV 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/55eb3f8575337de6555b01d2b1e4c402.jpg" group-title="Slovenia",SI: SPORT TV 2
http://ip96.uk:8080/shakeelmirza/4110440/500254
#EXTINF:-1 tvg-id="" tvg-name="SI: SPORT TV 3" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/b66bf39e8b5ab24bb6635b5e5d907f8f.png" group-title="Slovenia",SI: SPORT TV 3
http://ip96.uk:8080/shakeelmirza/4110440/500255
#EXTINF:-1 tvg-id="" tvg-name="SI: Star Channel" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2024-05/dd51f2b1731ae7eaec11972ba96b30f2.png" group-title="Slovenia",SI: Star Channel
http://ip96.uk:8080/shakeelmirza/4110440/500256
#EXTINF:-1 tvg-id="" tvg-name="SI: Star Crime" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2024-08/7e7aa4d61aef5b233ea5be319017e92e.png" group-title="Slovenia",SI: Star Crime
http://ip96.uk:8080/shakeelmirza/4110440/500257
#EXTINF:-1 tvg-id="" tvg-name="SI: Star Movies" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2024-08/0312bb63186e1dd63c42f5bf6b7714cc.png" group-title="Slovenia",SI: Star Movies
http://ip96.uk:8080/shakeelmirza/4110440/500258
#EXTINF:-1 tvg-id="" tvg-name="SI: Trzic TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/acfb48f2d9231f5f747928af36e0d362.jpg" group-title="Slovenia",SI: Trzic TV
http://ip96.uk:8080/shakeelmirza/4110440/500259
#EXTINF:-1 tvg-id="" tvg-name="SI: TV Koper Capodistria" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-08/914d651bc9f60461c386df0fb2406667.png" group-title="Slovenia",SI: TV Koper Capodistria
http://ip96.uk:8080/shakeelmirza/4110440/500260
#EXTINF:-1 tvg-id="" tvg-name="SI: TV Maribor" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/9e0e18f04d681997dfebe2a2d48e478f.jpg" group-title="Slovenia",SI: TV Maribor
http://ip96.uk:8080/shakeelmirza/4110440/500261
#EXTINF:-1 tvg-id="" tvg-name="SI: TV Slovenija 1 (SLO 1)" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/c39056eff736bca556db3146a2dd1780.png" group-title="Slovenia",SI: TV Slovenija 1 (SLO 1)
http://ip96.uk:8080/shakeelmirza/4110440/500262
#EXTINF:-1 tvg-id="" tvg-name="SI: TV Slovenija 2 (SLO 2)" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/78b4ca2b12512ae1fa4c28f43052e703.png" group-title="Slovenia",SI: TV Slovenija 2 (SLO 2)
http://ip96.uk:8080/shakeelmirza/4110440/500263
#EXTINF:-1 tvg-id="" tvg-name="SI: TV Slovenija 3 (SLO 3)" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/688487ac7c3f186a363cad56efd6977d.png" group-title="Slovenia",SI: TV Slovenija 3 (SLO 3)
http://ip96.uk:8080/shakeelmirza/4110440/500264
#EXTINF:-1 tvg-id="" tvg-name="SI: TVDX" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/53b83eb32ec5cf329b1b0d258ceb1785.jpg" group-title="Slovenia",SI: TVDX
http://ip96.uk:8080/shakeelmirza/4110440/500265
#EXTINF:-1 tvg-id="" tvg-name="SI: Veseljak TV (Golica)" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/d193729e7cecc75672eea2fbdd6861ab.jpg" group-title="Slovenia",SI: Veseljak TV (Golica)
http://ip96.uk:8080/shakeelmirza/4110440/500266
#EXTINF:-1 tvg-id="" tvg-name="SK: Arena Sport 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-10/0cbb5978c829aecd89ee19dffae6bb33.png" group-title="Slovakia",SK: Arena Sport 1
http://ip96.uk:8080/shakeelmirza/4110440/500267
#EXTINF:-1 tvg-id="" tvg-name="SK: Bardejovaska TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2024-09/3f93cac2c1eb197876bfe6eba6ed9afd.jpg" group-title="Slovakia",SK: Bardejovaska TV
http://ip96.uk:8080/shakeelmirza/4110440/500268
#EXTINF:-1 tvg-id="" tvg-name="SK: Dajto" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-10/fb7f0784ce42f7261cf9176a5308f28f.png" group-title="Slovakia",SK: Dajto
http://ip96.uk:8080/shakeelmirza/4110440/500269
#EXTINF:-1 tvg-id="" tvg-name="SK: Doma" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2024-09/5918d69343ef4ed304123c92e0c59ad9.svg" group-title="Slovakia",SK: Doma
http://ip96.uk:8080/shakeelmirza/4110440/500270
#EXTINF:-1 tvg-id="" tvg-name="SK: Duck TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-01/4926c018e557e5d8559fd932f38b2d8e.png" group-title="Slovakia",SK: Duck TV
http://ip96.uk:8080/shakeelmirza/4110440/500271
#EXTINF:-1 tvg-id="" tvg-name="SK: FashionTV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-03/f1b29e415062b7af7a2d3085907df37f.png" group-title="Slovakia",SK: FashionTV
http://ip96.uk:8080/shakeelmirza/4110440/500272
#EXTINF:-1 tvg-id="" tvg-name="SK: FilmBox" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-03/1949cd7117af56530f38fb12bf930854.png" group-title="Slovakia",SK: FilmBox
http://ip96.uk:8080/shakeelmirza/4110440/500273
#EXTINF:-1 tvg-id="" tvg-name="SK: FilmBox Extra" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2024-01/689c97e7b37400ff2e8bd6f8247c5060.png" group-title="Slovakia",SK: FilmBox Extra
http://ip96.uk:8080/shakeelmirza/4110440/500274
#EXTINF:-1 tvg-id="" tvg-name="SK: FilmBox Family" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-03/0136870e7f818b32694dd6dfe4496615.png" group-title="Slovakia",SK: FilmBox Family
http://ip96.uk:8080/shakeelmirza/4110440/500275
#EXTINF:-1 tvg-id="" tvg-name="SK: FilmBox Premium" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-03/d8df3e72e3f79764ce91ffd67f803cc4.png" group-title="Slovakia",SK: FilmBox Premium
http://ip96.uk:8080/shakeelmirza/4110440/500276
#EXTINF:-1 tvg-id="" tvg-name="SK: FilmBox Stars" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-03/c052cb2f2d89b71f58e3ea40058ca9e6.png" group-title="Slovakia",SK: FilmBox Stars
http://ip96.uk:8080/shakeelmirza/4110440/500277
#EXTINF:-1 tvg-id="" tvg-name="SK: HBO 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-03/14007833648e5ccd6be69eb56edfd927.png" group-title="Slovakia",SK: HBO 2
http://ip96.uk:8080/shakeelmirza/4110440/500278
#EXTINF:-1 tvg-id="" tvg-name="SK: Jednotka TV (RTVS 1)" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/c764da84273b57beada7709851ece980.jpg" group-title="Slovakia",SK: Jednotka TV (RTVS 1)
http://ip96.uk:8080/shakeelmirza/4110440/500279
#EXTINF:-1 tvg-id="" tvg-name="SK: Joj Cinema" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/3df03716c342ad69be656dbbf3618d51.png" group-title="Slovakia",SK: Joj Cinema
http://ip96.uk:8080/shakeelmirza/4110440/500280
#EXTINF:-1 tvg-id="" tvg-name="SK: Joj Family" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/a71ffe03dfe4922e4dd62b65669df7df.png" group-title="Slovakia",SK: Joj Family
http://ip96.uk:8080/shakeelmirza/4110440/500281
#EXTINF:-1 tvg-id="" tvg-name="SK: Joj Plus" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/f97c354c0f424cf53f5ce34e496587c2.png" group-title="Slovakia",SK: Joj Plus
http://ip96.uk:8080/shakeelmirza/4110440/500282
#EXTINF:-1 tvg-id="" tvg-name="SK: Life TV" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Slovakia",SK: Life TV
http://ip96.uk:8080/shakeelmirza/4110440/500283
#EXTINF:-1 tvg-id="" tvg-name="SK: Markiza International" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/bc81b47233ab1b976a47966598fb48c7.png" group-title="Slovakia",SK: Markiza International
http://ip96.uk:8080/shakeelmirza/4110440/500284
#EXTINF:-1 tvg-id="" tvg-name="SK: Minimax" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Slovakia",SK: Minimax
http://ip96.uk:8080/shakeelmirza/4110440/500285
#EXTINF:-1 tvg-id="" tvg-name="SK: RTVS 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/da4d55e682952781082178dbfd44dc81.jpg" group-title="Slovakia",SK: RTVS 2
http://ip96.uk:8080/shakeelmirza/4110440/500286
#EXTINF:-1 tvg-id="" tvg-name="SK: RTVS 24" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2024-09/0674980fec273edc5ad9735f0f9d2f0b.svg" group-title="Slovakia",SK: RTVS 24
http://ip96.uk:8080/shakeelmirza/4110440/500287
#EXTINF:-1 tvg-id="" tvg-name="SK: RTVS Šport" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2024-09/4e6e91405a9a82d267a60373136a36df.png" group-title="Slovakia",SK: RTVS Šport
http://ip96.uk:8080/shakeelmirza/4110440/500288
#EXTINF:-1 tvg-id="" tvg-name="SK: Régió TV" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Slovakia",SK: Régió TV
http://ip96.uk:8080/shakeelmirza/4110440/500289
#EXTINF:-1 tvg-id="" tvg-name="SK: Senzi" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/39aa1041ad8613be8c5b207f78639290.png" group-title="Slovakia",SK: Senzi
http://ip96.uk:8080/shakeelmirza/4110440/500290
#EXTINF:-1 tvg-id="" tvg-name="SK: Televízia OSEM" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-01/1b1b2b9419752bc57a04879470db99bf.png" group-title="Slovakia",SK: Televízia OSEM
http://ip96.uk:8080/shakeelmirza/4110440/500291
#EXTINF:-1 tvg-id="" tvg-name="SK: TV Central" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Slovakia",SK: TV Central
http://ip96.uk:8080/shakeelmirza/4110440/500292
#EXTINF:-1 tvg-id="" tvg-name="SK: TV DK" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Slovakia",SK: TV DK
http://ip96.uk:8080/shakeelmirza/4110440/500293
#EXTINF:-1 tvg-id="" tvg-name="SK: TV Doma" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-10/23c08df5d409b5eeb6fc7c40b0c9aea8.png" group-title="Slovakia",SK: TV Doma
http://ip96.uk:8080/shakeelmirza/4110440/500294
#EXTINF:-1 tvg-id="" tvg-name="SK: TV Joj" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/2299fa34a5bc5660344c9371053d0ed9.jpg" group-title="Slovakia",SK: TV Joj
http://ip96.uk:8080/shakeelmirza/4110440/500295
#EXTINF:-1 tvg-id="" tvg-name="SK: TV Liptov" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Slovakia",SK: TV Liptov
http://ip96.uk:8080/shakeelmirza/4110440/500296
#EXTINF:-1 tvg-id="" tvg-name="SK: TV LocAll" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Slovakia",SK: TV LocAll
http://ip96.uk:8080/shakeelmirza/4110440/500297
#EXTINF:-1 tvg-id="" tvg-name="SK: TV Lux" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/d27ebe83054c7f0bed10c4255b3764e5.png" group-title="Slovakia",SK: TV Lux
http://ip96.uk:8080/shakeelmirza/4110440/500298
#EXTINF:-1 tvg-id="" tvg-name="SK: TV Markiza" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/bd046f3cc4ca15d3ab931aab3f36ce09.png" group-title="Slovakia",SK: TV Markiza
http://ip96.uk:8080/shakeelmirza/4110440/500299
#EXTINF:-1 tvg-id="" tvg-name="SK: TV Nové Zámky" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/f6602301a537e69cf91bd5c51c01739d.jpg" group-title="Slovakia",SK: TV Nové Zámky
http://ip96.uk:8080/shakeelmirza/4110440/500300
#EXTINF:-1 tvg-id="" tvg-name="SK: TV Povazie" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-01/97f89baa6aa4b1151374503c1c0c2ebf.png" group-title="Slovakia",SK: TV Povazie
http://ip96.uk:8080/shakeelmirza/4110440/500301
#EXTINF:-1 tvg-id="" tvg-name="SK: TV Raj" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/7053f43ea1c6c0d72dcda41c8a11b623.jpg" group-title="Slovakia",SK: TV Raj
http://ip96.uk:8080/shakeelmirza/4110440/500302
#EXTINF:-1 tvg-id="" tvg-name="SK: TV Romana" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/1b54b575294d852c26f9f4c367562de3.png" group-title="Slovakia",SK: TV Romana
http://ip96.uk:8080/shakeelmirza/4110440/500303
#EXTINF:-1 tvg-id="" tvg-name="SK: TV Ruzinov" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/94f5b1765b362552a1617518d2ed0c99.jpg" group-title="Slovakia",SK: TV Ruzinov
http://ip96.uk:8080/shakeelmirza/4110440/500304
#EXTINF:-1 tvg-id="" tvg-name="SK: TVT" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Slovakia",SK: TVT
http://ip96.uk:8080/shakeelmirza/4110440/500305
#EXTINF:-1 tvg-id="" tvg-name="SK: Wau TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/815d6bf8f69efe5a28771ee1a77e9599.png" group-title="Slovakia",SK: Wau TV
http://ip96.uk:8080/shakeelmirza/4110440/500306
#EXTINF:-1 tvg-id="" tvg-name="SK: Óčko" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2024-09/572acffcee78a1aacec066c3b94a4bd4.png" group-title="Slovakia",SK: Óčko
http://ip96.uk:8080/shakeelmirza/4110440/500307
#EXTINF:-1 tvg-id="" tvg-name="SK: Óčko Expres" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2024-09/d9d96ed45ea13936f4a8d0ddf4a52551.png" group-title="Slovakia",SK: Óčko Expres
http://ip96.uk:8080/shakeelmirza/4110440/500308
#EXTINF:-1 tvg-id="" tvg-name="SK: Óčko Star" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2024-09/6d6e12cac93443aeed697f41fa6ff6e3.png" group-title="Slovakia",SK: Óčko Star
http://ip96.uk:8080/shakeelmirza/4110440/500309
#EXTINF:-1 tvg-id="" tvg-name="GEM AZ" tvg-logo="" group-title="GEM",GEM AZ
http://ip96.uk:8080/shakeelmirza/4110440/456453
#EXTINF:-1 tvg-id="" tvg-name="GEM FILM" tvg-logo="" group-title="GEM",GEM FILM
http://ip96.uk:8080/shakeelmirza/4110440/456454
#EXTINF:-1 tvg-id="" tvg-name="GEM FOOD" tvg-logo="" group-title="GEM",GEM FOOD
http://ip96.uk:8080/shakeelmirza/4110440/456455
#EXTINF:-1 tvg-id="" tvg-name="GEM KIDS" tvg-logo="" group-title="GEM",GEM KIDS
http://ip96.uk:8080/shakeelmirza/4110440/456456
#EXTINF:-1 tvg-id="" tvg-name="GEM LIFE" tvg-logo="" group-title="GEM",GEM LIFE
http://ip96.uk:8080/shakeelmirza/4110440/456457
#EXTINF:-1 tvg-id="" tvg-name="GEM PIXEL" tvg-logo="" group-title="GEM",GEM PIXEL
http://ip96.uk:8080/shakeelmirza/4110440/456458
#EXTINF:-1 tvg-id="" tvg-name="GEM SERIES" tvg-logo="" group-title="GEM",GEM SERIES
http://ip96.uk:8080/shakeelmirza/4110440/456459
#EXTINF:-1 tvg-id="" tvg-name="MBC 1" tvg-logo="" group-title="MBC",MBC 1
http://ip96.uk:8080/shakeelmirza/4110440/456462
#EXTINF:-1 tvg-id="" tvg-name="MBC 2" tvg-logo="" group-title="MBC",MBC 2
http://ip96.uk:8080/shakeelmirza/4110440/456463
#EXTINF:-1 tvg-id="" tvg-name="MBC 3" tvg-logo="" group-title="MBC",MBC 3
http://ip96.uk:8080/shakeelmirza/4110440/456464
#EXTINF:-1 tvg-id="" tvg-name="MBC 4" tvg-logo="" group-title="MBC",MBC 4
http://ip96.uk:8080/shakeelmirza/4110440/456465
#EXTINF:-1 tvg-id="" tvg-name="MBC GAMING" tvg-logo="" group-title="MBC",MBC GAMING
http://ip96.uk:8080/shakeelmirza/4110440/456720
#EXTINF:-1 tvg-id="" tvg-name="PK | AAN TV 4K" tvg-logo="https://www.lyngsat.com/logo/tv/aa/aan-tv-pk.png" group-title="PAKISTAN ➾ DRAMA VIP",PK | AAN TV 4K
http://ip96.uk:8080/shakeelmirza/4110440/246584
#EXTINF:-1 tvg-id="" tvg-name="PK | A1 TV 4K" tvg-logo="https://www.lyngsat.com/logo/tv/aa/a1-entertainment-tv-pk.png" group-title="PAKISTAN ➾ DRAMA VIP",PK | A1 TV 4K
http://ip96.uk:8080/shakeelmirza/4110440/246585
#EXTINF:-1 tvg-id="" tvg-name="PK | AAJ ENT 4K" tvg-logo="https://www.lyngsat.com/logo/tv/aa/aaj_entertainment_pk.png" group-title="PAKISTAN ➾ DRAMA VIP",PK | AAJ ENT 4K
http://ip96.uk:8080/shakeelmirza/4110440/246586
#EXTINF:-1 tvg-id="" tvg-name="PK | APNA TV HD 4K" tvg-logo="https://www.lyngsat.com/logo/tv/aa/apna-channel-pk.png" group-title="PAKISTAN ➾ DRAMA VIP",PK | APNA TV HD 4K
http://ip96.uk:8080/shakeelmirza/4110440/246588
#EXTINF:-1 tvg-id="" tvg-name="PK | ARY DIGITAL 4K" tvg-logo="https://www.lyngsat.com/logo/tv/aa/ary_digital_asia.png" group-title="PAKISTAN ➾ DRAMA VIP",PK | ARY DIGITAL 4K
http://ip96.uk:8080/shakeelmirza/4110440/246590
#EXTINF:-1 tvg-id="" tvg-name="PK | BOL ENT 4K" tvg-logo="https://www.lyngsat.com/logo/tv/bb/bol-entertainment-pk.png" group-title="PAKISTAN ➾ DRAMA VIP",PK | BOL ENT 4K
http://ip96.uk:8080/shakeelmirza/4110440/246591
#EXTINF:-1 tvg-id="" tvg-name="PK | EXPRESS ENT 4K" tvg-logo="https://www.lyngsat.com/logo/tv/ee/express_entertainment_pk.png" group-title="PAKISTAN ➾ DRAMA VIP",PK | EXPRESS ENT 4K
http://ip96.uk:8080/shakeelmirza/4110440/246593
#EXTINF:-1 tvg-id="" tvg-name="PK | GEO ENT 4K" tvg-logo="https://www.lyngsat.com/logo/corp/gg/geo_tv_network.png" group-title="PAKISTAN ➾ DRAMA VIP",PK | GEO ENT 4K
http://ip96.uk:8080/shakeelmirza/4110440/246595
#EXTINF:-1 tvg-id="" tvg-name="PK | GEO KAHANI 4K" tvg-logo="https://www.lyngsat.com/logo/tv/gg/geo_kahani_pk.png" group-title="PAKISTAN ➾ DRAMA VIP",PK | GEO KAHANI 4K
http://ip96.uk:8080/shakeelmirza/4110440/246596
#EXTINF:-1 tvg-id="" tvg-name="PK | HUM MASALA 4K" tvg-logo="https://www.lyngsat.com/logo/tv/hh/hum-masala.png" group-title="PAKISTAN ➾ DRAMA VIP",PK | HUM MASALA 4K
http://ip96.uk:8080/shakeelmirza/4110440/246597
#EXTINF:-1 tvg-id="" tvg-name="PK | HUM SITARY 4K" tvg-logo="https://www.lyngsat.com/logo/tv/hh/hum-sitaray-pk.png" group-title="PAKISTAN ➾ DRAMA VIP",PK | HUM SITARY 4K
http://ip96.uk:8080/shakeelmirza/4110440/246598
#EXTINF:-1 tvg-id="" tvg-name="PK | KAY 2 4K" tvg-logo="https://www.lyngsat.com/logo/tv/kk/kay-2-pk.png" group-title="PAKISTAN ➾ DRAMA VIP",PK | KAY 2 4K
http://ip96.uk:8080/shakeelmirza/4110440/246599
#EXTINF:-1 tvg-id="" tvg-name="PK | KHYBER TV 4K" tvg-logo="https://www.lyngsat.com/logo/tv/kk/khyber-middle-east-tv-pk.png" group-title="PAKISTAN ➾ DRAMA VIP",PK | KHYBER TV 4K
http://ip96.uk:8080/shakeelmirza/4110440/246600
#EXTINF:-1 tvg-id="" tvg-name="PK | KTN ENT 4K" tvg-logo="https://www.lyngsat.com/logo/tv/kk/ktn_tv_pk.png" group-title="PAKISTAN ➾ DRAMA VIP",PK | KTN ENT 4K
http://ip96.uk:8080/shakeelmirza/4110440/246601
#EXTINF:-1 tvg-id="" tvg-name="PK | HUM PASHTO 1 4K" tvg-logo="https://www.lyngsat.com/logo/tv/pp/pashto_1_pk.png" group-title="PAKISTAN ➾ DRAMA VIP",PK | HUM PASHTO 1 4K
http://ip96.uk:8080/shakeelmirza/4110440/246602
#EXTINF:-1 tvg-id="" tvg-name="PK | PTV HOME 4K" tvg-logo="https://www.lyngsat.com/logo/tv/pp/ptv_home_pk.png" group-title="PAKISTAN ➾ DRAMA VIP",PK | PTV HOME 4K
http://ip96.uk:8080/shakeelmirza/4110440/246604
#EXTINF:-1 tvg-id="" tvg-name="PK | SEE TV 4K" tvg-logo="https://www.lyngsat.com/logo/tv/ss/see_tv_pk_hd.png" group-title="PAKISTAN ➾ DRAMA VIP",PK | SEE TV 4K
http://ip96.uk:8080/shakeelmirza/4110440/246606
#EXTINF:-1 tvg-id="" tvg-name="PK | SINDH TV 4K" tvg-logo="https://www.lyngsat.com/logo/tv/ss/sindh_tv.png" group-title="PAKISTAN ➾ DRAMA VIP",PK | SINDH TV 4K
http://ip96.uk:8080/shakeelmirza/4110440/246607
#EXTINF:-1 tvg-id="" tvg-name="PK | TV ONE 4K" tvg-logo="https://www.lyngsat.com/logo/tv/tt/tv_one_pk.png" group-title="PAKISTAN ➾ DRAMA VIP",PK | TV ONE 4K
http://ip96.uk:8080/shakeelmirza/4110440/246608
#EXTINF:-1 tvg-id="" tvg-name="PK | FILMAX 4K" tvg-logo="https://www.lyngsat.com/logo/tv/ff/filmax_pk.png" group-title="PAKISTAN ➾ DRAMA VIP",PK | FILMAX 4K
http://ip96.uk:8080/shakeelmirza/4110440/246610
#EXTINF:-1 tvg-id="" tvg-name="PK | GREEN ENT 4K" tvg-logo="https://www.lyngsat.com/logo/tv/gg/green-entertainment-pk.png" group-title="PAKISTAN ➾ DRAMA VIP",PK | GREEN ENT 4K
http://ip96.uk:8080/shakeelmirza/4110440/246611
#EXTINF:-1 tvg-id="" tvg-name="PK | LTN FAMILY 4K" tvg-logo="https://www.lyngsat.com/logo/tv/ll/ltn-family-pk.png" group-title="PAKISTAN ➾ DRAMA VIP",PK | LTN FAMILY 4K
http://ip96.uk:8080/shakeelmirza/4110440/246612
#EXTINF:-1 tvg-id="" tvg-name="PK | RAAVI 4K" tvg-logo="https://www.lyngsat.com/logo/tv/rr/raavi_tv.png" group-title="PAKISTAN ➾ DRAMA VIP",PK | RAAVI 4K
http://ip96.uk:8080/shakeelmirza/4110440/246613
#EXTINF:-1 tvg-id="" tvg-name="PK | SAB TV 4K" tvg-logo="https://www.lyngsat.com/logo/tv/ss/sab-tv-pk.png" group-title="PAKISTAN ➾ DRAMA VIP",PK | SAB TV 4K
http://ip96.uk:8080/shakeelmirza/4110440/246614
#EXTINF:-1 tvg-id="" tvg-name="PK | MUN TV 4K" tvg-logo="https://www.lyngsat.com/logo/tv/mm/mun-tv-pk.png" group-title="PAKISTAN ➾ DRAMA VIP",PK | MUN TV 4K
http://ip96.uk:8080/shakeelmirza/4110440/246615
#EXTINF:-1 tvg-id="" tvg-name="PK | URDU 1 4K" tvg-logo="https://www.lyngsat.com/logo/tv/uu/urdu_1_pk_me.png" group-title="PAKISTAN ➾ DRAMA VIP",PK | URDU 1 4K
http://ip96.uk:8080/shakeelmirza/4110440/246616
#EXTINF:-1 tvg-id="" tvg-name="PK | ARY ZINDAGI 4K" tvg-logo="https://www.lyngsat.com/logo/tv/aa/ary_zindagi_pk.png" group-title="PAKISTAN ➾ DRAMA VIP",PK | ARY ZINDAGI 4K
http://ip96.uk:8080/shakeelmirza/4110440/246617
#EXTINF:-1 tvg-id="" tvg-name="PK | WASEB 4K" tvg-logo="https://www.lyngsat.com/logo/tv/ww/waseb_tv.png" group-title="PAKISTAN ➾ DRAMA VIP",PK | WASEB 4K
http://ip96.uk:8080/shakeelmirza/4110440/246618
#EXTINF:-1 tvg-id="" tvg-name="PK | PTV NATIONAL 4K" tvg-logo="https://www.lyngsat.com/logo/tv/pp/ptv_national_pk.png" group-title="PAKISTAN ➾ DRAMA VIP",PK | PTV NATIONAL 4K
http://ip96.uk:8080/shakeelmirza/4110440/246619
#EXTINF:-1 tvg-id="" tvg-name="PK | HUM TV 4K" tvg-logo="https://www.lyngsat.com/logo/tv/hh/hum_tv_pk.png" group-title="PAKISTAN ➾ DRAMA VIP",PK | HUM TV 4K
http://ip96.uk:8080/shakeelmirza/4110440/246620
#EXTINF:-1 tvg-id="" tvg-name="PK | FILMAZIA 4K" tvg-logo="https://www.lyngsat.com/logo/tv/ff/filmazia_pk.png" group-title="PAKISTAN ➾ DRAMA VIP",PK | FILMAZIA 4K
http://ip96.uk:8080/shakeelmirza/4110440/246622
#EXTINF:-1 tvg-id="" tvg-name="PK | FILMAZIA PUNJABI 4K" tvg-logo="https://www.lyngsat.com/logo/tv/ff/filmazia-punjabi-pk.png" group-title="PAKISTAN ➾ DRAMA VIP",PK | FILMAZIA PUNJABI 4K
http://ip96.uk:8080/shakeelmirza/4110440/246624
#EXTINF:-1 tvg-id="" tvg-name="PK | ATV 4K" tvg-logo="http://webotv.asia:80/images/ef539b6df421dff0196ffec9dee7147c.png" group-title="PAKISTAN ➾ DRAMA VIP",PK | ATV 4K
http://ip96.uk:8080/shakeelmirza/4110440/246625
#EXTINF:-1 tvg-id="" tvg-name="PK | WANASAH TV 4K" tvg-logo="" group-title="PAKISTAN ➾ DRAMA VIP",PK | WANASAH TV 4K
http://ip96.uk:8080/shakeelmirza/4110440/284013
#EXTINF:-1 tvg-id="" tvg-name="PK | ARY NEWS 4K" tvg-logo="https://www.lyngsat.com/logo/tv/aa/ary_news_asia.png" group-title="PAKISTAN ➾ NEWS VIP",PK | ARY NEWS 4K
http://ip96.uk:8080/shakeelmirza/4110440/246972
#EXTINF:-1 tvg-id="" tvg-name="PK | DUNYA NEWS 4K" tvg-logo="https://www.lyngsat.com/logo/tv/dd/dunya_news_tv_pk.png" group-title="PAKISTAN ➾ NEWS VIP",PK | DUNYA NEWS 4K
http://ip96.uk:8080/shakeelmirza/4110440/246973
#EXTINF:-1 tvg-id="" tvg-name="PK | BOL NEWS 4K" tvg-logo="https://www.lyngsat.com/logo/tv/bb/bol_news_pk.png" group-title="PAKISTAN ➾ NEWS VIP",PK | BOL NEWS 4K
http://ip96.uk:8080/shakeelmirza/4110440/246974
#EXTINF:-1 tvg-id="" tvg-name="PK | EXPRESS NEWS 4K" tvg-logo="https://www.lyngsat.com/logo/tv/ee/express-news-pk.png" group-title="PAKISTAN ➾ NEWS VIP",PK | EXPRESS NEWS 4K
http://ip96.uk:8080/shakeelmirza/4110440/246975
#EXTINF:-1 tvg-id="" tvg-name="PK | GEO NEWS 4K" tvg-logo="https://www.lyngsat.com/logo/tv/gg/geo_news_international.png" group-title="PAKISTAN ➾ NEWS VIP",PK | GEO NEWS 4K
http://ip96.uk:8080/shakeelmirza/4110440/246976
#EXTINF:-1 tvg-id="" tvg-name=" PK | GNN NEWS 4K" tvg-logo="https://www.lyngsat.com/logo/tv/gg/gourmet-news-network-pk.png" group-title="PAKISTAN ➾ NEWS VIP", PK | GNN NEWS 4K
http://ip96.uk:8080/shakeelmirza/4110440/246977
#EXTINF:-1 tvg-id="" tvg-name="PK | GEO TEZ 4K" tvg-logo="https://www.lyngsat.com/logo/tv/gg/geo_tez_pk.png" group-title="PAKISTAN ➾ NEWS VIP",PK | GEO TEZ 4K
http://ip96.uk:8080/shakeelmirza/4110440/246978
#EXTINF:-1 tvg-id="" tvg-name="PK |  HUM NEWS 4K" tvg-logo="https://www.lyngsat.com/logo/tv/hh/hum-news-pk.png" group-title="PAKISTAN ➾ NEWS VIP",PK |  HUM NEWS 4K
http://ip96.uk:8080/shakeelmirza/4110440/246980
#EXTINF:-1 tvg-id="" tvg-name="PK |  KHYBER NEWS 4K" tvg-logo="https://www.lyngsat.com/logo/tv/kk/khyber-news-pk.png" group-title="PAKISTAN ➾ NEWS VIP",PK |  KHYBER NEWS 4K
http://ip96.uk:8080/shakeelmirza/4110440/246981
#EXTINF:-1 tvg-id="" tvg-name="PK |  NEO NEWS 4K" tvg-logo="https://www.lyngsat.com/logo/tv/nn/neo-tv-pk.png" group-title="PAKISTAN ➾ NEWS VIP",PK |  NEO NEWS 4K
http://ip96.uk:8080/shakeelmirza/4110440/246983
#EXTINF:-1 tvg-id="" tvg-name="PK |  PTV NEWS 4K" tvg-logo="https://www.lyngsat.com/logo/tv/pp/ptv_news_pk.png" group-title="PAKISTAN ➾ NEWS VIP",PK |  PTV NEWS 4K
http://ip96.uk:8080/shakeelmirza/4110440/246984
#EXTINF:-1 tvg-id="" tvg-name="PK |  PTV WORLD 4K" tvg-logo="https://www.lyngsat.com/logo/tv/pp/ptv_world_pk.png" group-title="PAKISTAN ➾ NEWS VIP",PK |  PTV WORLD 4K
http://ip96.uk:8080/shakeelmirza/4110440/246985
#EXTINF:-1 tvg-id="" tvg-name="PK | SAMAA NEWS 4K" tvg-logo="https://www.dthsat.com/images/Samaa-News-Logo.png" group-title="PAKISTAN ➾ NEWS VIP",PK | SAMAA NEWS 4K
http://ip96.uk:8080/shakeelmirza/4110440/246986
#EXTINF:-1 tvg-id="" tvg-name="PK |  NEWS ONE 4K" tvg-logo="https://www.lyngsat.com/logo/tv/nn/news-one-pk.png" group-title="PAKISTAN ➾ NEWS VIP",PK |  NEWS ONE 4K
http://ip96.uk:8080/shakeelmirza/4110440/246987
#EXTINF:-1 tvg-id="" tvg-name="PK | TV2DAY 4K" tvg-logo="https://www.lyngsat.com/logo/tv/tt/tv-today-pk.png" group-title="PAKISTAN ➾ NEWS VIP",PK | TV2DAY 4K
http://ip96.uk:8080/shakeelmirza/4110440/246989
#EXTINF:-1 tvg-id="" tvg-name="PK | 24 NEWS 4K" tvg-logo="https://www.lyngsat.com/logo/tv/cc/channel_24_pk.png" group-title="PAKISTAN ➾ NEWS VIP",PK | 24 NEWS 4K
http://ip96.uk:8080/shakeelmirza/4110440/246990
#EXTINF:-1 tvg-id="" tvg-name="PK | K21 NEWS 4K" tvg-logo="https://www.lyngsat.com/logo/tv/kk/k21-news-pk.png" group-title="PAKISTAN ➾ NEWS VIP",PK | K21 NEWS 4K
http://ip96.uk:8080/shakeelmirza/4110440/246991
#EXTINF:-1 tvg-id="" tvg-name="PK | ROHI TV 4K" tvg-logo="https://www.lyngsat.com/logo/tv/rr/rohi-tv-pk.png" group-title="PAKISTAN ➾ NEWS VIP",PK | ROHI TV 4K
http://ip96.uk:8080/shakeelmirza/4110440/246992
#EXTINF:-1 tvg-id="" tvg-name="PK | DAWN NEWS 4K" tvg-logo="https://www.lyngsat.com/logo/tv/dd/dawn_news_pk.png" group-title="PAKISTAN ➾ NEWS VIP",PK | DAWN NEWS 4K
http://ip96.uk:8080/shakeelmirza/4110440/246993
#EXTINF:-1 tvg-id="" tvg-name="PK | VSH NEWS 4K" tvg-logo="https://www.lyngsat.com/logo/tv/vv/vsh_news.png" group-title="PAKISTAN ➾ NEWS VIP",PK | VSH NEWS 4K
http://ip96.uk:8080/shakeelmirza/4110440/246994
#EXTINF:-1 tvg-id="" tvg-name="PK | 92 NEWS 4K" tvg-logo="https://www.lyngsat.com/logo/tv/num/92-news-pk.png" group-title="PAKISTAN ➾ NEWS VIP",PK | 92 NEWS 4K
http://ip96.uk:8080/shakeelmirza/4110440/246995
#EXTINF:-1 tvg-id="" tvg-name="PK | CITY 42 NEWS 4K" tvg-logo="https://www.lyngsat.com/logo/tv/cc/city_42_tv.png" group-title="PAKISTAN ➾ NEWS VIP",PK | CITY 42 NEWS 4K
http://ip96.uk:8080/shakeelmirza/4110440/246996
#EXTINF:-1 tvg-id="" tvg-name="PK | SUNO NEWS 4K" tvg-logo="https://www.lyngsat.com/logo/tv/ss/suno-news-hd-pk.png" group-title="PAKISTAN ➾ NEWS VIP",PK | SUNO NEWS 4K
http://ip96.uk:8080/shakeelmirza/4110440/246997
#EXTINF:-1 tvg-id="" tvg-name="PK | PUBLIC NEWS 4K" tvg-logo="https://www.lyngsat.com/logo/tv/pp/public-news-pk.png" group-title="PAKISTAN ➾ NEWS VIP",PK | PUBLIC NEWS 4K
http://ip96.uk:8080/shakeelmirza/4110440/246998
#EXTINF:-1 tvg-id="" tvg-name="PK | CAPITAL NEWS 4K" tvg-logo="https://www.lyngsat.com/logo/tv/cc/capital_tv_pk.png" group-title="PAKISTAN ➾ NEWS VIP",PK | CAPITAL NEWS 4K
http://ip96.uk:8080/shakeelmirza/4110440/247000
#EXTINF:-1 tvg-id="" tvg-name="PK | ROZE NEWS 4K" tvg-logo="https://www.lyngsat.com/logo/tv/rr/roze_news_pk.png" group-title="PAKISTAN ➾ NEWS VIP",PK | ROZE NEWS 4K
http://ip96.uk:8080/shakeelmirza/4110440/247003
#EXTINF:-1 tvg-id="" tvg-name="PK | SINDH NEWS 4K" tvg-logo="https://www.lyngsat.com/logo/tv/ss/sindh_tv_news.png" group-title="PAKISTAN ➾ NEWS VIP",PK | SINDH NEWS 4K
http://ip96.uk:8080/shakeelmirza/4110440/247004
#EXTINF:-1 tvg-id="" tvg-name="PK | CITY 41 NEWS 4K" tvg-logo="https://www.lyngsat.com/logo/tv/cc/city_41_tv.png" group-title="PAKISTAN ➾ NEWS VIP",PK | CITY 41 NEWS 4K
http://ip96.uk:8080/shakeelmirza/4110440/247005
#EXTINF:-1 tvg-id="" tvg-name="PK | CITY 21 NEWS 4K" tvg-logo="https://www.lyngsat.com/logo/tv/cc/city-21-pk.png" group-title="PAKISTAN ➾ NEWS VIP",PK | CITY 21 NEWS 4K
http://ip96.uk:8080/shakeelmirza/4110440/247006
#EXTINF:-1 tvg-id="" tvg-name="PH | VENUS NEWS 4K" tvg-logo="https://www.lyngsat.com/logo/tv/vv/venus-hd-pk.png" group-title="PAKISTAN ➾ NEWS VIP",PH | VENUS NEWS 4K
http://ip96.uk:8080/shakeelmirza/4110440/247009
#EXTINF:-1 tvg-id="" tvg-name="PK | AAJ NEWS 4K" tvg-logo="https://www.lyngsat.com/logo/tv/aa/aaj_tv_news.png" group-title="PAKISTAN ➾ NEWS VIP",PK | AAJ NEWS 4K
http://ip96.uk:8080/shakeelmirza/4110440/247011
#EXTINF:-1 tvg-id="" tvg-name="PK | ABB TAK NEWS 4K" tvg-logo="https://www.lyngsat.com/logo/tv/aa/abb_takk_pk.png" group-title="PAKISTAN ➾ NEWS VIP",PK | ABB TAK NEWS 4K
http://ip96.uk:8080/shakeelmirza/4110440/247012
#EXTINF:-1 tvg-id="" tvg-name="PK | LAHORE RANG 4K" tvg-logo="" group-title="PAKISTAN ➾ NEWS VIP",PK | LAHORE RANG 4K
http://ip96.uk:8080/shakeelmirza/4110440/283903
#EXTINF:-1 tvg-id="" tvg-name="PK | UK 44 NEWS 4K" tvg-logo="" group-title="PAKISTAN ➾ NEWS VIP",PK | UK 44 NEWS 4K
http://ip96.uk:8080/shakeelmirza/4110440/288098
#EXTINF:-1 tvg-id="" tvg-name="IN | ZEE TV 4K" tvg-logo="https://www.lyngsat.com/logo/tv/zz/zee-tv-in.png" group-title="INDIAN ➾ 4K",IN | ZEE TV 4K
http://ip96.uk:8080/shakeelmirza/4110440/275034
#EXTINF:-1 tvg-id="" tvg-name="IN | SONY 4K" tvg-logo="https://www.lyngsat.com/logo/tv/ss/set_in.png" group-title="INDIAN ➾ 4K",IN | SONY 4K
http://ip96.uk:8080/shakeelmirza/4110440/275035
#EXTINF:-1 tvg-id="" tvg-name="IN | COLORS 4K" tvg-logo="https://www.lyngsat.com/logo/tv/cc/colors-in.png" group-title="INDIAN ➾ 4K",IN | COLORS 4K
http://ip96.uk:8080/shakeelmirza/4110440/275036
#EXTINF:-1 tvg-id="" tvg-name="IN | STAR PLUS 4K" tvg-logo="https://www.lyngsat.com/logo/tv/ss/star-plus-hk.png" group-title="INDIAN ➾ 4K",IN | STAR PLUS 4K
http://ip96.uk:8080/shakeelmirza/4110440/275037
#EXTINF:-1 tvg-id="" tvg-name="IN | STAR BHARAT 4K" tvg-logo="" group-title="INDIAN ➾ 4K",IN | STAR BHARAT 4K
http://ip96.uk:8080/shakeelmirza/4110440/275038
#EXTINF:-1 tvg-id="" tvg-name="IN | STAR UTSAV 4K" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2024-08/0745eefbd8a17542003f01bf22735da0.png" group-title="INDIAN ➾ 4K",IN | STAR UTSAV 4K
http://ip96.uk:8080/shakeelmirza/4110440/275039
#EXTINF:-1 tvg-id="" tvg-name="IN | & TV 4K" tvg-logo="" group-title="INDIAN ➾ 4K",IN | & TV 4K
http://ip96.uk:8080/shakeelmirza/4110440/275040
#EXTINF:-1 tvg-id="" tvg-name="IN | & FLIX TV 4K" tvg-logo="" group-title="INDIAN ➾ 4K",IN | & FLIX TV 4K
http://ip96.uk:8080/shakeelmirza/4110440/275041
#EXTINF:-1 tvg-id="" tvg-name="IN | & PICTURESHD 4K" tvg-logo="" group-title="INDIAN ➾ 4K",IN | & PICTURESHD 4K
http://ip96.uk:8080/shakeelmirza/4110440/275042
#EXTINF:-1 tvg-id="" tvg-name="IN | & PRIVE 4K" tvg-logo="" group-title="INDIAN ➾ 4K",IN | & PRIVE 4K
http://ip96.uk:8080/shakeelmirza/4110440/275043
#EXTINF:-1 tvg-id="" tvg-name="IN | SONY SAB 4K" tvg-logo="" group-title="INDIAN ➾ 4K",IN | SONY SAB 4K
http://ip96.uk:8080/shakeelmirza/4110440/275044
#EXTINF:-1 tvg-id="" tvg-name="IN | SONY MAX 4K" tvg-logo="" group-title="INDIAN ➾ 4K",IN | SONY MAX 4K
http://ip96.uk:8080/shakeelmirza/4110440/275045
#EXTINF:-1 tvg-id="" tvg-name="IN | SONY MAX 2 4K" tvg-logo="" group-title="INDIAN ➾ 4K",IN | SONY MAX 2 4K
http://ip96.uk:8080/shakeelmirza/4110440/275046
#EXTINF:-1 tvg-id="" tvg-name="IN | SONY PAL 4K" tvg-logo="" group-title="INDIAN ➾ 4K",IN | SONY PAL 4K
http://ip96.uk:8080/shakeelmirza/4110440/275047
#EXTINF:-1 tvg-id="" tvg-name="IN | SONY PIX 4K" tvg-logo="" group-title="INDIAN ➾ 4K",IN | SONY PIX 4K
http://ip96.uk:8080/shakeelmirza/4110440/275048
#EXTINF:-1 tvg-id="" tvg-name="IN | STAR GOLD 4K" tvg-logo="" group-title="INDIAN ➾ 4K",IN | STAR GOLD 4K
http://ip96.uk:8080/shakeelmirza/4110440/275049
#EXTINF:-1 tvg-id="" tvg-name="IN | STAR GOLD 2 4K" tvg-logo="" group-title="INDIAN ➾ 4K",IN | STAR GOLD 2 4K
http://ip96.uk:8080/shakeelmirza/4110440/275050
#EXTINF:-1 tvg-id="" tvg-name="IN | STAR GOLD SELECT 4K" tvg-logo="" group-title="INDIAN ➾ 4K",IN | STAR GOLD SELECT 4K
http://ip96.uk:8080/shakeelmirza/4110440/275051
#EXTINF:-1 tvg-id="" tvg-name="IN | STAR GOLD THRILLS 4K" tvg-logo="" group-title="INDIAN ➾ 4K",IN | STAR GOLD THRILLS 4K
http://ip96.uk:8080/shakeelmirza/4110440/275052
#EXTINF:-1 tvg-id="" tvg-name="IN | STAR MOVIES 4K" tvg-logo="" group-title="INDIAN ➾ 4K",IN | STAR MOVIES 4K
http://ip96.uk:8080/shakeelmirza/4110440/275053
#EXTINF:-1 tvg-id="" tvg-name="IN | STAR MOVIES SELECT 4K" tvg-logo="" group-title="INDIAN ➾ 4K",IN | STAR MOVIES SELECT 4K
http://ip96.uk:8080/shakeelmirza/4110440/275054
#EXTINF:-1 tvg-id="" tvg-name="IN | COLORS RISHTEY 4K" tvg-logo="" group-title="INDIAN ➾ 4K",IN | COLORS RISHTEY 4K
http://ip96.uk:8080/shakeelmirza/4110440/275055
#EXTINF:-1 tvg-id="" tvg-name="IN | COLORS INFINITY 4K" tvg-logo="" group-title="INDIAN ➾ 4K",IN | COLORS INFINITY 4K
http://ip96.uk:8080/shakeelmirza/4110440/275056
#EXTINF:-1 tvg-id="" tvg-name="IN | MN PLUS 4K" tvg-logo="" group-title="INDIAN ➾ 4K",IN | MN PLUS 4K
http://ip96.uk:8080/shakeelmirza/4110440/275057
#EXTINF:-1 tvg-id="" tvg-name="IN | ZEE CINEMA 4K" tvg-logo="" group-title="INDIAN ➾ 4K",IN | ZEE CINEMA 4K
http://ip96.uk:8080/shakeelmirza/4110440/275058
#EXTINF:-1 tvg-id="" tvg-name="IN | ZEE BOLLYWOOD 4K" tvg-logo="" group-title="INDIAN ➾ 4K",IN | ZEE BOLLYWOOD 4K
http://ip96.uk:8080/shakeelmirza/4110440/275059
#EXTINF:-1 tvg-id="" tvg-name="IN | ZEE ANMOL 4K" tvg-logo="" group-title="INDIAN ➾ 4K",IN | ZEE ANMOL 4K
http://ip96.uk:8080/shakeelmirza/4110440/275060
#EXTINF:-1 tvg-id="" tvg-name="IN | ZEE CAFE 4K" tvg-logo="" group-title="INDIAN ➾ 4K",IN | ZEE CAFE 4K
http://ip96.uk:8080/shakeelmirza/4110440/275061
#EXTINF:-1 tvg-id="" tvg-name="IN | SONY SPORTS 1 FHD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/sony-sports-ten-1-in.png" group-title="CRICKET ➾ VIP",IN | SONY SPORTS 1 FHD
http://ip96.uk:8080/shakeelmirza/4110440/247155
#EXTINF:-1 tvg-id="" tvg-name="SONY SPORTS 2 FHD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/sony-sports-ten-2-in.png" group-title="CRICKET ➾ VIP",SONY SPORTS 2 FHD
http://ip96.uk:8080/shakeelmirza/4110440/247156
#EXTINF:-1 tvg-id="" tvg-name="SONY SPORTS 3 FHD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/sony-sports-ten-3-in.png" group-title="CRICKET ➾ VIP",SONY SPORTS 3 FHD
http://ip96.uk:8080/shakeelmirza/4110440/247157
#EXTINF:-1 tvg-id="" tvg-name="IN | STAR SPORTS 1 FHD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/star-sports-1-hk-in.png" group-title="CRICKET ➾ VIP",IN | STAR SPORTS 1 FHD
http://ip96.uk:8080/shakeelmirza/4110440/247159
#EXTINF:-1 tvg-id="" tvg-name="IN | STAR SPORTS 2 FHD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/star-sports-2-hk-in.png" group-title="CRICKET ➾ VIP",IN | STAR SPORTS 2 FHD
http://ip96.uk:8080/shakeelmirza/4110440/247160
#EXTINF:-1 tvg-id="" tvg-name="IN | STAR SPORTS SELECT 1 FHD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/star-sports-select-hd1-hk-in.png" group-title="CRICKET ➾ VIP",IN | STAR SPORTS SELECT 1 FHD
http://ip96.uk:8080/shakeelmirza/4110440/247161
#EXTINF:-1 tvg-id="" tvg-name="IN | STAR SPORTS SELECT 2 FHD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/star-sports-select-hd2-hk-in.png" group-title="CRICKET ➾ VIP",IN | STAR SPORTS SELECT 2 FHD
http://ip96.uk:8080/shakeelmirza/4110440/247162
#EXTINF:-1 tvg-id="" tvg-name="SPORTS 18 FHD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/sports-18-in.png" group-title="CRICKET ➾ VIP",SPORTS 18 FHD
http://ip96.uk:8080/shakeelmirza/4110440/247163
#EXTINF:-1 tvg-id="" tvg-name="GEO SUPER FHD" tvg-logo="https://www.lyngsat.com/logo/tv/gg/geo_super.png" group-title="CRICKET ➾ VIP",GEO SUPER FHD
http://ip96.uk:8080/shakeelmirza/4110440/247167
#EXTINF:-1 tvg-id="" tvg-name="A SPORTS FHD" tvg-logo="https://www.lyngsat.com/logo/tv/aa/a-sports-pk.png" group-title="CRICKET ➾ VIP",A SPORTS FHD
http://ip96.uk:8080/shakeelmirza/4110440/247168
#EXTINF:-1 tvg-id="" tvg-name="FAST SPORTS HD" tvg-logo="https://www.lyngsat.com/logo/tv/ff/fast-sports-pk.png" group-title="CRICKET ➾ VIP",FAST SPORTS HD
http://ip96.uk:8080/shakeelmirza/4110440/247169
#EXTINF:-1 tvg-id="" tvg-name="PTV SPORTS FHD" tvg-logo="https://www.lyngsat.com/logo/tv/pp/ptv_sports_pk.png" group-title="CRICKET ➾ VIP",PTV SPORTS FHD
http://ip96.uk:8080/shakeelmirza/4110440/247170
#EXTINF:-1 tvg-id="" tvg-name="TEN SPORTS FHD" tvg-logo="https://www.lyngsat.com/logo/tv/tt/ten_sports_in_pakistan.png" group-title="CRICKET ➾ VIP",TEN SPORTS FHD
http://ip96.uk:8080/shakeelmirza/4110440/247171
#EXTINF:-1 tvg-id="" tvg-name="PK | AUR LIFE 4K" tvg-logo="" group-title="PAKISTAN ➾ DRAMA VIP",PK | AUR LIFE 4K
http://ip96.uk:8080/shakeelmirza/4110440/350101
#EXTINF:-1 tvg-id="" tvg-name="PK | AVT KHYBER 4K" tvg-logo="" group-title="PAKISTAN ➾ DRAMA VIP",PK | AVT KHYBER 4K
http://ip96.uk:8080/shakeelmirza/4110440/350102
#EXTINF:-1 tvg-id="" tvg-name="PK | AVT KHYBER ME 4K" tvg-logo="" group-title="PAKISTAN ➾ DRAMA VIP",PK | AVT KHYBER ME 4K
http://ip96.uk:8080/shakeelmirza/4110440/350103
#EXTINF:-1 tvg-id="" tvg-name="PK | RAAVI TV 4K " tvg-logo="" group-title="PAKISTAN ➾ DRAMA VIP",PK | RAAVI TV 4K 
http://ip96.uk:8080/shakeelmirza/4110440/350122
#EXTINF:-1 tvg-id="" tvg-name="PK | ROHI TV 4K " tvg-logo="" group-title="PAKISTAN ➾ DRAMA VIP",PK | ROHI TV 4K 
http://ip96.uk:8080/shakeelmirza/4110440/350142
#EXTINF:-1 tvg-id="" tvg-name="PK | STAR LIFE TV 4K " tvg-logo="" group-title="PAKISTAN ➾ DRAMA VIP",PK | STAR LIFE TV 4K 
http://ip96.uk:8080/shakeelmirza/4110440/350160
#EXTINF:-1 tvg-id="" tvg-name="PK | BARKAT TV 4K " tvg-logo="" group-title="PAKISTAN ➾ DRAMA VIP",PK | BARKAT TV 4K 
http://ip96.uk:8080/shakeelmirza/4110440/350105
#EXTINF:-1 tvg-id="" tvg-name="PK | ISAAC TV 4K " tvg-logo="" group-title="PAKISTAN ➾ DRAMA VIP",PK | ISAAC TV 4K 
http://ip96.uk:8080/shakeelmirza/4110440/350120
#EXTINF:-1 tvg-id="" tvg-name="PK | GAWAHI TV 4K " tvg-logo="" group-title="PAKISTAN ➾ DRAMA VIP",PK | GAWAHI TV 4K 
http://ip96.uk:8080/shakeelmirza/4110440/350116
#EXTINF:-1 tvg-id="" tvg-name="PK | JOSHUA TV 4K " tvg-logo="" group-title="PAKISTAN ➾ DRAMA VIP",PK | JOSHUA TV 4K 
http://ip96.uk:8080/shakeelmirza/4110440/350121
#EXTINF:-1 tvg-id="" tvg-name="PK | KASHIS TV 4K " tvg-logo="" group-title="PAKISTAN ➾ DRAMA VIP",PK | KASHIS TV 4K 
http://ip96.uk:8080/shakeelmirza/4110440/350123
#EXTINF:-1 tvg-id="" tvg-name="PK | CHANNEL 5 4K" tvg-logo="" group-title="PAKISTAN ➾ NEWS VIP",PK | CHANNEL 5 4K
http://ip96.uk:8080/shakeelmirza/4110440/350107
#EXTINF:-1 tvg-id="" tvg-name="PK | AVT KHYBER NEWS 4K" tvg-logo="" group-title="PAKISTAN ➾ NEWS VIP",PK | AVT KHYBER NEWS 4K
http://ip96.uk:8080/shakeelmirza/4110440/350104
#EXTINF:-1 tvg-id="" tvg-name="PK | ABN NEWS 4K" tvg-logo="" group-title="PAKISTAN ➾ NEWS VIP",PK | ABN NEWS 4K
http://ip96.uk:8080/shakeelmirza/4110440/350099
#EXTINF:-1 tvg-id="" tvg-name="PK | ZINDAGI TV 4K " tvg-logo="" group-title="PAKISTAN ➾ DRAMA VIP",PK | ZINDAGI TV 4K 
http://ip96.uk:8080/shakeelmirza/4110440/478021
#EXTINF:-1 tvg-id="" tvg-name="SONY SPORTS 5 FHD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/sony-sports-ten-5-in.png" group-title="CRICKET ➾ VIP",SONY SPORTS 5 FHD
http://ip96.uk:8080/shakeelmirza/4110440/247158
#EXTINF:-1 tvg-id="" tvg-name="IN|UK | UTSAV PLUS HD" tvg-logo="" group-title="INDIAN ➾ UK",IN|UK | UTSAV PLUS HD
http://ip96.uk:8080/shakeelmirza/4110440/276646
#EXTINF:-1 tvg-id="" tvg-name="IN|UK | SONY TV ASIA HD" tvg-logo="https://www.lyngsat.com/logo/tv/ss/set_in.png" group-title="INDIAN ➾ UK",IN|UK | SONY TV ASIA HD
http://ip96.uk:8080/shakeelmirza/4110440/276648
#EXTINF:-1 tvg-id="" tvg-name="IN|UK | ZEE TV HD" tvg-logo="https://www.lyngsat.com/logo/tv/zz/zee-tv-in.png" group-title="INDIAN ➾ UK",IN|UK | ZEE TV HD
http://ip96.uk:8080/shakeelmirza/4110440/276650
#EXTINF:-1 tvg-id="" tvg-name="IN|UK | ZEE CINEMA" tvg-logo="" group-title="INDIAN ➾ UK",IN|UK | ZEE CINEMA
http://ip96.uk:8080/shakeelmirza/4110440/276651
#EXTINF:-1 tvg-id="" tvg-name="IN|UK | SONY MAX" tvg-logo="" group-title="INDIAN ➾ UK",IN|UK | SONY MAX
http://ip96.uk:8080/shakeelmirza/4110440/276652
#EXTINF:-1 tvg-id="" tvg-name="IN||UK | SONY MAX 2" tvg-logo="" group-title="INDIAN ➾ UK",IN||UK | SONY MAX 2
http://ip96.uk:8080/shakeelmirza/4110440/276653
#EXTINF:-1 tvg-id="" tvg-name="IN|UK | SONY SAB" tvg-logo="" group-title="INDIAN ➾ UK",IN|UK | SONY SAB
http://ip96.uk:8080/shakeelmirza/4110440/276654
#EXTINF:-1 tvg-id="" tvg-name="IN|UK | COLORS HD" tvg-logo="https://www.lyngsat.com/logo/tv/cc/colors-in.png" group-title="INDIAN ➾ UK",IN|UK | COLORS HD
http://ip96.uk:8080/shakeelmirza/4110440/276655
#EXTINF:-1 tvg-id="" tvg-name="IN|UK | COLOR CINEPLEX" tvg-logo="" group-title="INDIAN ➾ UK",IN|UK | COLOR CINEPLEX
http://ip96.uk:8080/shakeelmirza/4110440/276656
#EXTINF:-1 tvg-id="" tvg-name="IN|UK | B4U MOVIES" tvg-logo="" group-title="INDIAN ➾ UK",IN|UK | B4U MOVIES
http://ip96.uk:8080/shakeelmirza/4110440/276658
#EXTINF:-1 tvg-id="" tvg-name="IN|UK | BRIT ASIA" tvg-logo="" group-title="INDIAN ➾ UK",IN|UK | BRIT ASIA
http://ip96.uk:8080/shakeelmirza/4110440/276659
#EXTINF:-1 tvg-id="" tvg-name="IN|UK | ZING" tvg-logo="" group-title="INDIAN ➾ UK",IN|UK | ZING
http://ip96.uk:8080/shakeelmirza/4110440/276660
#EXTINF:-1 tvg-id="" tvg-name="IN|UK | AKAAL TV" tvg-logo="" group-title="INDIAN ➾ UK",IN|UK | AKAAL TV
http://ip96.uk:8080/shakeelmirza/4110440/276992
#EXTINF:-1 tvg-id="" tvg-name="IN|UK | SIKH CHANNEL" tvg-logo="" group-title="INDIAN ➾ UK",IN|UK | SIKH CHANNEL
http://ip96.uk:8080/shakeelmirza/4110440/276993
#EXTINF:-1 tvg-id="" tvg-name="BIH: 24 Kitchen" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/7d275592440de062be2b2e95af85da66.jpg" group-title="Bosnia",BIH: 24 Kitchen
http://ip96.uk:8080/shakeelmirza/4110440/302812
#EXTINF:-1 tvg-id="" tvg-name="BIH: Alfa TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-01/7a66a15fa5cec6c84fcc597794a838bc.jpg" group-title="Bosnia",BIH: Alfa TV
http://ip96.uk:8080/shakeelmirza/4110440/302813
#EXTINF:-1 tvg-id="" tvg-name="BIH: AlJazeera Balkans" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-07/3ddda942a2d1ecd91f529ba781ec2ebe.png" group-title="Bosnia",BIH: AlJazeera Balkans
http://ip96.uk:8080/shakeelmirza/4110440/302814
#EXTINF:-1 tvg-id="" tvg-name="BIH: Alternativna TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-10/f32c09d8f01390e9a82e1ee0163e7ad8.svg" group-title="Bosnia",BIH: Alternativna TV
http://ip96.uk:8080/shakeelmirza/4110440/302815
#EXTINF:-1 tvg-id="" tvg-name="BIH: Arena Sport 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-01/7080764e6e3bb36c4c2cf7018076670a.png" group-title="Bosnia",BIH: Arena Sport 1
http://ip96.uk:8080/shakeelmirza/4110440/302816
#EXTINF:-1 tvg-id="" tvg-name="BIH: Arena Sport 1 Premium" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2024-03/3f49ed109214b84440ecebae4ccbbba4.png" group-title="Bosnia",BIH: Arena Sport 1 Premium
http://ip96.uk:8080/shakeelmirza/4110440/302817
#EXTINF:-1 tvg-id="" tvg-name="BIH: Arena Sport 2 Premium" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2024-03/cfaf43a33897d934b6b88c1ccf89271d.png" group-title="Bosnia",BIH: Arena Sport 2 Premium
http://ip96.uk:8080/shakeelmirza/4110440/302818
#EXTINF:-1 tvg-id="" tvg-name="BIH: Arena Sport 3" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/137d2079bbf49782da7a364c8bb879fb.png" group-title="Bosnia",BIH: Arena Sport 3
http://ip96.uk:8080/shakeelmirza/4110440/302819
#EXTINF:-1 tvg-id="" tvg-name="BIH: Arena Sport 4" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2024-03/20150316bc2d82a859c3af18566e5f1e.png" group-title="Bosnia",BIH: Arena Sport 4
http://ip96.uk:8080/shakeelmirza/4110440/302820
#EXTINF:-1 tvg-id="" tvg-name="BIH: Arena Sport 5" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2024-03/1fa675e6620c0ae5a8bf4f9d47e6b48d.png" group-title="Bosnia",BIH: Arena Sport 5
http://ip96.uk:8080/shakeelmirza/4110440/302821
#EXTINF:-1 tvg-id="" tvg-name="BIH: AXN" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/a7bb4c7998058bf3dccbec624029e006.png" group-title="Bosnia",BIH: AXN
http://ip96.uk:8080/shakeelmirza/4110440/302822
#EXTINF:-1 tvg-id="" tvg-name="BIH: BHT 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/207ae543c971da3d4b2777dab6a02647.png" group-title="Bosnia",BIH: BHT 1
http://ip96.uk:8080/shakeelmirza/4110440/302823
#EXTINF:-1 tvg-id="" tvg-name="BIH: BN" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/22b7587043000bc5f78da8892591b470.png" group-title="Bosnia",BIH: BN
http://ip96.uk:8080/shakeelmirza/4110440/302824
#EXTINF:-1 tvg-id="" tvg-name="BIH: BN Music" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/7c47da32df5f28097061809d4537d9bd.png" group-title="Bosnia",BIH: BN Music
http://ip96.uk:8080/shakeelmirza/4110440/302825
#EXTINF:-1 tvg-id="" tvg-name="BIH: BN2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-11/0fdb7790835364716f635ad2da1a7dcd.jfif" group-title="Bosnia",BIH: BN2
http://ip96.uk:8080/shakeelmirza/4110440/302826
#EXTINF:-1 tvg-id="" tvg-name="BIH: Cinemax" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-06/6f789f2d30410db6fdc2a6690386ed44.png" group-title="Bosnia",BIH: Cinemax
http://ip96.uk:8080/shakeelmirza/4110440/302827
#EXTINF:-1 tvg-id="" tvg-name="BIH: Cinemax 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/5413bc239e2a827c4ddc76416194801b.png" group-title="Bosnia",BIH: Cinemax 2
http://ip96.uk:8080/shakeelmirza/4110440/302828
#EXTINF:-1 tvg-id="" tvg-name="BIH: City TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/713253947c4911554c3cbfab4f17cb5b.png" group-title="Bosnia",BIH: City TV
http://ip96.uk:8080/shakeelmirza/4110440/302829
#EXTINF:-1 tvg-id="" tvg-name="BIH: Discovery Science" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/3eb4f5cb19f6ee32e75473e2d3ec994b.png" group-title="Bosnia",BIH: Discovery Science
http://ip96.uk:8080/shakeelmirza/4110440/302830
#EXTINF:-1 tvg-id="" tvg-name="BIH: Elta" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/51bb21c77710eaae1b440787ed0d1903.jpg" group-title="Bosnia",BIH: Elta
http://ip96.uk:8080/shakeelmirza/4110440/302831
#EXTINF:-1 tvg-id="" tvg-name="BIH: Elta 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/4ef678f1c673fa7da17c883a050ef1a5.jpg" group-title="Bosnia",BIH: Elta 2
http://ip96.uk:8080/shakeelmirza/4110440/302832
#EXTINF:-1 tvg-id="" tvg-name="BIH: Eurosport 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/e9ce5d90aee489e36c94ae3f591e12f7.png" group-title="Bosnia",BIH: Eurosport 2
http://ip96.uk:8080/shakeelmirza/4110440/302833
#EXTINF:-1 tvg-id="" tvg-name="BIH: Face TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/a29d8992908bcf3a14edbb756ee51946.jpg" group-title="Bosnia",BIH: Face TV
http://ip96.uk:8080/shakeelmirza/4110440/302834
#EXTINF:-1 tvg-id="" tvg-name="BIH: Federalna TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/bb61a0e3547ce8ebe9eaf47e7b4bde53.png" group-title="Bosnia",BIH: Federalna TV
http://ip96.uk:8080/shakeelmirza/4110440/302835
#EXTINF:-1 tvg-id="" tvg-name="BIH: Fox" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-06/695c55643558cc31fb0ef2570a4a0234.svg" group-title="Bosnia",BIH: Fox
http://ip96.uk:8080/shakeelmirza/4110440/302836
#EXTINF:-1 tvg-id="" tvg-name="BIH: Fox Crime" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/f25eb340162b7c091847a0ec0b48b3bc.png" group-title="Bosnia",BIH: Fox Crime
http://ip96.uk:8080/shakeelmirza/4110440/302837
#EXTINF:-1 tvg-id="" tvg-name="BIH: Fox Life" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-01/6f4b6cc1830c72454d626a6e4cfa453c.png" group-title="Bosnia",BIH: Fox Life
http://ip96.uk:8080/shakeelmirza/4110440/302838
#EXTINF:-1 tvg-id="" tvg-name="BIH: Fox Movies" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-10/732de89da53335d6033f10608448313d.png" group-title="Bosnia",BIH: Fox Movies
http://ip96.uk:8080/shakeelmirza/4110440/302839
#EXTINF:-1 tvg-id="" tvg-name="BIH: Hayat" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-12/e832809e8279d8a5ce47d3973dc06cad.png" group-title="Bosnia",BIH: Hayat
http://ip96.uk:8080/shakeelmirza/4110440/302840
#EXTINF:-1 tvg-id="" tvg-name="BIH: Hayat Folk" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/a618506155be44045fa6fb5bdc32fbcc.png" group-title="Bosnia",BIH: Hayat Folk
http://ip96.uk:8080/shakeelmirza/4110440/302841
#EXTINF:-1 tvg-id="" tvg-name="BIH: Hayat Music" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/3b93cefbfc9d70fbce0bb8829f5b748a.png" group-title="Bosnia",BIH: Hayat Music
http://ip96.uk:8080/shakeelmirza/4110440/302842
#EXTINF:-1 tvg-id="" tvg-name="BIH: Hayat Plus" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/6f70a476d7f8269ce72de0c04fbbd77d.png" group-title="Bosnia",BIH: Hayat Plus
http://ip96.uk:8080/shakeelmirza/4110440/302843
#EXTINF:-1 tvg-id="" tvg-name="BIH: Hayatovci" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/f5dac349548bf730c7c830bca00eb712.png" group-title="Bosnia",BIH: Hayatovci
http://ip96.uk:8080/shakeelmirza/4110440/302844
#EXTINF:-1 tvg-id="" tvg-name="BIH: HBO" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/92ffb399d7271b5a008ed825723dfcb8.png" group-title="Bosnia",BIH: HBO
http://ip96.uk:8080/shakeelmirza/4110440/302845
#EXTINF:-1 tvg-id="" tvg-name="BIH: HBO 3" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/ce1bfc48ef134315df64b326838e439c.png" group-title="Bosnia",BIH: HBO 3
http://ip96.uk:8080/shakeelmirza/4110440/302846
#EXTINF:-1 tvg-id="" tvg-name="BIH: Hema TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-04/33d6f9a9c9aace0d9563f2d52f02d5b6.png" group-title="Bosnia",BIH: Hema TV
http://ip96.uk:8080/shakeelmirza/4110440/302847
#EXTINF:-1 tvg-id="" tvg-name="BIH: HIT Televizija" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/4709d6dd9f5908b5685f254ced36bbbd.jpg" group-title="Bosnia",BIH: HIT Televizija
http://ip96.uk:8080/shakeelmirza/4110440/302848
#EXTINF:-1 tvg-id="" tvg-name="BIH: Investigation Discovery" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/ca79c21dc61ae26a14d36568f7772aa4.jpg" group-title="Bosnia",BIH: Investigation Discovery
http://ip96.uk:8080/shakeelmirza/4110440/302849
#EXTINF:-1 tvg-id="" tvg-name="BIH: Izvorna TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/0b18740ba25955d012a89cd4b10145db.jpg" group-title="Bosnia",BIH: Izvorna TV
http://ip96.uk:8080/shakeelmirza/4110440/302850
#EXTINF:-1 tvg-id="" tvg-name="BIH: Kanal 6" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/918815e4a0b69e97ff6cdc0c18c3fa6f.jpg" group-title="Bosnia",BIH: Kanal 6
http://ip96.uk:8080/shakeelmirza/4110440/302851
#EXTINF:-1 tvg-id="" tvg-name="BIH: Lov i ribolov" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/5e826b8e6c5dd5eecbd55cba5cb95de5.png" group-title="Bosnia",BIH: Lov i ribolov
http://ip96.uk:8080/shakeelmirza/4110440/302852
#EXTINF:-1 tvg-id="" tvg-name="BIH: Mini TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-01/704671093ce4b390e321a7f99e8af0cc.jpg" group-title="Bosnia",BIH: Mini TV
http://ip96.uk:8080/shakeelmirza/4110440/302853
#EXTINF:-1 tvg-id="" tvg-name="BIH: MTV Igman" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/78626303d341aef8dddd63855249dea1.png" group-title="Bosnia",BIH: MTV Igman
http://ip96.uk:8080/shakeelmirza/4110440/302854
#EXTINF:-1 tvg-id="" tvg-name="BIH: N1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/602c158b5e4179a3c956fa3bbf118b6b.png" group-title="Bosnia",BIH: N1
http://ip96.uk:8080/shakeelmirza/4110440/302855
#EXTINF:-1 tvg-id="" tvg-name="BIH: NAT GEO" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-04/f7af67dc378842c32a19e8fb0cb27473.png" group-title="Bosnia",BIH: NAT GEO
http://ip96.uk:8080/shakeelmirza/4110440/302856
#EXTINF:-1 tvg-id="" tvg-name="BIH: NAT GEO Wild" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-04/dd26455a68322149c38ec434e2d6e0d6.png" group-title="Bosnia",BIH: NAT GEO Wild
http://ip96.uk:8080/shakeelmirza/4110440/302857
#EXTINF:-1 tvg-id="" tvg-name="BIH: Nova BH" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/38ea7e1801680bf6ad074a2196c56b7a.png" group-title="Bosnia",BIH: Nova BH
http://ip96.uk:8080/shakeelmirza/4110440/302858
#EXTINF:-1 tvg-id="" tvg-name="BIH: NTVIC Kakanj" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/1f5ffb5a161f22e9fe5ffa17c922f13c.jpg" group-title="Bosnia",BIH: NTVIC Kakanj
http://ip96.uk:8080/shakeelmirza/4110440/302859
#EXTINF:-1 tvg-id="" tvg-name="BIH: O Kanal" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/bb905a251c9a971c50732a0d5898bf4d.png" group-title="Bosnia",BIH: O Kanal
http://ip96.uk:8080/shakeelmirza/4110440/302860
#EXTINF:-1 tvg-id="" tvg-name="BIH: OBN" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/98bd791f881cc0cdf5a6134e2ac64d25.png" group-title="Bosnia",BIH: OBN
http://ip96.uk:8080/shakeelmirza/4110440/302861
#EXTINF:-1 tvg-id="" tvg-name="BIH: OTV Valentino" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/2c02b9603e6c9eae9f4eae6adc5813c2.png" group-title="Bosnia",BIH: OTV Valentino
http://ip96.uk:8080/shakeelmirza/4110440/302862
#EXTINF:-1 tvg-id="" tvg-name="BIH: Pink BH" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/d01f4589f6858bea15ece53d3a7ab89d.png" group-title="Bosnia",BIH: Pink BH
http://ip96.uk:8080/shakeelmirza/4110440/302863
#EXTINF:-1 tvg-id="" tvg-name="BIH: Posavina TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/05b1b61d20c5a1f18e8dbf0dd71bb32a.png" group-title="Bosnia",BIH: Posavina TV
http://ip96.uk:8080/shakeelmirza/4110440/302864
#EXTINF:-1 tvg-id="" tvg-name="BIH: RTRS Plus" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/78ffe0ce0952658d5886535624bcc3ba.png" group-title="Bosnia",BIH: RTRS Plus
http://ip96.uk:8080/shakeelmirza/4110440/302865
#EXTINF:-1 tvg-id="" tvg-name="BIH: RTRS TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/210f97d7a09f3360c9c3f6acc0b365a9.png" group-title="Bosnia",BIH: RTRS TV
http://ip96.uk:8080/shakeelmirza/4110440/302866
#EXTINF:-1 tvg-id="" tvg-name="BIH: RTV Cazin" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/20cf80acf769a0c94658a37de85b4190.jpg" group-title="Bosnia",BIH: RTV Cazin
http://ip96.uk:8080/shakeelmirza/4110440/302867
#EXTINF:-1 tvg-id="" tvg-name="BIH: RTV Herceg Bosne" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/27797b9cc343d9355b5b6811dc6fce39.jpg" group-title="Bosnia",BIH: RTV Herceg Bosne
http://ip96.uk:8080/shakeelmirza/4110440/302868
#EXTINF:-1 tvg-id="" tvg-name="BIH: RTV Sana" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/93e8157eed5094534b6c624f13bbc3b8.jpg" group-title="Bosnia",BIH: RTV Sana
http://ip96.uk:8080/shakeelmirza/4110440/302869
#EXTINF:-1 tvg-id="" tvg-name="BIH: RTV TK Tuzla" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/96c5c0f7b4f5e6ac0f69fb8cbceadc00.png" group-title="Bosnia",BIH: RTV TK Tuzla
http://ip96.uk:8080/shakeelmirza/4110440/302870
#EXTINF:-1 tvg-id="" tvg-name="BIH: RTV Zenica" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/8b9b0194fd0afe4c4901c35d1d72db9c.png" group-title="Bosnia",BIH: RTV Zenica
http://ip96.uk:8080/shakeelmirza/4110440/302871
#EXTINF:-1 tvg-id="" tvg-name="BIH: Sehara TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/8a2fa31b558477bf427f22d0897a997f.png" group-title="Bosnia",BIH: Sehara TV
http://ip96.uk:8080/shakeelmirza/4110440/302872
#EXTINF:-1 tvg-id="" tvg-name="BIH: Sevdah TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/5f9effc2661924d40c553419028c69be.jpg" group-title="Bosnia",BIH: Sevdah TV
http://ip96.uk:8080/shakeelmirza/4110440/302873
#EXTINF:-1 tvg-id="" tvg-name="BIH: Smart Televizija" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/53af5ec76d37c2942e1c2fe317af0aea.jpg" group-title="Bosnia",BIH: Smart Televizija
http://ip96.uk:8080/shakeelmirza/4110440/302874
#EXTINF:-1 tvg-id="" tvg-name="BIH: Super TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/38b76ac5be365499a2a42256aaefa0f7.jpg" group-title="Bosnia",BIH: Super TV
http://ip96.uk:8080/shakeelmirza/4110440/302875
#EXTINF:-1 tvg-id="" tvg-name="BIH: Televizija 5" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/d84101622740bed260ce3c5f99a9c1bc.png" group-title="Bosnia",BIH: Televizija 5
http://ip96.uk:8080/shakeelmirza/4110440/302876
#EXTINF:-1 tvg-id="" tvg-name="BIH: Top TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/c5d676995f0c6bd189ff6439040dade0.jpg" group-title="Bosnia",BIH: Top TV
http://ip96.uk:8080/shakeelmirza/4110440/302877
#EXTINF:-1 tvg-id="" tvg-name="BIH: TV Glas Drine" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/043464c1713ba0be982732a8828bccb5.png" group-title="Bosnia",BIH: TV Glas Drine
http://ip96.uk:8080/shakeelmirza/4110440/302878
#EXTINF:-1 tvg-id="" tvg-name="BIH: TV K3" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/f31898aaf90df40bd1f222ca9990039f.png" group-title="Bosnia",BIH: TV K3
http://ip96.uk:8080/shakeelmirza/4110440/302879
#EXTINF:-1 tvg-id="" tvg-name="BIH: TV Sarajevo" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/4d3c303b60a028acb2a86f8bccbe9a55.png" group-title="Bosnia",BIH: TV Sarajevo
http://ip96.uk:8080/shakeelmirza/4110440/302880
#EXTINF:-1 tvg-id="" tvg-name="BIH: TV Slon Extra" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-10/1cf0702d9c1ec46a3786b35eb382b276.jpg" group-title="Bosnia",BIH: TV Slon Extra
http://ip96.uk:8080/shakeelmirza/4110440/302881
#EXTINF:-1 tvg-id="" tvg-name="BIH: TV USK" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/acef6fe124f1cff76ab0b87e8f0881b2.png" group-title="Bosnia",BIH: TV USK
http://ip96.uk:8080/shakeelmirza/4110440/302882
#EXTINF:-1 tvg-id="" tvg-name="BIH: Una TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-04/6304a746d64db5c47d904b7e5746a8ae.png" group-title="Bosnia",BIH: Una TV
http://ip96.uk:8080/shakeelmirza/4110440/302883
#EXTINF:-1 tvg-id="" tvg-name="BIH: Zivinice" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Bosnia",BIH: Zivinice
http://ip96.uk:8080/shakeelmirza/4110440/302884
#EXTINF:-1 tvg-id="" tvg-name="AU | 9 Life" tvg-logo="" group-title="AU | AUSTRALIA",AU | 9 Life
http://ip96.uk:8080/shakeelmirza/4110440/499750
#EXTINF:-1 tvg-id="" tvg-name="AU | ABC News" tvg-logo="" group-title="AU | AUSTRALIA",AU | ABC News
http://ip96.uk:8080/shakeelmirza/4110440/499751
#EXTINF:-1 tvg-id="" tvg-name="AU: Australia Channel" tvg-logo="" group-title="AU | AUSTRALIA",AU: Australia Channel
http://ip96.uk:8080/shakeelmirza/4110440/499752
#EXTINF:-1 tvg-id="" tvg-name="AU: Bloomberg TV Australia HD" tvg-logo="" group-title="AU | AUSTRALIA",AU: Bloomberg TV Australia HD
http://ip96.uk:8080/shakeelmirza/4110440/499753
#EXTINF:-1 tvg-id="" tvg-name="AU: God TV Australia HD" tvg-logo="" group-title="AU | AUSTRALIA",AU: God TV Australia HD
http://ip96.uk:8080/shakeelmirza/4110440/499754
#EXTINF:-1 tvg-id="" tvg-name="AU: NITV" tvg-logo="" group-title="AU | AUSTRALIA",AU: NITV
http://ip96.uk:8080/shakeelmirza/4110440/499755
#EXTINF:-1 tvg-id="" tvg-name="AU: SBS Food Melbourne" tvg-logo="" group-title="AU | AUSTRALIA",AU: SBS Food Melbourne
http://ip96.uk:8080/shakeelmirza/4110440/499756
#EXTINF:-1 tvg-id="" tvg-name="AU: TVSN" tvg-logo="" group-title="AU | AUSTRALIA",AU: TVSN
http://ip96.uk:8080/shakeelmirza/4110440/499757
#EXTINF:-1 tvg-id="" tvg-name="AU | Racing.com FHD" tvg-logo="" group-title="AU | AUSTRALIA",AU | Racing.com FHD
http://ip96.uk:8080/shakeelmirza/4110440/499758
#EXTINF:-1 tvg-id="" tvg-name="AU | Redbull TV FHD" tvg-logo="" group-title="AU | AUSTRALIA",AU | Redbull TV FHD
http://ip96.uk:8080/shakeelmirza/4110440/499759
#EXTINF:-1 tvg-id="" tvg-name="AU: beIN Sports 1" tvg-logo="" group-title="AU | AUSTRALIA",AU: beIN Sports 1
http://ip96.uk:8080/shakeelmirza/4110440/499760
#EXTINF:-1 tvg-id="" tvg-name="AU: beIN Sports 1 FHD" tvg-logo="" group-title="AU | AUSTRALIA",AU: beIN Sports 1 FHD
http://ip96.uk:8080/shakeelmirza/4110440/499761
#EXTINF:-1 tvg-id="" tvg-name="AU: beIN Sports 2" tvg-logo="" group-title="AU | AUSTRALIA",AU: beIN Sports 2
http://ip96.uk:8080/shakeelmirza/4110440/499762
#EXTINF:-1 tvg-id="" tvg-name="AU: beIN Sports 2 FHD" tvg-logo="" group-title="AU | AUSTRALIA",AU: beIN Sports 2 FHD
http://ip96.uk:8080/shakeelmirza/4110440/499763
#EXTINF:-1 tvg-id="" tvg-name="AU: beIN Sports 3" tvg-logo="" group-title="AU | AUSTRALIA",AU: beIN Sports 3
http://ip96.uk:8080/shakeelmirza/4110440/499764
#EXTINF:-1 tvg-id="" tvg-name="AU: beIN Sports 3 FHD" tvg-logo="" group-title="AU | AUSTRALIA",AU: beIN Sports 3 FHD
http://ip96.uk:8080/shakeelmirza/4110440/499765
#EXTINF:-1 tvg-id="" tvg-name="AU: ESPN 1" tvg-logo="" group-title="AU | AUSTRALIA",AU: ESPN 1
http://ip96.uk:8080/shakeelmirza/4110440/499766
#EXTINF:-1 tvg-id="" tvg-name="AU: ESPN 1 FHD" tvg-logo="" group-title="AU | AUSTRALIA",AU: ESPN 1 FHD
http://ip96.uk:8080/shakeelmirza/4110440/499767
#EXTINF:-1 tvg-id="" tvg-name="AU: ESPN 2" tvg-logo="" group-title="AU | AUSTRALIA",AU: ESPN 2
http://ip96.uk:8080/shakeelmirza/4110440/499768
#EXTINF:-1 tvg-id="" tvg-name="AU: ESPN 2 FHD" tvg-logo="" group-title="AU | AUSTRALIA",AU: ESPN 2 FHD
http://ip96.uk:8080/shakeelmirza/4110440/499769
#EXTINF:-1 tvg-id="" tvg-name="AU: Fox Sports News" tvg-logo="" group-title="AU | AUSTRALIA",AU: Fox Sports News
http://ip96.uk:8080/shakeelmirza/4110440/499770
#EXTINF:-1 tvg-id="" tvg-name="AU: Fox Sports News FHD" tvg-logo="" group-title="AU | AUSTRALIA",AU: Fox Sports News FHD
http://ip96.uk:8080/shakeelmirza/4110440/499771
#EXTINF:-1 tvg-id="" tvg-name="AU: Fox Sports 501" tvg-logo="" group-title="AU | AUSTRALIA",AU: Fox Sports 501
http://ip96.uk:8080/shakeelmirza/4110440/499772
#EXTINF:-1 tvg-id="" tvg-name="AU: Fox Sports 501 FHD" tvg-logo="" group-title="AU | AUSTRALIA",AU: Fox Sports 501 FHD
http://ip96.uk:8080/shakeelmirza/4110440/499773
#EXTINF:-1 tvg-id="" tvg-name="AU: Fox Sports 502" tvg-logo="" group-title="AU | AUSTRALIA",AU: Fox Sports 502
http://ip96.uk:8080/shakeelmirza/4110440/499774
#EXTINF:-1 tvg-id="" tvg-name="AU: Fox Sports 502 FHD" tvg-logo="" group-title="AU | AUSTRALIA",AU: Fox Sports 502 FHD
http://ip96.uk:8080/shakeelmirza/4110440/499775
#EXTINF:-1 tvg-id="" tvg-name="AU: Fox Sports 503" tvg-logo="" group-title="AU | AUSTRALIA",AU: Fox Sports 503
http://ip96.uk:8080/shakeelmirza/4110440/499776
#EXTINF:-1 tvg-id="" tvg-name="AU: Fox Sports 503 FHD" tvg-logo="" group-title="AU | AUSTRALIA",AU: Fox Sports 503 FHD
http://ip96.uk:8080/shakeelmirza/4110440/499777
#EXTINF:-1 tvg-id="" tvg-name="AU: Fox Sports 504" tvg-logo="" group-title="AU | AUSTRALIA",AU: Fox Sports 504
http://ip96.uk:8080/shakeelmirza/4110440/499778
#EXTINF:-1 tvg-id="" tvg-name="AU: Fox Sports 504 FHD" tvg-logo="" group-title="AU | AUSTRALIA",AU: Fox Sports 504 FHD
http://ip96.uk:8080/shakeelmirza/4110440/499779
#EXTINF:-1 tvg-id="" tvg-name="AU: Fox Sports 505" tvg-logo="" group-title="AU | AUSTRALIA",AU: Fox Sports 505
http://ip96.uk:8080/shakeelmirza/4110440/499780
#EXTINF:-1 tvg-id="" tvg-name="AU: Fox Sports 505 FHD" tvg-logo="" group-title="AU | AUSTRALIA",AU: Fox Sports 505 FHD
http://ip96.uk:8080/shakeelmirza/4110440/499781
#EXTINF:-1 tvg-id="" tvg-name="AU: Fox Sports 506" tvg-logo="" group-title="AU | AUSTRALIA",AU: Fox Sports 506
http://ip96.uk:8080/shakeelmirza/4110440/499782
#EXTINF:-1 tvg-id="" tvg-name="AU: Fox Sports 506 FHD" tvg-logo="" group-title="AU | AUSTRALIA",AU: Fox Sports 506 FHD
http://ip96.uk:8080/shakeelmirza/4110440/499783
#EXTINF:-1 tvg-id="" tvg-name="AU: Fox Sports 507" tvg-logo="" group-title="AU | AUSTRALIA",AU: Fox Sports 507
http://ip96.uk:8080/shakeelmirza/4110440/499784
#EXTINF:-1 tvg-id="" tvg-name="AU: Fox Sports 507 FHD" tvg-logo="" group-title="AU | AUSTRALIA",AU: Fox Sports 507 FHD
http://ip96.uk:8080/shakeelmirza/4110440/499785
#EXTINF:-1 tvg-id="" tvg-name="AU: Redbull TV" tvg-logo="" group-title="AU | AUSTRALIA",AU: Redbull TV
http://ip96.uk:8080/shakeelmirza/4110440/499786
#EXTINF:-1 tvg-id="" tvg-name="AU: UFC Fight Pass UHD" tvg-logo="" group-title="AU | AUSTRALIA",AU: UFC Fight Pass UHD
http://ip96.uk:8080/shakeelmirza/4110440/499787
#EXTINF:-1 tvg-id="" tvg-name="AU: RACING.COM" tvg-logo="" group-title="AU | AUSTRALIA",AU: RACING.COM
http://ip96.uk:8080/shakeelmirza/4110440/499788
#EXTINF:-1 tvg-id="" tvg-name="AU: SKY RACING 1" tvg-logo="" group-title="AU | AUSTRALIA",AU: SKY RACING 1
http://ip96.uk:8080/shakeelmirza/4110440/499789
#EXTINF:-1 tvg-id="" tvg-name="AU: SKY RACING 1 FHD" tvg-logo="" group-title="AU | AUSTRALIA",AU: SKY RACING 1 FHD
http://ip96.uk:8080/shakeelmirza/4110440/499790
#EXTINF:-1 tvg-id="" tvg-name="AU: SKY RACING 2" tvg-logo="" group-title="AU | AUSTRALIA",AU: SKY RACING 2
http://ip96.uk:8080/shakeelmirza/4110440/499791
#EXTINF:-1 tvg-id="" tvg-name="AU: SKY RACING 2 FHD" tvg-logo="" group-title="AU | AUSTRALIA",AU: SKY RACING 2 FHD
http://ip96.uk:8080/shakeelmirza/4110440/499792
#EXTINF:-1 tvg-id="" tvg-name="AU: Sky Greyhound (Watchdog)" tvg-logo="" group-title="AU | AUSTRALIA",AU: Sky Greyhound (Watchdog)
http://ip96.uk:8080/shakeelmirza/4110440/499793
#EXTINF:-1 tvg-id="" tvg-name="AU: PAC 12" tvg-logo="" group-title="AU | AUSTRALIA",AU: PAC 12
http://ip96.uk:8080/shakeelmirza/4110440/499794
#EXTINF:-1 tvg-id="" tvg-name="AU: PAC 12 FHD" tvg-logo="" group-title="AU | AUSTRALIA",AU: PAC 12 FHD
http://ip96.uk:8080/shakeelmirza/4110440/499795
#EXTINF:-1 tvg-id="" tvg-name="AU: OutDoor FHD" tvg-logo="" group-title="AU | AUSTRALIA",AU: OutDoor FHD
http://ip96.uk:8080/shakeelmirza/4110440/499796
#EXTINF:-1 tvg-id="" tvg-name="AU: Fuel TV FHD" tvg-logo="" group-title="AU | AUSTRALIA",AU: Fuel TV FHD
http://ip96.uk:8080/shakeelmirza/4110440/499797
#EXTINF:-1 tvg-id="" tvg-name="AU: ausbiz FHD" tvg-logo="" group-title="AU | AUSTRALIA",AU: ausbiz FHD
http://ip96.uk:8080/shakeelmirza/4110440/499798
#EXTINF:-1 tvg-id="" tvg-name="AU: Sky News Extra 1 FHD" tvg-logo="" group-title="AU | AUSTRALIA",AU: Sky News Extra 1 FHD
http://ip96.uk:8080/shakeelmirza/4110440/499799
#EXTINF:-1 tvg-id="" tvg-name="AU: Sky News Extra 2 FHD" tvg-logo="" group-title="AU | AUSTRALIA",AU: Sky News Extra 2 FHD
http://ip96.uk:8080/shakeelmirza/4110440/499800
#EXTINF:-1 tvg-id="" tvg-name="AU: Sky News Extra 3 FHD" tvg-logo="" group-title="AU | AUSTRALIA",AU: Sky News Extra 3 FHD
http://ip96.uk:8080/shakeelmirza/4110440/499801
#EXTINF:-1 tvg-id="" tvg-name="AU: Sky News Extra 1" tvg-logo="" group-title="AU | AUSTRALIA",AU: Sky News Extra 1
http://ip96.uk:8080/shakeelmirza/4110440/499802
#EXTINF:-1 tvg-id="" tvg-name="AU: Sky News Extra 2" tvg-logo="" group-title="AU | AUSTRALIA",AU: Sky News Extra 2
http://ip96.uk:8080/shakeelmirza/4110440/499803
#EXTINF:-1 tvg-id="" tvg-name="AU: Sky News Extra 3" tvg-logo="" group-title="AU | AUSTRALIA",AU: Sky News Extra 3
http://ip96.uk:8080/shakeelmirza/4110440/499804
#EXTINF:-1 tvg-id="" tvg-name="AU: Channel 7" tvg-logo="" group-title="AU | AUSTRALIA",AU: Channel 7
http://ip96.uk:8080/shakeelmirza/4110440/499805
#EXTINF:-1 tvg-id="" tvg-name="AU: Channel 7 TWO" tvg-logo="" group-title="AU | AUSTRALIA",AU: Channel 7 TWO
http://ip96.uk:8080/shakeelmirza/4110440/499806
#EXTINF:-1 tvg-id="" tvg-name="AU: Channel 7 FLIX" tvg-logo="" group-title="AU | AUSTRALIA",AU: Channel 7 FLIX
http://ip96.uk:8080/shakeelmirza/4110440/499807
#EXTINF:-1 tvg-id="" tvg-name="AU: Channel 7 MATE" tvg-logo="" group-title="AU | AUSTRALIA",AU: Channel 7 MATE
http://ip96.uk:8080/shakeelmirza/4110440/499808
#EXTINF:-1 tvg-id="" tvg-name="AU: Channel 9" tvg-logo="" group-title="AU | AUSTRALIA",AU: Channel 9
http://ip96.uk:8080/shakeelmirza/4110440/499809
#EXTINF:-1 tvg-id="" tvg-name="AU: Channel 9 GEM" tvg-logo="" group-title="AU | AUSTRALIA",AU: Channel 9 GEM
http://ip96.uk:8080/shakeelmirza/4110440/499810
#EXTINF:-1 tvg-id="" tvg-name="AU: Channel 9 GO" tvg-logo="" group-title="AU | AUSTRALIA",AU: Channel 9 GO
http://ip96.uk:8080/shakeelmirza/4110440/499811
#EXTINF:-1 tvg-id="" tvg-name="AU: Channel 9 LIFE" tvg-logo="" group-title="AU | AUSTRALIA",AU: Channel 9 LIFE
http://ip96.uk:8080/shakeelmirza/4110440/499812
#EXTINF:-1 tvg-id="" tvg-name="AU: Channel 10" tvg-logo="" group-title="AU | AUSTRALIA",AU: Channel 10
http://ip96.uk:8080/shakeelmirza/4110440/499813
#EXTINF:-1 tvg-id="" tvg-name="AU: Channel 10 PEACH" tvg-logo="" group-title="AU | AUSTRALIA",AU: Channel 10 PEACH
http://ip96.uk:8080/shakeelmirza/4110440/499814
#EXTINF:-1 tvg-id="" tvg-name="AU: Channel 10 BOLD" tvg-logo="" group-title="AU | AUSTRALIA",AU: Channel 10 BOLD
http://ip96.uk:8080/shakeelmirza/4110440/499815
#EXTINF:-1 tvg-id="" tvg-name="AU: ABC News" tvg-logo="" group-title="AU | AUSTRALIA",AU: ABC News
http://ip96.uk:8080/shakeelmirza/4110440/499816
#EXTINF:-1 tvg-id="" tvg-name="AU: ABC" tvg-logo="" group-title="AU | AUSTRALIA",AU: ABC
http://ip96.uk:8080/shakeelmirza/4110440/499817
#EXTINF:-1 tvg-id="" tvg-name="AU: ABC ME" tvg-logo="" group-title="AU | AUSTRALIA",AU: ABC ME
http://ip96.uk:8080/shakeelmirza/4110440/499818
#EXTINF:-1 tvg-id="" tvg-name="AU: ABC Comedy" tvg-logo="" group-title="AU | AUSTRALIA",AU: ABC Comedy
http://ip96.uk:8080/shakeelmirza/4110440/499819
#EXTINF:-1 tvg-id="" tvg-name="AU: ABC KIDS" tvg-logo="" group-title="AU | AUSTRALIA",AU: ABC KIDS
http://ip96.uk:8080/shakeelmirza/4110440/499820
#EXTINF:-1 tvg-id="" tvg-name="AU: Fuel TV" tvg-logo="" group-title="AU | AUSTRALIA",AU: Fuel TV
http://ip96.uk:8080/shakeelmirza/4110440/499821
#EXTINF:-1 tvg-id="" tvg-name="AU: Outdoor" tvg-logo="" group-title="AU | AUSTRALIA",AU: Outdoor
http://ip96.uk:8080/shakeelmirza/4110440/499822
#EXTINF:-1 tvg-id="" tvg-name="AU: SBS" tvg-logo="" group-title="AU | AUSTRALIA",AU: SBS
http://ip96.uk:8080/shakeelmirza/4110440/499823
#EXTINF:-1 tvg-id="" tvg-name="AU: SBS FOOD NETWORK" tvg-logo="" group-title="AU | AUSTRALIA",AU: SBS FOOD NETWORK
http://ip96.uk:8080/shakeelmirza/4110440/499824
#EXTINF:-1 tvg-id="" tvg-name="AU: SBS World Movies" tvg-logo="" group-title="AU | AUSTRALIA",AU: SBS World Movies
http://ip96.uk:8080/shakeelmirza/4110440/499825
#EXTINF:-1 tvg-id="" tvg-name="AU: Open Shop" tvg-logo="" group-title="AU | AUSTRALIA",AU: Open Shop
http://ip96.uk:8080/shakeelmirza/4110440/499826
#EXTINF:-1 tvg-id="" tvg-name="AU: ausbiz" tvg-logo="" group-title="AU | AUSTRALIA",AU: ausbiz
http://ip96.uk:8080/shakeelmirza/4110440/499827
#EXTINF:-1 tvg-id="" tvg-name="AU | OPTUS 1 HD" tvg-logo="" group-title="AU | AUSTRALIA",AU | OPTUS 1 HD
http://ip96.uk:8080/shakeelmirza/4110440/499828
#EXTINF:-1 tvg-id="" tvg-name="AU | OPTUS 2 HD" tvg-logo="" group-title="AU | AUSTRALIA",AU | OPTUS 2 HD
http://ip96.uk:8080/shakeelmirza/4110440/499829
#EXTINF:-1 tvg-id="" tvg-name="OPTUS 3 HD" tvg-logo="" group-title="AU | AUSTRALIA",OPTUS 3 HD
http://ip96.uk:8080/shakeelmirza/4110440/499830
#EXTINF:-1 tvg-id="" tvg-name="OPTUS 4 HD" tvg-logo="" group-title="AU | AUSTRALIA",OPTUS 4 HD
http://ip96.uk:8080/shakeelmirza/4110440/499831
#EXTINF:-1 tvg-id="" tvg-name="OPTUS 5 HD" tvg-logo="" group-title="AU | AUSTRALIA",OPTUS 5 HD
http://ip96.uk:8080/shakeelmirza/4110440/499832
#EXTINF:-1 tvg-id="" tvg-name="OPTUS 6 HD" tvg-logo="" group-title="AU | AUSTRALIA",OPTUS 6 HD
http://ip96.uk:8080/shakeelmirza/4110440/499833
#EXTINF:-1 tvg-id="" tvg-name="OPTUS 7 HD" tvg-logo="" group-title="AU | AUSTRALIA",OPTUS 7 HD
http://ip96.uk:8080/shakeelmirza/4110440/499834
#EXTINF:-1 tvg-id="" tvg-name="OPTUS 8 HD" tvg-logo="" group-title="AU | AUSTRALIA",OPTUS 8 HD
http://ip96.uk:8080/shakeelmirza/4110440/499835
#EXTINF:-1 tvg-id="" tvg-name="OPTUS 9 HD" tvg-logo="" group-title="AU | AUSTRALIA",OPTUS 9 HD
http://ip96.uk:8080/shakeelmirza/4110440/499836
#EXTINF:-1 tvg-id="" tvg-name="OPTUS 10 HD" tvg-logo="" group-title="AU | AUSTRALIA",OPTUS 10 HD
http://ip96.uk:8080/shakeelmirza/4110440/499837
#EXTINF:-1 tvg-id="" tvg-name="OPTUS 11 HD" tvg-logo="" group-title="AU | AUSTRALIA",OPTUS 11 HD
http://ip96.uk:8080/shakeelmirza/4110440/499838
#EXTINF:-1 tvg-id="" tvg-name="OPTUS 12 HD" tvg-logo="" group-title="AU | AUSTRALIA",OPTUS 12 HD
http://ip96.uk:8080/shakeelmirza/4110440/499839
#EXTINF:-1 tvg-id="" tvg-name="CH: NAT GEO" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-11/088d5b2df426f74f42188ca9d5cd6eb2.png" group-title="Switzerland ➾ Nature",CH: NAT GEO
http://ip96.uk:8080/shakeelmirza/4110440/315999
#EXTINF:-1 tvg-id="" tvg-name="CH: NAT GEO Wild" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-11/84dfb87e522df8221cdd3a3d07e89214.png" group-title="Switzerland ➾ Nature",CH: NAT GEO Wild
http://ip96.uk:8080/shakeelmirza/4110440/316000
#EXTINF:-1 tvg-id="" tvg-name="CH: Tele M1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/b4b7cc4911f5bf72720c645c79f31d62.png" group-title="Switzerland ➾ News",CH: Tele M1
http://ip96.uk:8080/shakeelmirza/4110440/316001
#EXTINF:-1 tvg-id="" tvg-name="CH: Telebielingue" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/a4da6595d04f8fe02bb20b5fcaa65b1a.png" group-title="Switzerland ➾ News",CH: Telebielingue
http://ip96.uk:8080/shakeelmirza/4110440/316002
#EXTINF:-1 tvg-id="" tvg-name="CH: TeleTicino" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-07/15470e5aad4d72fd2ebff81f022ff274.png" group-title="Switzerland ➾ News",CH: TeleTicino
http://ip96.uk:8080/shakeelmirza/4110440/316003
#EXTINF:-1 tvg-id="" tvg-name="CH: Disney Junior" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-11/6a8d06ea1088104b52846a4b51e272a4.png" group-title="Switzerland ➾ Kids",CH: Disney Junior
http://ip96.uk:8080/shakeelmirza/4110440/316004
#EXTINF:-1 tvg-id="" tvg-name="CH: Nick Jr" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-11/2c223db1394dd80c2e88f4e0a8fb8556.png" group-title="Switzerland ➾ Kids",CH: Nick Jr
http://ip96.uk:8080/shakeelmirza/4110440/316005
#EXTINF:-1 tvg-id="" tvg-name="CH: nickelodeon" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-11/84ea6ba0df632ea38a8d6b19e13a7b02.png" group-title="Switzerland ➾ Kids",CH: nickelodeon
http://ip96.uk:8080/shakeelmirza/4110440/316006
#EXTINF:-1 tvg-id="" tvg-name="CH: Discovery World" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/6d601ee98228bdebace57a4c9fe882b4.png" group-title="Switzerland ➾ Documentary",CH: Discovery World
http://ip96.uk:8080/shakeelmirza/4110440/316007
#EXTINF:-1 tvg-id="" tvg-name="CH: History" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-04/835a1d6dc6424bbaf8cfab7024b33813.png" group-title="Switzerland ➾ Documentary",CH: History
http://ip96.uk:8080/shakeelmirza/4110440/316008
#EXTINF:-1 tvg-id="" tvg-name="CH: Die Neue Zeit TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/552c8d1c96ed5d6e2a2ec73806b31bdb.png" group-title="Switzerland",CH: Die Neue Zeit TV
http://ip96.uk:8080/shakeelmirza/4110440/316009
#EXTINF:-1 tvg-id="" tvg-name="CH: TV 3" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Switzerland",CH: TV 3
http://ip96.uk:8080/shakeelmirza/4110440/316010
#EXTINF:-1 tvg-id="" tvg-name="CH: V Film Premiere" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-12/32e1f8665d4a201d40690885fd718a9a.png" group-title="Switzerland",CH: V Film Premiere
http://ip96.uk:8080/shakeelmirza/4110440/316011
#EXTINF:-1 tvg-id="" tvg-name="CH: Wetter TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-07/59b37716b8d6708c8d117d4a4edfa49f.jpg" group-title="Switzerland",CH: Wetter TV
http://ip96.uk:8080/shakeelmirza/4110440/316012
#EXTINF:-1 tvg-id="" tvg-name="CH: Comedy Central" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/7ad42dc58895b681ab312d8aa33dadeb.png" group-title="Switzerland ➾ Movie",CH: Comedy Central
http://ip96.uk:8080/shakeelmirza/4110440/316013
#EXTINF:-1 tvg-id="" tvg-name="CH: SYFY" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2024-03/4bd9ac68ca6b7c616b8e585d917a97b4.png" group-title="Switzerland ➾ Movie",CH: SYFY
http://ip96.uk:8080/shakeelmirza/4110440/316014
#EXTINF:-1 tvg-id="" tvg-name="CH: Blue Sport 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/1e3a6ebd017afb3fc7373b14067d6c51.png" group-title="Switzerland ➾ Sports",CH: Blue Sport 1
http://ip96.uk:8080/shakeelmirza/4110440/316015
#EXTINF:-1 tvg-id="" tvg-name="CH: Blue Sport 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/100d55fd9acdc34aeb54e4df82f87b1a.png" group-title="Switzerland ➾ Sports",CH: Blue Sport 2
http://ip96.uk:8080/shakeelmirza/4110440/316016
#EXTINF:-1 tvg-id="" tvg-name="CH: Blue Zoom D" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-04/450e5190888f692e5fb4a7ee86400be8.png" group-title="Switzerland ➾ Sports",CH: Blue Zoom D
http://ip96.uk:8080/shakeelmirza/4110440/316017
#EXTINF:-1 tvg-id="" tvg-name="CH: Eurosport 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-11/528ebfe5d69b38dae835afd3628a4956.png" group-title="Switzerland ➾ Sports",CH: Eurosport 1
http://ip96.uk:8080/shakeelmirza/4110440/316018
#EXTINF:-1 tvg-id="" tvg-name="CH: Eurosport 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-11/3084c2e5eaa87c847d42fd3ecce47718.png" group-title="Switzerland ➾ Sports",CH: Eurosport 2
http://ip96.uk:8080/shakeelmirza/4110440/316019
#EXTINF:-1 tvg-id="" tvg-name="CH: MySports 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/9da1168f90f62c51581db76c46519503.png" group-title="Switzerland ➾ Sports",CH: MySports 1
http://ip96.uk:8080/shakeelmirza/4110440/316020
#EXTINF:-1 tvg-id="" tvg-name="CH: MySports 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/67d636b0a5f449fd413c51ba188b3fb3.png" group-title="Switzerland ➾ Sports",CH: MySports 2
http://ip96.uk:8080/shakeelmirza/4110440/316021
#EXTINF:-1 tvg-id="" tvg-name="CH: MySports 3" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/3e40e700bbc67d8977b90681588e669a.png" group-title="Switzerland ➾ Sports",CH: MySports 3
http://ip96.uk:8080/shakeelmirza/4110440/316022
#EXTINF:-1 tvg-id="" tvg-name="CH: MySports 4" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/154688010fd429c30997af27ef4a7e92.png" group-title="Switzerland ➾ Sports",CH: MySports 4
http://ip96.uk:8080/shakeelmirza/4110440/316023
#EXTINF:-1 tvg-id="" tvg-name="CH: MySports 5" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/c2afd899876b86dfd5216bc85ab0e2a6.png" group-title="Switzerland ➾ Sports",CH: MySports 5
http://ip96.uk:8080/shakeelmirza/4110440/316024
#EXTINF:-1 tvg-id="" tvg-name="CH: MySports 6" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/060db78d6cef8728f844991cf695c6cb.png" group-title="Switzerland ➾ Sports",CH: MySports 6
http://ip96.uk:8080/shakeelmirza/4110440/316025
#EXTINF:-1 tvg-id="" tvg-name="CH: MySports 7" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/7e4698387844e469175e8214d75dd5a9.png" group-title="Switzerland ➾ Sports",CH: MySports 7
http://ip96.uk:8080/shakeelmirza/4110440/316026
#EXTINF:-1 tvg-id="" tvg-name="CH: MySports 8" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/236003a9f4f2078c02e5578884caaaef.png" group-title="Switzerland ➾ Sports",CH: MySports 8
http://ip96.uk:8080/shakeelmirza/4110440/316027
#EXTINF:-1 tvg-id="" tvg-name="CH: MySports 9" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/57635904fa763c7237e69c8f8490e286.png" group-title="Switzerland ➾ Sports",CH: MySports 9
http://ip96.uk:8080/shakeelmirza/4110440/316028
#EXTINF:-1 tvg-id="" tvg-name="CH: V Sport Live 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-03/5e23feca6c940eaf37b220fa1b72c6ad.svg" group-title="Switzerland ➾ Sports",CH: V Sport Live 1
http://ip96.uk:8080/shakeelmirza/4110440/316029
#EXTINF:-1 tvg-id="" tvg-name="CH: TVM 3" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/1fefd2b10ca49bba6abe26c738c810cc.png" group-title="Switzerland ➾ Music",CH: TVM 3
http://ip96.uk:8080/shakeelmirza/4110440/316030
#EXTINF:-1 tvg-id="" tvg-name="CH: W9 Suisse" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/de9365f987d0a6cba1118cc1426016d2.png" group-title="Switzerland ➾ Music",CH: W9 Suisse
http://ip96.uk:8080/shakeelmirza/4110440/316031
#EXTINF:-1 tvg-id="" tvg-name="CH: 3+" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-12/271c6d9ef8e5eb671139670ac9ddf1f2.jpg" group-title="Switzerland ➾ LifeStyle",CH: 3+
http://ip96.uk:8080/shakeelmirza/4110440/316032
#EXTINF:-1 tvg-id="" tvg-name="CH: 4+" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-11/16a2d4bc6047b7de028e4b12766c5e9a.jpg" group-title="Switzerland ➾ LifeStyle",CH: 4+
http://ip96.uk:8080/shakeelmirza/4110440/316033
#EXTINF:-1 tvg-id="" tvg-name="CH: 5+" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-11/2f3d71717d14267c3e41aab7034eab72.jpg" group-title="Switzerland ➾ LifeStyle",CH: 5+
http://ip96.uk:8080/shakeelmirza/4110440/316034
#EXTINF:-1 tvg-id="" tvg-name="CH: 6+" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-11/991697814fe1febaeec5bcd7e79190c8.jpg" group-title="Switzerland ➾ LifeStyle",CH: 6+
http://ip96.uk:8080/shakeelmirza/4110440/316035
#EXTINF:-1 tvg-id="" tvg-name="CH: 6ter Suisse" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/3825c6abda9a3fd91058756be5ba94af.png" group-title="Switzerland ➾ LifeStyle",CH: 6ter Suisse
http://ip96.uk:8080/shakeelmirza/4110440/316036
#EXTINF:-1 tvg-id="" tvg-name="CH: Canal Alpha Jura" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/de637d405976fc05d60739ea6458fa55.webp" group-title="Switzerland ➾ LifeStyle",CH: Canal Alpha Jura
http://ip96.uk:8080/shakeelmirza/4110440/316037
#EXTINF:-1 tvg-id="" tvg-name="CH: Kabel Eins Schweiz" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/35e5555ad4d52e696d2bcb162abb44f7.png" group-title="Switzerland ➾ LifeStyle",CH: Kabel Eins Schweiz
http://ip96.uk:8080/shakeelmirza/4110440/316038
#EXTINF:-1 tvg-id="" tvg-name="CH: Kanal 9" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/efff6bde8081767c6b84bffa17d14650.jpg" group-title="Switzerland ➾ LifeStyle",CH: Kanal 9
http://ip96.uk:8080/shakeelmirza/4110440/316039
#EXTINF:-1 tvg-id="" tvg-name="CH: Kanal 9 (FR)" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/5b347b83d8f53d3a28e9de000f3c6d71.jpg" group-title="Switzerland ➾ LifeStyle",CH: Kanal 9 (FR)
http://ip96.uk:8080/shakeelmirza/4110440/316040
#EXTINF:-1 tvg-id="" tvg-name="CH: LA TELE" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/a0267af626f87fbe4706d272d4a52872.png" group-title="Switzerland ➾ LifeStyle",CH: LA TELE
http://ip96.uk:8080/shakeelmirza/4110440/316041
#EXTINF:-1 tvg-id="" tvg-name="CH: M6 Suisse" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/4d46c21ba88b269e2f174db1127239eb.png" group-title="Switzerland ➾ LifeStyle",CH: M6 Suisse
http://ip96.uk:8080/shakeelmirza/4110440/316042
#EXTINF:-1 tvg-id="" tvg-name="CH: ProSieben Schweiz" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/9ab6af132e30653a4b4fd2d8407361be.png" group-title="Switzerland ➾ LifeStyle",CH: ProSieben Schweiz
http://ip96.uk:8080/shakeelmirza/4110440/316043
#EXTINF:-1 tvg-id="" tvg-name="CH: Puls Acht" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/e8d2cb2d76a559bade68e8da4e46ad86.png" group-title="Switzerland ➾ LifeStyle",CH: Puls Acht
http://ip96.uk:8080/shakeelmirza/4110440/316044
#EXTINF:-1 tvg-id="" tvg-name="CH: Rouge TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/20dce57115cfebf0daa206e844e55dff.jpg" group-title="Switzerland ➾ LifeStyle",CH: Rouge TV
http://ip96.uk:8080/shakeelmirza/4110440/316045
#EXTINF:-1 tvg-id="" tvg-name="CH: RSI La 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/3d4fd9dbf9a578a15cc5ca58cb58ebd9.png" group-title="Switzerland ➾ LifeStyle",CH: RSI La 1
http://ip96.uk:8080/shakeelmirza/4110440/316046
#EXTINF:-1 tvg-id="" tvg-name="CH: RSI La 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/c25edfb73d12a43e8193daa91e987e49.svg" group-title="Switzerland ➾ LifeStyle",CH: RSI La 2
http://ip96.uk:8080/shakeelmirza/4110440/316047
#EXTINF:-1 tvg-id="" tvg-name="CH: RTL" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-04/87c26e164238471525ed4c208b9f3785.png" group-title="Switzerland ➾ LifeStyle",CH: RTL
http://ip96.uk:8080/shakeelmirza/4110440/316048
#EXTINF:-1 tvg-id="" tvg-name="CH: RTS 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/4847db52e23df3782fd26e974c09bf85.png" group-title="Switzerland ➾ LifeStyle",CH: RTS 1
http://ip96.uk:8080/shakeelmirza/4110440/316049
#EXTINF:-1 tvg-id="" tvg-name="CH: RTS 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/60828eab0f4b53f84f6197b9464bfd9c.png" group-title="Switzerland ➾ LifeStyle",CH: RTS 2
http://ip96.uk:8080/shakeelmirza/4110440/316050
#EXTINF:-1 tvg-id="" tvg-name="CH: Sat 1 Schweiz" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/c029e9fe8fb1be39672d9bc5654acd61.png" group-title="Switzerland ➾ LifeStyle",CH: Sat 1 Schweiz
http://ip96.uk:8080/shakeelmirza/4110440/316051
#EXTINF:-1 tvg-id="" tvg-name="CH: SRF 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/ff137efd29cc494420c97edfb7462ce9.png" group-title="Switzerland ➾ LifeStyle",CH: SRF 1
http://ip96.uk:8080/shakeelmirza/4110440/316052
#EXTINF:-1 tvg-id="" tvg-name="CH: SRF Info" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/10e1c1a91b05d33a3a07b3b688214138.png" group-title="Switzerland ➾ LifeStyle",CH: SRF Info
http://ip96.uk:8080/shakeelmirza/4110440/316053
#EXTINF:-1 tvg-id="" tvg-name="CH: SRF Zwei" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-04/ebedeef3396154de7043a23cc8781851.svg" group-title="Switzerland ➾ LifeStyle",CH: SRF Zwei
http://ip96.uk:8080/shakeelmirza/4110440/316054
#EXTINF:-1 tvg-id="" tvg-name="CH: Swiss 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/7555e26c97ca117dfbd12a27790c50a1.png" group-title="Switzerland ➾ LifeStyle",CH: Swiss 1
http://ip96.uk:8080/shakeelmirza/4110440/316055
#EXTINF:-1 tvg-id="" tvg-name="CH: Tele 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-11/cd2da93882e3ae8ad6733a83b586bda7.jpg" group-title="Switzerland ➾ LifeStyle",CH: Tele 1
http://ip96.uk:8080/shakeelmirza/4110440/316056
#EXTINF:-1 tvg-id="" tvg-name="CH: Tele D" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/e29eaa351e3528cc670f19d87763d81e.webp" group-title="Switzerland ➾ LifeStyle",CH: Tele D
http://ip96.uk:8080/shakeelmirza/4110440/316057
#EXTINF:-1 tvg-id="" tvg-name="CH: TeleBarn" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/afe4ad3772f5a22fcde046820cf1e126.png" group-title="Switzerland ➾ LifeStyle",CH: TeleBarn
http://ip96.uk:8080/shakeelmirza/4110440/316058
#EXTINF:-1 tvg-id="" tvg-name="CH: Telebasel" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/014cdfd7531a30019da295e18940f392.png" group-title="Switzerland ➾ LifeStyle",CH: Telebasel
http://ip96.uk:8080/shakeelmirza/4110440/316059
#EXTINF:-1 tvg-id="" tvg-name="CH: TeleZuri" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-11/945373d36c1d5489b8704d49fe1a068f.jpg" group-title="Switzerland ➾ LifeStyle",CH: TeleZuri
http://ip96.uk:8080/shakeelmirza/4110440/316060
#EXTINF:-1 tvg-id="" tvg-name="CH: TF 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2024-01/f0394a38138864be30151ce7a559dd62.png" group-title="Switzerland ➾ LifeStyle",CH: TF 1
http://ip96.uk:8080/shakeelmirza/4110440/316061
#EXTINF:-1 tvg-id="" tvg-name="CH: TLC" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-11/04737af507abe502010b24913c4b924e.jpg" group-title="Switzerland ➾ LifeStyle",CH: TLC
http://ip96.uk:8080/shakeelmirza/4110440/316062
#EXTINF:-1 tvg-id="" tvg-name="CH: TV 24" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/c2202d24de3a6b6df5f472852086394f.png" group-title="Switzerland ➾ LifeStyle",CH: TV 24
http://ip96.uk:8080/shakeelmirza/4110440/316063
#EXTINF:-1 tvg-id="" tvg-name="CH: TV 25" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/010b491d314baee5484235eb971a3d0c.png" group-title="Switzerland ➾ LifeStyle",CH: TV 25
http://ip96.uk:8080/shakeelmirza/4110440/316064
#EXTINF:-1 tvg-id="" tvg-name="CH: TVO" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/629340de786301b316894975a7647e06.png" group-title="Switzerland ➾ LifeStyle",CH: TVO
http://ip96.uk:8080/shakeelmirza/4110440/316065
#EXTINF:-1 tvg-id="" tvg-name="HR: MTV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-12/e8d942aa6c81a24c8a30849943b403e8.png" group-title="Croatia ➾ Music",HR: MTV
http://ip96.uk:8080/shakeelmirza/4110440/317287
#EXTINF:-1 tvg-id="" tvg-name="HR: TV Banovina" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/15d251cb594a04da19d271f237bdf950.png" group-title="Croatia ➾ Music",HR: TV Banovina
http://ip96.uk:8080/shakeelmirza/4110440/317288
#EXTINF:-1 tvg-id="" tvg-name="HR: Cro Max Select 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-11/3a0f3c964ab159fd9f683f4823ac0a39.jpeg" group-title="Croatia",HR: Cro Max Select 1
http://ip96.uk:8080/shakeelmirza/4110440/317289
#EXTINF:-1 tvg-id="" tvg-name="HR: Cro Max Select 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-11/51991a5e213834169e136111913393af.jpeg" group-title="Croatia",HR: Cro Max Select 2
http://ip96.uk:8080/shakeelmirza/4110440/317290
#EXTINF:-1 tvg-id="" tvg-name="HR: Cro Max Select 3" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-11/3bc79d7b0f2b4acfda4cb09f0b3bcfbe.jpeg" group-title="Croatia",HR: Cro Max Select 3
http://ip96.uk:8080/shakeelmirza/4110440/317291
#EXTINF:-1 tvg-id="" tvg-name="HR: Cro Max Select 10" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-11/ffc492bf5004be2dd1b938a46b1213b6.jpeg" group-title="Croatia",HR: Cro Max Select 10
http://ip96.uk:8080/shakeelmirza/4110440/317292
#EXTINF:-1 tvg-id="" tvg-name="HR: Dalmacija" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Croatia",HR: Dalmacija
http://ip96.uk:8080/shakeelmirza/4110440/317293
#EXTINF:-1 tvg-id="" tvg-name="HR: Jadran TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-07/4a83dbc19cf2e925967a30857741476a.png" group-title="Croatia",HR: Jadran TV
http://ip96.uk:8080/shakeelmirza/4110440/317294
#EXTINF:-1 tvg-id="" tvg-name="HR: Jugoton TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/f63067992a429008e6d540b1ed035952.png" group-title="Croatia",HR: Jugoton TV
http://ip96.uk:8080/shakeelmirza/4110440/317295
#EXTINF:-1 tvg-id="" tvg-name="HR: Kanal Ri" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-07/dfda2dcb9e988fc1c2d4e76b215efc3f.jpg" group-title="Croatia",HR: Kanal Ri
http://ip96.uk:8080/shakeelmirza/4110440/317296
#EXTINF:-1 tvg-id="" tvg-name="HR: Laudato TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/f40339fc243210e0cb5a5b794a25fb6b.png" group-title="Croatia",HR: Laudato TV
http://ip96.uk:8080/shakeelmirza/4110440/317297
#EXTINF:-1 tvg-id="" tvg-name="HR: Mreza Zagreb" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/c411bfa6e618afb79309fad48d84d541.jpg" group-title="Croatia",HR: Mreza Zagreb
http://ip96.uk:8080/shakeelmirza/4110440/317298
#EXTINF:-1 tvg-id="" tvg-name="HR: Nova Pula" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/c78fc9a903d3c9ff6a41d993575ff2d2.jpg" group-title="Croatia",HR: Nova Pula
http://ip96.uk:8080/shakeelmirza/4110440/317299
#EXTINF:-1 tvg-id="" tvg-name="HR: Plava Vinkovačka" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/b9fa86888bcca07be9c418688aca3820.jpg" group-title="Croatia",HR: Plava Vinkovačka
http://ip96.uk:8080/shakeelmirza/4110440/317300
#EXTINF:-1 tvg-id="" tvg-name="HR: Poljoprivredna TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/1f7cb9e030eb146717472f16cfbf6a76.jpg" group-title="Croatia",HR: Poljoprivredna TV
http://ip96.uk:8080/shakeelmirza/4110440/317301
#EXTINF:-1 tvg-id="" tvg-name="HR: SBTV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/ec2d4b35c52a051d0858117b826b4573.png" group-title="Croatia",HR: SBTV
http://ip96.uk:8080/shakeelmirza/4110440/317302
#EXTINF:-1 tvg-id="" tvg-name="HR: Slavonska TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/f5c7fc8f191b12a85b4c4339138e1a6e.jpg" group-title="Croatia",HR: Slavonska TV
http://ip96.uk:8080/shakeelmirza/4110440/317303
#EXTINF:-1 tvg-id="" tvg-name="HR: Star Crime" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Croatia",HR: Star Crime
http://ip96.uk:8080/shakeelmirza/4110440/317304
#EXTINF:-1 tvg-id="" tvg-name="HR: TV Trend Karlovac" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-09/4bc183c21c4981faf62c50013fed4bdd.jpg" group-title="Croatia",HR: TV Trend Karlovac
http://ip96.uk:8080/shakeelmirza/4110440/317305
#EXTINF:-1 tvg-id="" tvg-name="HR: VTV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-08/a84a1f65d4c4700fef43785d11366265.png" group-title="Croatia",HR: VTV
http://ip96.uk:8080/shakeelmirza/4110440/317306
#EXTINF:-1 tvg-id="" tvg-name="HR: Z1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/5dc87e86b37fba3bd6e58817a79754a0.png" group-title="Croatia",HR: Z1
http://ip96.uk:8080/shakeelmirza/4110440/317307
#EXTINF:-1 tvg-id="" tvg-name="HR: Zapad" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/0ef97f55079ec972001648160602153c.png" group-title="Croatia",HR: Zapad
http://ip96.uk:8080/shakeelmirza/4110440/317308
#EXTINF:-1 tvg-id="" tvg-name="HR: Crime+ Investigation" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/ad9653524d39e6cd6fa0f7be2429903a.png" group-title="Croatia ➾ Documentary",HR: Crime+ Investigation
http://ip96.uk:8080/shakeelmirza/4110440/317309
#EXTINF:-1 tvg-id="" tvg-name="HR: Discovery World" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/2ff14441804407d39aa4eb2553382f2b.png" group-title="Croatia ➾ Documentary",HR: Discovery World
http://ip96.uk:8080/shakeelmirza/4110440/317310
#EXTINF:-1 tvg-id="" tvg-name="HR: DocuBox" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/64843124bd2efb30a9187f69300372d6.png" group-title="Croatia ➾ Documentary",HR: DocuBox
http://ip96.uk:8080/shakeelmirza/4110440/317311
#EXTINF:-1 tvg-id="" tvg-name="HR: Doku TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/a899e66151c0ad8ce2a4b4a8a411b55b.png" group-title="Croatia ➾ Documentary",HR: Doku TV
http://ip96.uk:8080/shakeelmirza/4110440/317312
#EXTINF:-1 tvg-id="" tvg-name="HR: History" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/066fb601b8a7a918e2d0979564a9491e.png" group-title="Croatia ➾ Documentary",HR: History
http://ip96.uk:8080/shakeelmirza/4110440/317313
#EXTINF:-1 tvg-id="" tvg-name="HR: History 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/84dbc3d80d60a6c25fa61a4541eb3b5e.jpg" group-title="Croatia ➾ Documentary",HR: History 2
http://ip96.uk:8080/shakeelmirza/4110440/317314
#EXTINF:-1 tvg-id="" tvg-name="HR: sci-fi" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/cf9ab5b80e06c25c1efe401f6ffe0818.jpg" group-title="Croatia ➾ Documentary",HR: sci-fi
http://ip96.uk:8080/shakeelmirza/4110440/317315
#EXTINF:-1 tvg-id="" tvg-name="HR: Viasat Explore" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/06480719e59f295b057df972ec37c71f.jpg" group-title="Croatia ➾ Documentary",HR: Viasat Explore
http://ip96.uk:8080/shakeelmirza/4110440/317316
#EXTINF:-1 tvg-id="" tvg-name="HR: Viasat History" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/5ba44a5f3944a8e7576334d949551203.png" group-title="Croatia ➾ Documentary",HR: Viasat History
http://ip96.uk:8080/shakeelmirza/4110440/317317
#EXTINF:-1 tvg-id="" tvg-name="HR: Baby TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-10/e01a5320e11e2ae60e8424d235e10bc6.png" group-title="Croatia ➾ Kids",HR: Baby TV
http://ip96.uk:8080/shakeelmirza/4110440/317318
#EXTINF:-1 tvg-id="" tvg-name="HR: Da Vinci" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/6106e7e7b9daf64e9552ac6f365ec74c.png" group-title="Croatia ➾ Kids",HR: Da Vinci
http://ip96.uk:8080/shakeelmirza/4110440/317319
#EXTINF:-1 tvg-id="" tvg-name="HR: Mini TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/ad04d5b0c0b50ac8b5dcdf4efc332469.jpg" group-title="Croatia ➾ Kids",HR: Mini TV
http://ip96.uk:8080/shakeelmirza/4110440/317320
#EXTINF:-1 tvg-id="" tvg-name="HR: Minimax" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/6628ce783a036a517564d6cadc0d6f83.jpg" group-title="Croatia ➾ Kids",HR: Minimax
http://ip96.uk:8080/shakeelmirza/4110440/317321
#EXTINF:-1 tvg-id="" tvg-name="HR: Nick Jr" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/6d4cbd12e46e0ee58278e8ead269fc56.jpg" group-title="Croatia ➾ Kids",HR: Nick Jr
http://ip96.uk:8080/shakeelmirza/4110440/317322
#EXTINF:-1 tvg-id="" tvg-name="HR: nickelodeon" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/64bd3dedbea5dfab62600808a6978dc3.png" group-title="Croatia ➾ Kids",HR: nickelodeon
http://ip96.uk:8080/shakeelmirza/4110440/317323
#EXTINF:-1 tvg-id="" tvg-name="HR: RTL Kockica" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/c057014b55c8618f652318656608e6a4.png" group-title="Croatia ➾ Kids",HR: RTL Kockica
http://ip96.uk:8080/shakeelmirza/4110440/317324
#EXTINF:-1 tvg-id="" tvg-name="HR: Arena Sport 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/3e22bab3e6cc787ceb5445d6c4fad694.png" group-title="Croatia ➾ Sports",HR: Arena Sport 1
http://ip96.uk:8080/shakeelmirza/4110440/317325
#EXTINF:-1 tvg-id="" tvg-name="HR: Arena Sport 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/8540b09c6c9b9e4fe035d27166426736.png" group-title="Croatia ➾ Sports",HR: Arena Sport 2
http://ip96.uk:8080/shakeelmirza/4110440/317326
#EXTINF:-1 tvg-id="" tvg-name="HR: Arena Sport 3" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/37f61d2b06d6d3ae0fd3d72f35ee378f.png" group-title="Croatia ➾ Sports",HR: Arena Sport 3
http://ip96.uk:8080/shakeelmirza/4110440/317327
#EXTINF:-1 tvg-id="" tvg-name="HR: Arena Sport 4" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/ef9d0183b1ffd0b974331dcfe61fc406.png" group-title="Croatia ➾ Sports",HR: Arena Sport 4
http://ip96.uk:8080/shakeelmirza/4110440/317328
#EXTINF:-1 tvg-id="" tvg-name="HR: Arena Sport 5" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/c0c30bf1d801dfbe422d0f51a31304e0.png" group-title="Croatia ➾ Sports",HR: Arena Sport 5
http://ip96.uk:8080/shakeelmirza/4110440/317329
#EXTINF:-1 tvg-id="" tvg-name="HR: Arena Sport 6" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/39ce59ded26a6843304e3ca4404c597f.png" group-title="Croatia ➾ Sports",HR: Arena Sport 6
http://ip96.uk:8080/shakeelmirza/4110440/317330
#EXTINF:-1 tvg-id="" tvg-name="HR: Arena Sport 10" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-02/8d9ca9457428f300218cbaececaa3c67.jpg" group-title="Croatia ➾ Sports",HR: Arena Sport 10
http://ip96.uk:8080/shakeelmirza/4110440/317331
#EXTINF:-1 tvg-id="" tvg-name="HR: Max Sport 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-07/67da0ff1699bec193a3d4264c0fdb302.png" group-title="Croatia ➾ Sports",HR: Max Sport 1
http://ip96.uk:8080/shakeelmirza/4110440/317332
#EXTINF:-1 tvg-id="" tvg-name="HR: Max Sport 2" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Croatia ➾ Sports",HR: Max Sport 2
http://ip96.uk:8080/shakeelmirza/4110440/317333
#EXTINF:-1 tvg-id="" tvg-name="HR: Sport Klub 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/5a85ec354802e6b85738a13c83d8fb3f.png" group-title="Croatia ➾ Sports",HR: Sport Klub 1
http://ip96.uk:8080/shakeelmirza/4110440/317334
#EXTINF:-1 tvg-id="" tvg-name="HR: Sport Klub 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/f03f8c517a5e79b9e8e927180496370d.png" group-title="Croatia ➾ Sports",HR: Sport Klub 2
http://ip96.uk:8080/shakeelmirza/4110440/317335
#EXTINF:-1 tvg-id="" tvg-name="HR: Sport Klub 3" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/3ee32511f85cad4408168d2700fb53d7.png" group-title="Croatia ➾ Sports",HR: Sport Klub 3
http://ip96.uk:8080/shakeelmirza/4110440/317336
#EXTINF:-1 tvg-id="" tvg-name="HR: Sport Klub 4" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-10/6dced90dd3378bb441466083f850e29b.jpg" group-title="Croatia ➾ Sports",HR: Sport Klub 4
http://ip96.uk:8080/shakeelmirza/4110440/317337
#EXTINF:-1 tvg-id="" tvg-name="HR: Sport Klub 5" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-11/753a33149eb926e7492903efb13367f5.jpg" group-title="Croatia ➾ Sports",HR: Sport Klub 5
http://ip96.uk:8080/shakeelmirza/4110440/317338
#EXTINF:-1 tvg-id="" tvg-name="HR: Sport Klub FIGHT" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-04/bc89e1ef81ba352752194ae6d02d3af5.png" group-title="Croatia ➾ Sports",HR: Sport Klub FIGHT
http://ip96.uk:8080/shakeelmirza/4110440/317339
#EXTINF:-1 tvg-id="" tvg-name="HR: Sportska" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/f38218991f3979bdcd26e2f94fa5b5fd.png" group-title="Croatia ➾ Sports",HR: Sportska
http://ip96.uk:8080/shakeelmirza/4110440/317340
#EXTINF:-1 tvg-id="" tvg-name="HR: ANIMAL PLANET" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/97e0294e8e35f7313d5ebe52d9d1a26f.png" group-title="Croatia ➾ Nature",HR: ANIMAL PLANET
http://ip96.uk:8080/shakeelmirza/4110440/317341
#EXTINF:-1 tvg-id="" tvg-name="HR: Lov i Ribolov" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/408ea7de15df2ad7d91ea22241d63e28.png" group-title="Croatia ➾ Nature",HR: Lov i Ribolov
http://ip96.uk:8080/shakeelmirza/4110440/317342
#EXTINF:-1 tvg-id="" tvg-name="HR: NAT GEO Wild" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/330b3b21ad24d9696ead334dba4eee0c.png" group-title="Croatia ➾ Nature",HR: NAT GEO Wild
http://ip96.uk:8080/shakeelmirza/4110440/317343
#EXTINF:-1 tvg-id="" tvg-name="HR: Viasat Nature" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/4c6a51a91f66fdf7974d4f2c74abdb64.png" group-title="Croatia ➾ Nature",HR: Viasat Nature
http://ip96.uk:8080/shakeelmirza/4110440/317344
#EXTINF:-1 tvg-id="" tvg-name="HR: Zdrava TV 7 Hrvatska" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/a3fc476b5d5e94d711c14efa62d883f7.jpeg" group-title="Croatia ➾ Nature",HR: Zdrava TV 7 Hrvatska
http://ip96.uk:8080/shakeelmirza/4110440/317345
#EXTINF:-1 tvg-id="" tvg-name="HR: AMC" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/636f40d407c3c5edcd4b1dd4607ac4e6.png" group-title="Croatia ➾ Movie",HR: AMC
http://ip96.uk:8080/shakeelmirza/4110440/317346
#EXTINF:-1 tvg-id="" tvg-name="HR: AXN" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/0bcb3f0a3022440d18060c631e45a3f8.png" group-title="Croatia ➾ Movie",HR: AXN
http://ip96.uk:8080/shakeelmirza/4110440/317347
#EXTINF:-1 tvg-id="" tvg-name="HR: AXN Spin" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-11/883fb6c0682ea316854ca13a19216021.png" group-title="Croatia ➾ Movie",HR: AXN Spin
http://ip96.uk:8080/shakeelmirza/4110440/317348
#EXTINF:-1 tvg-id="" tvg-name="HR: Cinemax" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/63a2c4c44a4f43187d2baac3eb5e0ede.png" group-title="Croatia ➾ Movie",HR: Cinemax
http://ip96.uk:8080/shakeelmirza/4110440/317349
#EXTINF:-1 tvg-id="" tvg-name="HR: Cinemax 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/f739f4f7e001ea7ef066abf9651a316d.png" group-title="Croatia ➾ Movie",HR: Cinemax 2
http://ip96.uk:8080/shakeelmirza/4110440/317350
#EXTINF:-1 tvg-id="" tvg-name="HR: CineStar TV 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/af9954b773e0d1cca8eb14d65d28d6d2.png" group-title="Croatia ➾ Movie",HR: CineStar TV 1
http://ip96.uk:8080/shakeelmirza/4110440/317351
#EXTINF:-1 tvg-id="" tvg-name="HR: CineStar TV 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-04/c04660341338df055a2bcc65c8ffdd8b.png" group-title="Croatia ➾ Movie",HR: CineStar TV 2
http://ip96.uk:8080/shakeelmirza/4110440/317352
#EXTINF:-1 tvg-id="" tvg-name="HR: CineStar TV Action" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/882a349e4965e633d5834ea58991fc1a.png" group-title="Croatia ➾ Movie",HR: CineStar TV Action
http://ip96.uk:8080/shakeelmirza/4110440/317353
#EXTINF:-1 tvg-id="" tvg-name="HR: CineStar TV Comedy" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/c5715e0750f0e1c3ba7917175c22c454.png" group-title="Croatia ➾ Movie",HR: CineStar TV Comedy
http://ip96.uk:8080/shakeelmirza/4110440/317354
#EXTINF:-1 tvg-id="" tvg-name="HR: CineStar TV Fantasy" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/56fea0caca577477db0ba8e291af0ecc.png" group-title="Croatia ➾ Movie",HR: CineStar TV Fantasy
http://ip96.uk:8080/shakeelmirza/4110440/317355
#EXTINF:-1 tvg-id="" tvg-name="HR: CineStar TV Premiere 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/5013895bd4d3d26baea072bc95825517.png" group-title="Croatia ➾ Movie",HR: CineStar TV Premiere 1
http://ip96.uk:8080/shakeelmirza/4110440/317356
#EXTINF:-1 tvg-id="" tvg-name="HR: CineStar TV Premiere 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/be4a33dfdf0b2b0b0090e45aacab262e.png" group-title="Croatia ➾ Movie",HR: CineStar TV Premiere 2
http://ip96.uk:8080/shakeelmirza/4110440/317357
#EXTINF:-1 tvg-id="" tvg-name="HR: FilmBox Extra" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-07/2bad446e99300922d325aa148ccf696e.png" group-title="Croatia ➾ Movie",HR: FilmBox Extra
http://ip96.uk:8080/shakeelmirza/4110440/317358
#EXTINF:-1 tvg-id="" tvg-name="HR: Fox Movies" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/39691672a0465118f82ae7e08f6d06ba.png" group-title="Croatia ➾ Movie",HR: Fox Movies
http://ip96.uk:8080/shakeelmirza/4110440/317359
#EXTINF:-1 tvg-id="" tvg-name="HR: HBO" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/3ae303aae3e2b684739423f1de2fd060.png" group-title="Croatia ➾ Movie",HR: HBO
http://ip96.uk:8080/shakeelmirza/4110440/317360
#EXTINF:-1 tvg-id="" tvg-name="HR: HBO 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/1734ce2a1a4aed3db9c3fdf4d7ec92d0.png" group-title="Croatia ➾ Movie",HR: HBO 2
http://ip96.uk:8080/shakeelmirza/4110440/317361
#EXTINF:-1 tvg-id="" tvg-name="HR: HBO 3" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/12b642531a6fb692a7d6377e0d52e643.png" group-title="Croatia ➾ Movie",HR: HBO 3
http://ip96.uk:8080/shakeelmirza/4110440/317362
#EXTINF:-1 tvg-id="" tvg-name="HR: Kino TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/e5d7f013cf0fa17b6a7147794bdad0af.png" group-title="Croatia ➾ Movie",HR: Kino TV
http://ip96.uk:8080/shakeelmirza/4110440/317363
#EXTINF:-1 tvg-id="" tvg-name="HR: Klasik TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-07/867e2504821ebbcd7add6f344ded707e.png" group-title="Croatia ➾ Movie",HR: Klasik TV
http://ip96.uk:8080/shakeelmirza/4110440/317364
#EXTINF:-1 tvg-id="" tvg-name="HR: M1 Film" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/ff7fa7200a1f02efe4c5eb4584373ca4.png" group-title="Croatia ➾ Movie",HR: M1 Film
http://ip96.uk:8080/shakeelmirza/4110440/317365
#EXTINF:-1 tvg-id="" tvg-name="HR: M1 Film Gold" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/c2d39c0b3c702c189c9547d4140c1083.jpg" group-title="Croatia ➾ Movie",HR: M1 Film Gold
http://ip96.uk:8080/shakeelmirza/4110440/317366
#EXTINF:-1 tvg-id="" tvg-name="HR: Nova Cinema" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/3f944fd75334000acf7cef2dd1738028.png" group-title="Croatia ➾ Movie",HR: Nova Cinema
http://ip96.uk:8080/shakeelmirza/4110440/317367
#EXTINF:-1 tvg-id="" tvg-name="HR: Nova Family" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/abe55efbfb39d62492863d784d639061.webp" group-title="Croatia ➾ Movie",HR: Nova Family
http://ip96.uk:8080/shakeelmirza/4110440/317368
#EXTINF:-1 tvg-id="" tvg-name="HR: Nova TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/704b1c5f5c4a08721ffeec638df0b2b7.png" group-title="Croatia ➾ Movie",HR: Nova TV
http://ip96.uk:8080/shakeelmirza/4110440/317369
#EXTINF:-1 tvg-id="" tvg-name="HR: PickBox TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/c527c800eb2395171fe9ae6b5f3a16d8.png" group-title="Croatia ➾ Movie",HR: PickBox TV
http://ip96.uk:8080/shakeelmirza/4110440/317370
#EXTINF:-1 tvg-id="" tvg-name="HR: TV 1000 Balkan" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/0b0bcb2c6d1de7eab6fc0b9446bffe5e.png" group-title="Croatia ➾ Movie",HR: TV 1000 Balkan
http://ip96.uk:8080/shakeelmirza/4110440/317371
#EXTINF:-1 tvg-id="" tvg-name="HR: AlJazeera Balkans" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-07/c48b0f068df9fa2072a3f5b10389e402.png" group-title="Croatia ➾ News",HR: AlJazeera Balkans
http://ip96.uk:8080/shakeelmirza/4110440/317372
#EXTINF:-1 tvg-id="" tvg-name="HR: N1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/22b8cac13cef90d23088b333b6e37898.png" group-title="Croatia ➾ News",HR: N1
http://ip96.uk:8080/shakeelmirza/4110440/317373
#EXTINF:-1 tvg-id="" tvg-name="HR: RTL Croatia World" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/a16266ac16f0503f57385c3e5fb46267.jpg" group-title="Croatia ➾ News",HR: RTL Croatia World
http://ip96.uk:8080/shakeelmirza/4110440/317374
#EXTINF:-1 tvg-id="" tvg-name="HR: 24 Kitchen" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/b445afbcddd40be002f73b8e1dd80cd7.jpg" group-title="Croatia ➾ LifeStyle",HR: 24 Kitchen
http://ip96.uk:8080/shakeelmirza/4110440/317375
#EXTINF:-1 tvg-id="" tvg-name="HR: CMC TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/7c0ef7597ff5639c6421d81b16bb2426.png" group-title="Croatia ➾ LifeStyle",HR: CMC TV
http://ip96.uk:8080/shakeelmirza/4110440/317376
#EXTINF:-1 tvg-id="" tvg-name="HR: Diva" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/df31da680832425749d2a55411dacbeb.png" group-title="Croatia ➾ LifeStyle",HR: Diva
http://ip96.uk:8080/shakeelmirza/4110440/317377
#EXTINF:-1 tvg-id="" tvg-name="HR: Doma" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/1f5b7a4b191ae61a9873bd172a769d07.png" group-title="Croatia ➾ LifeStyle",HR: Doma
http://ip96.uk:8080/shakeelmirza/4110440/317378
#EXTINF:-1 tvg-id="" tvg-name="HR: E!" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-10/89252911b756b7c9cd2b58735aae9735.png" group-title="Croatia ➾ LifeStyle",HR: E!
http://ip96.uk:8080/shakeelmirza/4110440/317379
#EXTINF:-1 tvg-id="" tvg-name="HR: HRT 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/e638e112d71f62fda4106a5342c0faea.png" group-title="Croatia ➾ LifeStyle",HR: HRT 1
http://ip96.uk:8080/shakeelmirza/4110440/317380
#EXTINF:-1 tvg-id="" tvg-name="HR: HRT 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/239c1863d4a52a75f23270d06046a1b2.png" group-title="Croatia ➾ LifeStyle",HR: HRT 2
http://ip96.uk:8080/shakeelmirza/4110440/317381
#EXTINF:-1 tvg-id="" tvg-name="HR: HRT 3" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/28f5aa4d318a562bf4e5b5a957bf7a17.png" group-title="Croatia ➾ LifeStyle",HR: HRT 3
http://ip96.uk:8080/shakeelmirza/4110440/317382
#EXTINF:-1 tvg-id="" tvg-name="HR: HRT 4" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/e50efd3f22334812874071283901e31d.png" group-title="Croatia ➾ LifeStyle",HR: HRT 4
http://ip96.uk:8080/shakeelmirza/4110440/317383
#EXTINF:-1 tvg-id="" tvg-name="HR: HRT International" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/12b0a52eba86788f8cdc347ffc51b38e.png" group-title="Croatia ➾ LifeStyle",HR: HRT International
http://ip96.uk:8080/shakeelmirza/4110440/317384
#EXTINF:-1 tvg-id="" tvg-name="HR: Nova World" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/7ea74876172ce67279f1851b6ce27dfd.jpg" group-title="Croatia ➾ LifeStyle",HR: Nova World
http://ip96.uk:8080/shakeelmirza/4110440/317385
#EXTINF:-1 tvg-id="" tvg-name="HR: Osjecka TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/d4fa803d63e7fae2d172617c0fe0b841.jpg" group-title="Croatia ➾ LifeStyle",HR: Osjecka TV
http://ip96.uk:8080/shakeelmirza/4110440/317386
#EXTINF:-1 tvg-id="" tvg-name="HR: RTL" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/5e99a0654a1f0f70e98d7cf10a41d56a.png" group-title="Croatia ➾ LifeStyle",HR: RTL
http://ip96.uk:8080/shakeelmirza/4110440/317387
#EXTINF:-1 tvg-id="" tvg-name="HR: RTL 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/0c072fc01b01764afac304b225510f71.png" group-title="Croatia ➾ LifeStyle",HR: RTL 2
http://ip96.uk:8080/shakeelmirza/4110440/317388
#EXTINF:-1 tvg-id="" tvg-name="HR: RTL Adria" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/9f134c52672074e036e419160133aaa7.png" group-title="Croatia ➾ LifeStyle",HR: RTL Adria
http://ip96.uk:8080/shakeelmirza/4110440/317389
#EXTINF:-1 tvg-id="" tvg-name="HR: RTL Crime" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/ef5872ca10b929e893e2441e99b1dd80.png" group-title="Croatia ➾ LifeStyle",HR: RTL Crime
http://ip96.uk:8080/shakeelmirza/4110440/317390
#EXTINF:-1 tvg-id="" tvg-name="HR: RTL Living" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/2999daf3abbdf7491ecf80d0cd4b8310.png" group-title="Croatia ➾ LifeStyle",HR: RTL Living
http://ip96.uk:8080/shakeelmirza/4110440/317391
#EXTINF:-1 tvg-id="" tvg-name="HR: RTL Passion" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/9c4c249c38ea801c3ea7a3bd70a0a84e.png" group-title="Croatia ➾ LifeStyle",HR: RTL Passion
http://ip96.uk:8080/shakeelmirza/4110440/317392
#EXTINF:-1 tvg-id="" tvg-name="HR: TLC" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/913412eb5f73309fcaa80831a809bb1f.png" group-title="Croatia ➾ LifeStyle",HR: TLC
http://ip96.uk:8080/shakeelmirza/4110440/317393
#EXTINF:-1 tvg-id="" tvg-name="BE: AB 3" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/efb7525e3306527abbdc1e223eee61ff.png" group-title="Belgium",BE: AB 3
http://ip96.uk:8080/shakeelmirza/4110440/317600
#EXTINF:-1 tvg-id="" tvg-name="BE: AB Xplore" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/8b8f83903f011d9f6ee0e72ce7a480b8.png" group-title="Belgium",BE: AB Xplore
http://ip96.uk:8080/shakeelmirza/4110440/317601
#EXTINF:-1 tvg-id="" tvg-name="BE: Bel RTL" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/db6465b944eeeab22529849c5c2cb737.png" group-title="Belgium",BE: Bel RTL
http://ip96.uk:8080/shakeelmirza/4110440/317602
#EXTINF:-1 tvg-id="" tvg-name="BE: Boomerang" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-12/438829f28228280fa49faa086e333815.png" group-title="Belgium",BE: Boomerang
http://ip96.uk:8080/shakeelmirza/4110440/317603
#EXTINF:-1 tvg-id="" tvg-name="BE: bx1 Redif" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/56211d7d01381955f18803db4acd852d.jpg" group-title="Belgium",BE: bx1 Redif
http://ip96.uk:8080/shakeelmirza/4110440/317604
#EXTINF:-1 tvg-id="" tvg-name="BE: Canal Atlas" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/ce429f774e7c44d4bb16b1956446af79.png" group-title="Belgium",BE: Canal Atlas
http://ip96.uk:8080/shakeelmirza/4110440/317605
#EXTINF:-1 tvg-id="" tvg-name="BE: Canvas" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Belgium",BE: Canvas
http://ip96.uk:8080/shakeelmirza/4110440/317606
#EXTINF:-1 tvg-id="" tvg-name="BE: City Music" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/cd14d1ed71f101ff6a3242901a44a7f1.jpg" group-title="Belgium",BE: City Music
http://ip96.uk:8080/shakeelmirza/4110440/317607
#EXTINF:-1 tvg-id="" tvg-name="BE: EbS+" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-07/bfce80bbc4ae43f2d9bd7661496225a2.png" group-title="Belgium",BE: EbS+
http://ip96.uk:8080/shakeelmirza/4110440/317608
#EXTINF:-1 tvg-id="" tvg-name="BE: Eclips TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/44837927107b6937605dc1abf6e67c25.png" group-title="Belgium",BE: Eclips TV
http://ip96.uk:8080/shakeelmirza/4110440/317609
#EXTINF:-1 tvg-id="" tvg-name="BE: Een" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/76831ec50d2a45f72392e65a5e67f218.png" group-title="Belgium",BE: Een
http://ip96.uk:8080/shakeelmirza/4110440/317610
#EXTINF:-1 tvg-id="" tvg-name="BE: Eldo Radio TV Luxembourg" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/63105eed44f2ccaa06405254385841c4.jpg" group-title="Belgium",BE: Eldo Radio TV Luxembourg
http://ip96.uk:8080/shakeelmirza/4110440/317611
#EXTINF:-1 tvg-id="" tvg-name="BE: ELEVEN SPORTS 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/3ce96de2bbb24a056acf10765f000d48.png" group-title="Belgium",BE: ELEVEN SPORTS 1
http://ip96.uk:8080/shakeelmirza/4110440/317612
#EXTINF:-1 tvg-id="" tvg-name="BE: ELEVEN SPORTS 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/cce2a70fbce9c36d42cef63e6da8c3f8.png" group-title="Belgium",BE: ELEVEN SPORTS 2
http://ip96.uk:8080/shakeelmirza/4110440/317613
#EXTINF:-1 tvg-id="" tvg-name="BE: ELEVEN SPORTS 3" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-02/ad32ef6fe9e5cbcdb683b77c5624e060.png" group-title="Belgium",BE: ELEVEN SPORTS 3
http://ip96.uk:8080/shakeelmirza/4110440/317614
#EXTINF:-1 tvg-id="" tvg-name="BE: FashionTV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/cdbe83830d2ee1b1909403537a2515e9.png" group-title="Belgium",BE: FashionTV
http://ip96.uk:8080/shakeelmirza/4110440/317615
#EXTINF:-1 tvg-id="" tvg-name="BE: Ketnet" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/388af359750018b480c98dcd3778e515.png" group-title="Belgium",BE: Ketnet
http://ip96.uk:8080/shakeelmirza/4110440/317616
#EXTINF:-1 tvg-id="" tvg-name="BE: Ketnet Junior" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/488737ab864736771fb5d24facc85414.png" group-title="Belgium",BE: Ketnet Junior
http://ip96.uk:8080/shakeelmirza/4110440/317617
#EXTINF:-1 tvg-id="" tvg-name="BE: La Une" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/f0cb66c35b817e5cb6dc370d9b77ece6.png" group-title="Belgium",BE: La Une
http://ip96.uk:8080/shakeelmirza/4110440/317618
#EXTINF:-1 tvg-id="" tvg-name="BE: LN 24" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/35752949fb158df37f8779f07181cb00.jpg" group-title="Belgium",BE: LN 24
http://ip96.uk:8080/shakeelmirza/4110440/317619
#EXTINF:-1 tvg-id="" tvg-name="BE: Matele" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/07c9714a35b473f02d8b0afb83c61e7d.png" group-title="Belgium",BE: Matele
http://ip96.uk:8080/shakeelmirza/4110440/317620
#EXTINF:-1 tvg-id="" tvg-name="BE: Ment" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/5bb04e55eee129c639b0acb79a42e422.png" group-title="Belgium",BE: Ment
http://ip96.uk:8080/shakeelmirza/4110440/317621
#EXTINF:-1 tvg-id="" tvg-name="BE: Nat Geo" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/fc25a1854abbc94a01f2c90f00896c6a.png" group-title="Belgium",BE: Nat Geo
http://ip96.uk:8080/shakeelmirza/4110440/317622
#EXTINF:-1 tvg-id="" tvg-name="BE: Nat Geo Wild" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/f76964375c9d1dafdb14a8fbc434573c.png" group-title="Belgium",BE: Nat Geo Wild
http://ip96.uk:8080/shakeelmirza/4110440/317623
#EXTINF:-1 tvg-id="" tvg-name="BE: Notele" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/19ed27135ad466ebc5818a3382ab23fc.png" group-title="Belgium",BE: Notele
http://ip96.uk:8080/shakeelmirza/4110440/317624
#EXTINF:-1 tvg-id="" tvg-name="BE: Ouftivi" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-06/8754ae9dcd02f76bae579b2c9f902f3e.png" group-title="Belgium",BE: Ouftivi
http://ip96.uk:8080/shakeelmirza/4110440/317625
#EXTINF:-1 tvg-id="" tvg-name="BE: Petange Info TV (Luxembourg)" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/29750a2ad75e6df7329182def650e879.png" group-title="Belgium",BE: Petange Info TV (Luxembourg)
http://ip96.uk:8080/shakeelmirza/4110440/317626
#EXTINF:-1 tvg-id="" tvg-name="BE: Play 4" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/e939f1a1505e7b8483c0b3f9b32d3f47.png" group-title="Belgium",BE: Play 4
http://ip96.uk:8080/shakeelmirza/4110440/317627
#EXTINF:-1 tvg-id="" tvg-name="BE: Play 5" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/785ee8086bb5530c9626dd8196816cb7.png" group-title="Belgium",BE: Play 5
http://ip96.uk:8080/shakeelmirza/4110440/317628
#EXTINF:-1 tvg-id="" tvg-name="BE: Play 6" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/46f7f8f81d45db74778bcff90c214e8c.png" group-title="Belgium",BE: Play 6
http://ip96.uk:8080/shakeelmirza/4110440/317629
#EXTINF:-1 tvg-id="" tvg-name="BE: Play 7" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/11a343012a31c0bcc7942fc03fe4e400.png" group-title="Belgium",BE: Play 7
http://ip96.uk:8080/shakeelmirza/4110440/317630
#EXTINF:-1 tvg-id="" tvg-name="BE: Play Sports 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/e326a62a0113f1ce66bf3a143b614ab6.jpg" group-title="Belgium",BE: Play Sports 1
http://ip96.uk:8080/shakeelmirza/4110440/317631
#EXTINF:-1 tvg-id="" tvg-name="BE: Play Sports 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/2ec2fbcad5e371a4951d181ecf7d2b5d.jpg" group-title="Belgium",BE: Play Sports 2
http://ip96.uk:8080/shakeelmirza/4110440/317632
#EXTINF:-1 tvg-id="" tvg-name="BE: Play Sports 3" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/f022842b3343a7c7e20c7935d69fcfe1.jpg" group-title="Belgium",BE: Play Sports 3
http://ip96.uk:8080/shakeelmirza/4110440/317633
#EXTINF:-1 tvg-id="" tvg-name="BE: Q music Vlaanderen" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/31e3dd1f2be83dc6db30d872a9552130.png" group-title="Belgium",BE: Q music Vlaanderen
http://ip96.uk:8080/shakeelmirza/4110440/317634
#EXTINF:-1 tvg-id="" tvg-name="BE: Radio Pros" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/385a038767300b6d6815ce87508d9aed.png" group-title="Belgium",BE: Radio Pros
http://ip96.uk:8080/shakeelmirza/4110440/317635
#EXTINF:-1 tvg-id="" tvg-name="BE: RTBF La Trois" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/9d9a3829354a7a80f939feda45eccade.png" group-title="Belgium",BE: RTBF La Trois
http://ip96.uk:8080/shakeelmirza/4110440/317636
#EXTINF:-1 tvg-id="" tvg-name="BE: RTL Club" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-04/db95ac5654dc7e35586ddee24d0bd0aa.png" group-title="Belgium",BE: RTL Club
http://ip96.uk:8080/shakeelmirza/4110440/317637
#EXTINF:-1 tvg-id="" tvg-name="BE: RTL Luxembourg" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-04/af1e760b6703469936b52e1637226bdf.png" group-title="Belgium",BE: RTL Luxembourg
http://ip96.uk:8080/shakeelmirza/4110440/317638
#EXTINF:-1 tvg-id="" tvg-name="BE: RTL Luxembourg Zwee" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/59b8d3e7ad56f307ecd0b54dab78bb57.png" group-title="Belgium",BE: RTL Luxembourg Zwee
http://ip96.uk:8080/shakeelmirza/4110440/317639
#EXTINF:-1 tvg-id="" tvg-name="BE: RTL Plug" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/47bdb3b8531b84d786f440416c66410d.png" group-title="Belgium",BE: RTL Plug
http://ip96.uk:8080/shakeelmirza/4110440/317640
#EXTINF:-1 tvg-id="" tvg-name="BE: RTL TVI" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/a14f7fc17b6c62cc8a88d93c2e413a84.png" group-title="Belgium",BE: RTL TVI
http://ip96.uk:8080/shakeelmirza/4110440/317641
#EXTINF:-1 tvg-id="" tvg-name="BE: Tipik" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/a28c3b774935f34a19fcfb42682c82de.png" group-title="Belgium",BE: Tipik
http://ip96.uk:8080/shakeelmirza/4110440/317642
#EXTINF:-1 tvg-id="" tvg-name="BE: TVO" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/f3b5dd31852b118b3b74f1b4ac33931a.jpg" group-title="Belgium",BE: TVO
http://ip96.uk:8080/shakeelmirza/4110440/317643
#EXTINF:-1 tvg-id="" tvg-name="BE: Voo Sport World 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/aa308d85100a70048a10b2087065da48.png" group-title="Belgium",BE: Voo Sport World 1
http://ip96.uk:8080/shakeelmirza/4110440/317644
#EXTINF:-1 tvg-id="" tvg-name="BE: VTM" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-12/42472fa6aefc863b7afcc707325611f1.png" group-title="Belgium",BE: VTM
http://ip96.uk:8080/shakeelmirza/4110440/317645
#EXTINF:-1 tvg-id="" tvg-name="BE: VTM 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/97fa58af0fbe3b5f6995e125ebd36901.png" group-title="Belgium",BE: VTM 2
http://ip96.uk:8080/shakeelmirza/4110440/317646
#EXTINF:-1 tvg-id="" tvg-name="BE: VTM 3" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/c646293d99a238000698eaf4a065c80a.png" group-title="Belgium",BE: VTM 3
http://ip96.uk:8080/shakeelmirza/4110440/317647
#EXTINF:-1 tvg-id="" tvg-name="BE: VTM 4" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/4e8abea4175a3b73d00f98947a6620fe.png" group-title="Belgium",BE: VTM 4
http://ip96.uk:8080/shakeelmirza/4110440/317648
#EXTINF:-1 tvg-id="" tvg-name="BE: VTM Gold" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-12/aa6147bc8efd24c6ef571fe84940b75a.jpg" group-title="Belgium",BE: VTM Gold
http://ip96.uk:8080/shakeelmirza/4110440/317649
#EXTINF:-1 tvg-id="" tvg-name="FI: Boomerang" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-04/f6b4ac88659ef016aa45048ea7ef0f81.svg" group-title="FINLAND",FI: Boomerang
http://ip96.uk:8080/shakeelmirza/4110440/317806
#EXTINF:-1 tvg-id="" tvg-name="FI: Cartoon Network" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/d94c4322aad7fe1daadc48ebc7e3a67a.png" group-title="FINLAND",FI: Cartoon Network
http://ip96.uk:8080/shakeelmirza/4110440/317807
#EXTINF:-1 tvg-id="" tvg-name="FI: Discovery Science" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/e14d3af9403c8350de351b4854410f5e.png" group-title="FINLAND",FI: Discovery Science
http://ip96.uk:8080/shakeelmirza/4110440/317808
#EXTINF:-1 tvg-id="" tvg-name="FI: Discovery World" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/67db489f33a610ef80bf60aa8763d7fb.png" group-title="FINLAND",FI: Discovery World
http://ip96.uk:8080/shakeelmirza/4110440/317809
#EXTINF:-1 tvg-id="" tvg-name="FI: Disney Channel" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/9be134ca232b1b56e05ecc9f576b7eb0.png" group-title="FINLAND",FI: Disney Channel
http://ip96.uk:8080/shakeelmirza/4110440/317810
#EXTINF:-1 tvg-id="" tvg-name="FI: Disney Junior" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/15a81b6b0f2c86d28d21360f2f9c953e.png" group-title="FINLAND",FI: Disney Junior
http://ip96.uk:8080/shakeelmirza/4110440/317811
#EXTINF:-1 tvg-id="" tvg-name="FI: Himlen TV 7" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2024-03/eaa6f578a5d8e06e6b115a038b51b25e.jpg" group-title="FINLAND",FI: Himlen TV 7
http://ip96.uk:8080/shakeelmirza/4110440/317812
#EXTINF:-1 tvg-id="" tvg-name="FI: History" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/e11461f0a4fe53385dd6e76fab4b0a51.png" group-title="FINLAND",FI: History
http://ip96.uk:8080/shakeelmirza/4110440/317813
#EXTINF:-1 tvg-id="" tvg-name="FI: Investigation Discovery" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/9e67015b937c354e44d5ab846190bff1.jpg" group-title="FINLAND",FI: Investigation Discovery
http://ip96.uk:8080/shakeelmirza/4110440/317814
#EXTINF:-1 tvg-id="" tvg-name="FI: Jim" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/f481c43503a354390b03a9e6c86e6d44.png" group-title="FINLAND",FI: Jim
http://ip96.uk:8080/shakeelmirza/4110440/317815
#EXTINF:-1 tvg-id="" tvg-name="FI: Liv" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/0cc37f1275c2a90f933e714e96dc7af7.png" group-title="FINLAND",FI: Liv
http://ip96.uk:8080/shakeelmirza/4110440/317816
#EXTINF:-1 tvg-id="" tvg-name="FI: Motorvision TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-04/3be1fb82205c8a8859cb78a2a298b7a0.png" group-title="FINLAND",FI: Motorvision TV
http://ip96.uk:8080/shakeelmirza/4110440/317817
#EXTINF:-1 tvg-id="" tvg-name="FI: MTV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-04/943f8755b65534ff44654822e00ad4fd.png" group-title="FINLAND",FI: MTV
http://ip96.uk:8080/shakeelmirza/4110440/317818
#EXTINF:-1 tvg-id="" tvg-name="FI: MTV 3" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-06/fbc08a9b6269bd813fcb45cd862e346e.png" group-title="FINLAND",FI: MTV 3
http://ip96.uk:8080/shakeelmirza/4110440/317819
#EXTINF:-1 tvg-id="" tvg-name="FI: MTV Juniori/C more Juniori" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-12/3a6b5945e8ac66077566d8a3b561ea46.jpg" group-title="FINLAND",FI: MTV Juniori/C more Juniori
http://ip96.uk:8080/shakeelmirza/4110440/317820
#EXTINF:-1 tvg-id="" tvg-name="FI: MTV Max/C More Max" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-12/24024b8ebc0d75ed65756e720d912495.jpg" group-title="FINLAND",FI: MTV Max/C More Max
http://ip96.uk:8080/shakeelmirza/4110440/317821
#EXTINF:-1 tvg-id="" tvg-name="FI: MTV Urheilu 2/C More Sport 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-12/f012b7737ee82a880e09fa9c9d0b9570.jpg" group-title="FINLAND",FI: MTV Urheilu 2/C More Sport 2
http://ip96.uk:8080/shakeelmirza/4110440/317822
#EXTINF:-1 tvg-id="" tvg-name="FI: Nar-TV" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="FINLAND",FI: Nar-TV
http://ip96.uk:8080/shakeelmirza/4110440/317823
#EXTINF:-1 tvg-id="" tvg-name="FI: NAT GEO Wild" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/67073f806bf3ae269795a968989693b5.png" group-title="FINLAND",FI: NAT GEO Wild
http://ip96.uk:8080/shakeelmirza/4110440/317824
#EXTINF:-1 tvg-id="" tvg-name="FI: Nelonen" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/efd533a87903b81c854e32ca34d6bdfb.png" group-title="FINLAND",FI: Nelonen
http://ip96.uk:8080/shakeelmirza/4110440/317825
#EXTINF:-1 tvg-id="" tvg-name="FI: Nick Junior" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/0eb4b2dbe86b87e3af62c400d1d6f868.png" group-title="FINLAND",FI: Nick Junior
http://ip96.uk:8080/shakeelmirza/4110440/317826
#EXTINF:-1 tvg-id="" tvg-name="FI: NickToons" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-04/7a15b9cb08dd40114ceb5aa829ecf42f.png" group-title="FINLAND",FI: NickToons
http://ip96.uk:8080/shakeelmirza/4110440/317827
#EXTINF:-1 tvg-id="" tvg-name="FI: Rakuten TV Family Movies" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-12/1ddf7e82ab1825227ebea33dd0484fad.png" group-title="FINLAND",FI: Rakuten TV Family Movies
http://ip96.uk:8080/shakeelmirza/4110440/317828
#EXTINF:-1 tvg-id="" tvg-name="FI: Sub" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/02d565ceb5d30c2084f43cee02a79f12.png" group-title="FINLAND",FI: Sub
http://ip96.uk:8080/shakeelmirza/4110440/317829
#EXTINF:-1 tvg-id="" tvg-name="FI: Taevas TV 7" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-07/5321cf9a36caa4d6c704df1efb3cbe38.png" group-title="FINLAND",FI: Taevas TV 7
http://ip96.uk:8080/shakeelmirza/4110440/317830
#EXTINF:-1 tvg-id="" tvg-name="FI: TLC" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-12/fe30969ee57f997ec739da6416f54c64.png" group-title="FINLAND",FI: TLC
http://ip96.uk:8080/shakeelmirza/4110440/317831
#EXTINF:-1 tvg-id="" tvg-name="FI: TV4 Sport Live 1/C More Sport 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-12/1b2d0039ac208666b396a6253d52206a.png" group-title="FINLAND",FI: TV4 Sport Live 1/C More Sport 1
http://ip96.uk:8080/shakeelmirza/4110440/317832
#EXTINF:-1 tvg-id="" tvg-name="FI: TV7" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/70f68cfba7d38f4cb2693b26fbdb22e4.png" group-title="FINLAND",FI: TV7
http://ip96.uk:8080/shakeelmirza/4110440/317833
#EXTINF:-1 tvg-id="" tvg-name="FI: V Sport + Suomi" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-03/ff4aec5d5ae810c49fbf1240bf0e9672.png" group-title="FINLAND",FI: V Sport + Suomi
http://ip96.uk:8080/shakeelmirza/4110440/317834
#EXTINF:-1 tvg-id="" tvg-name="FI: V Sport 1 Suomi" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-03/2b3341bf99af701f0623d3190d71ec50.png" group-title="FINLAND",FI: V Sport 1 Suomi
http://ip96.uk:8080/shakeelmirza/4110440/317835
#EXTINF:-1 tvg-id="" tvg-name="FI: V Sport 2 Suomi" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-03/72bfefbc5b5b06cb191b2d76c56308e9.png" group-title="FINLAND",FI: V Sport 2 Suomi
http://ip96.uk:8080/shakeelmirza/4110440/317836
#EXTINF:-1 tvg-id="" tvg-name="FI: VIASAT SPORT ULTRA 4K" tvg-logo="" group-title="FINLAND",FI: VIASAT SPORT ULTRA 4K
http://ip96.uk:8080/shakeelmirza/4110440/317837
#EXTINF:-1 tvg-id="" tvg-name="FI: YLE TV 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/4cedf23f5ed7e99e0eeeb0b34df70da7.png" group-title="FINLAND",FI: YLE TV 1
http://ip96.uk:8080/shakeelmirza/4110440/317838
#EXTINF:-1 tvg-id="" tvg-name="FI: YLE TV 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/7de15463e311f1fa2853c076998a9c3b.png" group-title="FINLAND",FI: YLE TV 2
http://ip96.uk:8080/shakeelmirza/4110440/317839
#EXTINF:-1 tvg-id="" tvg-name="FI: MTV Urheilu 1/C More Sport 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-12/c4d011015e302c36c95b22e6e8bb6a10.jpg" group-title="FINLAND ➾ SPORTS",FI: MTV Urheilu 1/C More Sport 1
http://ip96.uk:8080/shakeelmirza/4110440/317840
#EXTINF:-1 tvg-id="" tvg-name="AL: 8ova Drame" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: 8ova Drame
http://ip96.uk:8080/shakeelmirza/4110440/303711
#EXTINF:-1 tvg-id="" tvg-name="AL: 8ova Gjurme Shqiptare" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: 8ova Gjurme Shqiptare
http://ip96.uk:8080/shakeelmirza/4110440/303712
#EXTINF:-1 tvg-id="" tvg-name="AL: 8ova Humor" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: 8ova Humor
http://ip96.uk:8080/shakeelmirza/4110440/303713
#EXTINF:-1 tvg-id="" tvg-name="AL: 8ova Komedi" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: 8ova Komedi
http://ip96.uk:8080/shakeelmirza/4110440/303714
#EXTINF:-1 tvg-id="" tvg-name="AL: 8ova Thriller" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: 8ova Thriller
http://ip96.uk:8080/shakeelmirza/4110440/303715
#EXTINF:-1 tvg-id="" tvg-name="AL: ABC Story" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: ABC Story
http://ip96.uk:8080/shakeelmirza/4110440/303716
#EXTINF:-1 tvg-id="" tvg-name="AL: Adria Net" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-09/48d34ed46633530ba91608059fad5354.jpg" group-title="Albania",AL: Adria Net
http://ip96.uk:8080/shakeelmirza/4110440/303717
#EXTINF:-1 tvg-id="" tvg-name="AL: Albuk" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-06/5bff9d821ee487f9df8d1e70eb830194.png" group-title="Albania",AL: Albuk
http://ip96.uk:8080/shakeelmirza/4110440/303718
#EXTINF:-1 tvg-id="" tvg-name="AL: Amol TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/94dda95426bbaef8ac2cc9244ec6dcda.png" group-title="Albania",AL: Amol TV
http://ip96.uk:8080/shakeelmirza/4110440/303719
#EXTINF:-1 tvg-id="" tvg-name="AL: Apollon TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/48539aa3304c2a7b0ff845e5aa645c7e.jpg" group-title="Albania",AL: Apollon TV
http://ip96.uk:8080/shakeelmirza/4110440/303720
#EXTINF:-1 tvg-id="" tvg-name="AL: Art Doku 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-06/0a29f149fdf9ea0b75c430524b097d38.png" group-title="Albania",AL: Art Doku 1
http://ip96.uk:8080/shakeelmirza/4110440/303721
#EXTINF:-1 tvg-id="" tvg-name="AL: Art Doku 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-06/b4c398265f61972391d66dc127cad1bb.png" group-title="Albania",AL: Art Doku 2
http://ip96.uk:8080/shakeelmirza/4110440/303722
#EXTINF:-1 tvg-id="" tvg-name="AL: Art Kino 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-06/7fe45f2f1833f7f70be27cb3dc073c39.png" group-title="Albania",AL: Art Kino 1
http://ip96.uk:8080/shakeelmirza/4110440/303723
#EXTINF:-1 tvg-id="" tvg-name="AL: Art Kino 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-06/8f5cb8018c2f482d7bc3aebecf5d5e87.png" group-title="Albania",AL: Art Kino 2
http://ip96.uk:8080/shakeelmirza/4110440/303724
#EXTINF:-1 tvg-id="" tvg-name="AL: Art Kino 3" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-06/48fe0b00bb6214ce00ed429c2004ffa0.png" group-title="Albania",AL: Art Kino 3
http://ip96.uk:8080/shakeelmirza/4110440/303725
#EXTINF:-1 tvg-id="" tvg-name="AL: Ashkali TV" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Ashkali TV
http://ip96.uk:8080/shakeelmirza/4110440/303726
#EXTINF:-1 tvg-id="" tvg-name="AL: Besa TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/0a91d2c1caa0fca1a548de9508c8a9ad.png" group-title="Albania",AL: Besa TV
http://ip96.uk:8080/shakeelmirza/4110440/303727
#EXTINF:-1 tvg-id="" tvg-name="AL: Blue Sky TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-06/3ae3d95f9a89d075685c14b5ae675808.png" group-title="Albania",AL: Blue Sky TV
http://ip96.uk:8080/shakeelmirza/4110440/303728
#EXTINF:-1 tvg-id="" tvg-name="AL: Cifteli TV" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: Cifteli TV
http://ip96.uk:8080/shakeelmirza/4110440/303729
#EXTINF:-1 tvg-id="" tvg-name="AL: Dark Cka ka Shpia" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Dark Cka ka Shpia
http://ip96.uk:8080/shakeelmirza/4110440/303730
#EXTINF:-1 tvg-id="" tvg-name="AL: Dark Fara e Flliqt" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Dark Fara e Flliqt
http://ip96.uk:8080/shakeelmirza/4110440/303731
#EXTINF:-1 tvg-id="" tvg-name="AL: Dark Gezuar" tvg-logo="" group-title="Albania",AL: Dark Gezuar
http://ip96.uk:8080/shakeelmirza/4110440/303732
#EXTINF:-1 tvg-id="" tvg-name="AL: Dark Hindi" tvg-logo="" group-title="Albania",AL: Dark Hindi
http://ip96.uk:8080/shakeelmirza/4110440/303733
#EXTINF:-1 tvg-id="" tvg-name="AL: Dark Kafeneja jone" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Dark Kafeneja jone
http://ip96.uk:8080/shakeelmirza/4110440/303734
#EXTINF:-1 tvg-id="" tvg-name="AL: Dark Popullore" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Dark Popullore
http://ip96.uk:8080/shakeelmirza/4110440/303735
#EXTINF:-1 tvg-id="" tvg-name="AL: Dark Stupcat Skeçe" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Dark Stupcat Skeçe
http://ip96.uk:8080/shakeelmirza/4110440/303736
#EXTINF:-1 tvg-id="" tvg-name="AL: Dark Tallava" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Dark Tallava
http://ip96.uk:8080/shakeelmirza/4110440/303737
#EXTINF:-1 tvg-id="" tvg-name="AL: Dasma" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Dasma
http://ip96.uk:8080/shakeelmirza/4110440/303738
#EXTINF:-1 tvg-id="" tvg-name="AL: Digi Gold 1" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Digi Gold 1
http://ip96.uk:8080/shakeelmirza/4110440/303739
#EXTINF:-1 tvg-id="" tvg-name="AL: Digi Gold 2" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Digi Gold 2
http://ip96.uk:8080/shakeelmirza/4110440/303740
#EXTINF:-1 tvg-id="" tvg-name="AL: Digi Gold 3" tvg-logo="" group-title="Albania",AL: Digi Gold 3
http://ip96.uk:8080/shakeelmirza/4110440/303741
#EXTINF:-1 tvg-id="" tvg-name="AL: Digi Gold 4" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Digi Gold 4
http://ip96.uk:8080/shakeelmirza/4110440/303742
#EXTINF:-1 tvg-id="" tvg-name="AL: Discovery Channel" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2024-01/1c8441caf45385a7f3acc1c0494f28dd.png" group-title="Albania",AL: Discovery Channel
http://ip96.uk:8080/shakeelmirza/4110440/303743
#EXTINF:-1 tvg-id="" tvg-name="AL: Drita TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/eef24b5325b4ef4f581c2bb68ec7c942.png" group-title="Albania",AL: Drita TV
http://ip96.uk:8080/shakeelmirza/4110440/303744
#EXTINF:-1 tvg-id="" tvg-name="AL: Duck TV" tvg-logo="" group-title="Albania",AL: Duck TV
http://ip96.uk:8080/shakeelmirza/4110440/303745
#EXTINF:-1 tvg-id="" tvg-name="AL: EB Festive" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: EB Festive
http://ip96.uk:8080/shakeelmirza/4110440/303746
#EXTINF:-1 tvg-id="" tvg-name="AL: EB Festive 1" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: EB Festive 1
http://ip96.uk:8080/shakeelmirza/4110440/303747
#EXTINF:-1 tvg-id="" tvg-name="AL: EB Festive 2" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: EB Festive 2
http://ip96.uk:8080/shakeelmirza/4110440/303748
#EXTINF:-1 tvg-id="" tvg-name="AL: EB Festive 3" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: EB Festive 3
http://ip96.uk:8080/shakeelmirza/4110440/303749
#EXTINF:-1 tvg-id="" tvg-name="AL: EB Festive 4" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: EB Festive 4
http://ip96.uk:8080/shakeelmirza/4110440/303750
#EXTINF:-1 tvg-id="" tvg-name="AL: EB Festive 5" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: EB Festive 5
http://ip96.uk:8080/shakeelmirza/4110440/303751
#EXTINF:-1 tvg-id="" tvg-name="AL: EB Festive 6" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: EB Festive 6
http://ip96.uk:8080/shakeelmirza/4110440/303752
#EXTINF:-1 tvg-id="" tvg-name="AL: EB Festive 7" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: EB Festive 7
http://ip96.uk:8080/shakeelmirza/4110440/303753
#EXTINF:-1 tvg-id="" tvg-name="AL: EB Festive 8" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: EB Festive 8
http://ip96.uk:8080/shakeelmirza/4110440/303754
#EXTINF:-1 tvg-id="" tvg-name="AL: EB Festive Sofra" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: EB Festive Sofra
http://ip96.uk:8080/shakeelmirza/4110440/303755
#EXTINF:-1 tvg-id="" tvg-name="AL: EB Hits" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: EB Hits
http://ip96.uk:8080/shakeelmirza/4110440/303756
#EXTINF:-1 tvg-id="" tvg-name="AL: Elkalem TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/9c67ae1d1da5485a41967e6429bf5f7d.jpg" group-title="Albania",AL: Elkalem TV
http://ip96.uk:8080/shakeelmirza/4110440/303757
#EXTINF:-1 tvg-id="" tvg-name="AL: Episode" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Episode
http://ip96.uk:8080/shakeelmirza/4110440/303758
#EXTINF:-1 tvg-id="" tvg-name="AL: Era TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-01/e4ca153def19020ce3be1bc6d5cf91c8.png" group-title="Albania",AL: Era TV
http://ip96.uk:8080/shakeelmirza/4110440/303759
#EXTINF:-1 tvg-id="" tvg-name="AL: Euro Al" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/5e5fbc5b4a9cbaf591b2dd67b81fb7f2.png" group-title="Albania",AL: Euro Al
http://ip96.uk:8080/shakeelmirza/4110440/303760
#EXTINF:-1 tvg-id="" tvg-name="AL: Fast&FunBox" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: Fast&FunBox
http://ip96.uk:8080/shakeelmirza/4110440/303761
#EXTINF:-1 tvg-id="" tvg-name="AL: Flutra" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Flutra
http://ip96.uk:8080/shakeelmirza/4110440/303762
#EXTINF:-1 tvg-id="" tvg-name="AL: Globi TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-06/dcf230fa8c6c1b0499b52ad97eabfc04.png" group-title="Albania",AL: Globi TV
http://ip96.uk:8080/shakeelmirza/4110440/303763
#EXTINF:-1 tvg-id="" tvg-name="AL: Hetuesia" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: Hetuesia
http://ip96.uk:8080/shakeelmirza/4110440/303764
#EXTINF:-1 tvg-id="" tvg-name="AL: Histori Shqiptare" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-06/26cc28df4182f9d45f2da7a98a813b77.png" group-title="Albania",AL: Histori Shqiptare
http://ip96.uk:8080/shakeelmirza/4110440/303765
#EXTINF:-1 tvg-id="" tvg-name="AL: History" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: History
http://ip96.uk:8080/shakeelmirza/4110440/303766
#EXTINF:-1 tvg-id="" tvg-name="AL: HS Hore" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: HS Hore
http://ip96.uk:8080/shakeelmirza/4110440/303767
#EXTINF:-1 tvg-id="" tvg-name="AL: HS Tallava" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: HS Tallava
http://ip96.uk:8080/shakeelmirza/4110440/303768
#EXTINF:-1 tvg-id="" tvg-name="AL: Istogu Channel" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-06/6a7c815152522f3a3208afe0b759235d.png" group-title="Albania",AL: Istogu Channel
http://ip96.uk:8080/shakeelmirza/4110440/303769
#EXTINF:-1 tvg-id="" tvg-name="AL: Korca Plus" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/a2777d3b5d9060d988bbe7c4075927fd.png" group-title="Albania",AL: Korca Plus
http://ip96.uk:8080/shakeelmirza/4110440/303770
#EXTINF:-1 tvg-id="" tvg-name="AL: KS Action" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: KS Action
http://ip96.uk:8080/shakeelmirza/4110440/303771
#EXTINF:-1 tvg-id="" tvg-name="AL: KS Ciftelia" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: KS Ciftelia
http://ip96.uk:8080/shakeelmirza/4110440/303772
#EXTINF:-1 tvg-id="" tvg-name="AL: KS Comedy" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: KS Comedy
http://ip96.uk:8080/shakeelmirza/4110440/303773
#EXTINF:-1 tvg-id="" tvg-name="AL: KS Epic" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: KS Epic
http://ip96.uk:8080/shakeelmirza/4110440/303774
#EXTINF:-1 tvg-id="" tvg-name="AL: KS Festive" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: KS Festive
http://ip96.uk:8080/shakeelmirza/4110440/303775
#EXTINF:-1 tvg-id="" tvg-name="AL: KS Filma24 Hindi" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: KS Filma24 Hindi
http://ip96.uk:8080/shakeelmirza/4110440/303776
#EXTINF:-1 tvg-id="" tvg-name="AL: KS Filma24 Western" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: KS Filma24 Western
http://ip96.uk:8080/shakeelmirza/4110440/303777
#EXTINF:-1 tvg-id="" tvg-name="AL: KS Home Alone" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: KS Home Alone
http://ip96.uk:8080/shakeelmirza/4110440/303778
#EXTINF:-1 tvg-id="" tvg-name="AL: KS Popullore" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: KS Popullore
http://ip96.uk:8080/shakeelmirza/4110440/303779
#EXTINF:-1 tvg-id="" tvg-name="AL: Ks Premiere 1" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Ks Premiere 1
http://ip96.uk:8080/shakeelmirza/4110440/303780
#EXTINF:-1 tvg-id="" tvg-name="AL: Ks Premiere 2" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Ks Premiere 2
http://ip96.uk:8080/shakeelmirza/4110440/303781
#EXTINF:-1 tvg-id="" tvg-name="AL: Ks Premiere 3" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Ks Premiere 3
http://ip96.uk:8080/shakeelmirza/4110440/303782
#EXTINF:-1 tvg-id="" tvg-name="AL: Ks Premiere 4" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Ks Premiere 4
http://ip96.uk:8080/shakeelmirza/4110440/303783
#EXTINF:-1 tvg-id="" tvg-name="AL: KS Thriller" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: KS Thriller
http://ip96.uk:8080/shakeelmirza/4110440/303784
#EXTINF:-1 tvg-id="" tvg-name="AL: Liria" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/673c8472334fe025d402e6a7bd594170.jpg" group-title="Albania",AL: Liria
http://ip96.uk:8080/shakeelmirza/4110440/303785
#EXTINF:-1 tvg-id="" tvg-name="AL: MCN 24" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: MCN 24
http://ip96.uk:8080/shakeelmirza/4110440/303786
#EXTINF:-1 tvg-id="" tvg-name="AL: Melody TV" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Melody TV
http://ip96.uk:8080/shakeelmirza/4110440/303787
#EXTINF:-1 tvg-id="" tvg-name="AL: MetiTV Aksion" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: MetiTV Aksion
http://ip96.uk:8080/shakeelmirza/4110440/303788
#EXTINF:-1 tvg-id="" tvg-name="AL: MetiTV Cifteli" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: MetiTV Cifteli
http://ip96.uk:8080/shakeelmirza/4110440/303789
#EXTINF:-1 tvg-id="" tvg-name="AL: MetiTV Comedy" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: MetiTV Comedy
http://ip96.uk:8080/shakeelmirza/4110440/303790
#EXTINF:-1 tvg-id="" tvg-name="AL: MetiTV Epic" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: MetiTV Epic
http://ip96.uk:8080/shakeelmirza/4110440/303791
#EXTINF:-1 tvg-id="" tvg-name="AL: MetiTV Femije" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: MetiTV Femije
http://ip96.uk:8080/shakeelmirza/4110440/303792
#EXTINF:-1 tvg-id="" tvg-name="AL: MetiTV Film" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: MetiTV Film
http://ip96.uk:8080/shakeelmirza/4110440/303793
#EXTINF:-1 tvg-id="" tvg-name="AL: MetiTV Folk" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: MetiTV Folk
http://ip96.uk:8080/shakeelmirza/4110440/303794
#EXTINF:-1 tvg-id="" tvg-name="AL: MetiTV Gold" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: MetiTV Gold
http://ip96.uk:8080/shakeelmirza/4110440/303795
#EXTINF:-1 tvg-id="" tvg-name="AL: MetiTV Horror" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: MetiTV Horror
http://ip96.uk:8080/shakeelmirza/4110440/303796
#EXTINF:-1 tvg-id="" tvg-name="AL: MetiTV Humor" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: MetiTV Humor
http://ip96.uk:8080/shakeelmirza/4110440/303797
#EXTINF:-1 tvg-id="" tvg-name="AL: MetiTV kids" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: MetiTV kids
http://ip96.uk:8080/shakeelmirza/4110440/303798
#EXTINF:-1 tvg-id="" tvg-name="AL: MetiTV lufte" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: MetiTV lufte
http://ip96.uk:8080/shakeelmirza/4110440/303799
#EXTINF:-1 tvg-id="" tvg-name="AL: MetiTV Max" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: MetiTV Max
http://ip96.uk:8080/shakeelmirza/4110440/303800
#EXTINF:-1 tvg-id="" tvg-name="AL: MetiTV Mixha" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: MetiTV Mixha
http://ip96.uk:8080/shakeelmirza/4110440/303801
#EXTINF:-1 tvg-id="" tvg-name="AL: MetiTV Music" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: MetiTV Music
http://ip96.uk:8080/shakeelmirza/4110440/303802
#EXTINF:-1 tvg-id="" tvg-name="AL: MetiTV Shqip" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: MetiTV Shqip
http://ip96.uk:8080/shakeelmirza/4110440/303803
#EXTINF:-1 tvg-id="" tvg-name="AL: MetiTV Tallava" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: MetiTV Tallava
http://ip96.uk:8080/shakeelmirza/4110440/303804
#EXTINF:-1 tvg-id="" tvg-name="AL: MetiTV çka ka shpija 24/7" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: MetiTV çka ka shpija 24/7
http://ip96.uk:8080/shakeelmirza/4110440/303805
#EXTINF:-1 tvg-id="" tvg-name="AL: MFM Music" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/a0d688a0c1b50a2ea7c5b8cca2c39b9f.jpg" group-title="Albania",AL: MFM Music
http://ip96.uk:8080/shakeelmirza/4110440/303806
#EXTINF:-1 tvg-id="" tvg-name="AL: Nat Geo Wild" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: Nat Geo Wild
http://ip96.uk:8080/shakeelmirza/4110440/303807
#EXTINF:-1 tvg-id="" tvg-name="AL: Netflix Aksion" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: Netflix Aksion
http://ip96.uk:8080/shakeelmirza/4110440/303808
#EXTINF:-1 tvg-id="" tvg-name="AL: Netflix Arnold Schwarzenegger" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: Netflix Arnold Schwarzenegger
http://ip96.uk:8080/shakeelmirza/4110440/303809
#EXTINF:-1 tvg-id="" tvg-name="AL: Netflix Aventure" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: Netflix Aventure
http://ip96.uk:8080/shakeelmirza/4110440/303810
#EXTINF:-1 tvg-id="" tvg-name="AL: Netflix Bud Spencer" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: Netflix Bud Spencer
http://ip96.uk:8080/shakeelmirza/4110440/303811
#EXTINF:-1 tvg-id="" tvg-name="AL: Netflix Dwayne Johnson" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: Netflix Dwayne Johnson
http://ip96.uk:8080/shakeelmirza/4110440/303812
#EXTINF:-1 tvg-id="" tvg-name="AL: Netflix Epik" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: Netflix Epik
http://ip96.uk:8080/shakeelmirza/4110440/303813
#EXTINF:-1 tvg-id="" tvg-name="AL: Netflix Fantasy" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: Netflix Fantasy
http://ip96.uk:8080/shakeelmirza/4110440/303814
#EXTINF:-1 tvg-id="" tvg-name="AL: Netflix Femije" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: Netflix Femije
http://ip96.uk:8080/shakeelmirza/4110440/303815
#EXTINF:-1 tvg-id="" tvg-name="AL: Netflix Horror" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: Netflix Horror
http://ip96.uk:8080/shakeelmirza/4110440/303816
#EXTINF:-1 tvg-id="" tvg-name="AL: Netflix Jackie Chan" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: Netflix Jackie Chan
http://ip96.uk:8080/shakeelmirza/4110440/303817
#EXTINF:-1 tvg-id="" tvg-name="AL: Netflix Komedi" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: Netflix Komedi
http://ip96.uk:8080/shakeelmirza/4110440/303818
#EXTINF:-1 tvg-id="" tvg-name="AL: Netflix Larva Kids" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: Netflix Larva Kids
http://ip96.uk:8080/shakeelmirza/4110440/303819
#EXTINF:-1 tvg-id="" tvg-name="AL: Netflix Relaks" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: Netflix Relaks
http://ip96.uk:8080/shakeelmirza/4110440/303820
#EXTINF:-1 tvg-id="" tvg-name="AL: Netflix Romance" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: Netflix Romance
http://ip96.uk:8080/shakeelmirza/4110440/303821
#EXTINF:-1 tvg-id="" tvg-name="AL: Netflix Spider-Man" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: Netflix Spider-Man
http://ip96.uk:8080/shakeelmirza/4110440/303822
#EXTINF:-1 tvg-id="" tvg-name="AL: Netflix Sylvester stallone" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: Netflix Sylvester stallone
http://ip96.uk:8080/shakeelmirza/4110440/303823
#EXTINF:-1 tvg-id="" tvg-name="AL: Netflix Van Damme" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: Netflix Van Damme
http://ip96.uk:8080/shakeelmirza/4110440/303824
#EXTINF:-1 tvg-id="" tvg-name="AL: ntv" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-11/3ad58049b1f40d7de7c5374fbd558258.jpg" group-title="Albania",AL: ntv
http://ip96.uk:8080/shakeelmirza/4110440/303825
#EXTINF:-1 tvg-id="" tvg-name="AL: OnePlay Aksion" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: OnePlay Aksion
http://ip96.uk:8080/shakeelmirza/4110440/303826
#EXTINF:-1 tvg-id="" tvg-name="AL: OnePlay Classic" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: OnePlay Classic
http://ip96.uk:8080/shakeelmirza/4110440/303827
#EXTINF:-1 tvg-id="" tvg-name="AL: OnePlay Collection" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: OnePlay Collection
http://ip96.uk:8080/shakeelmirza/4110440/303828
#EXTINF:-1 tvg-id="" tvg-name="AL: OnePlay Extra" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: OnePlay Extra
http://ip96.uk:8080/shakeelmirza/4110440/303829
#EXTINF:-1 tvg-id="" tvg-name="AL: OnePlay Family" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: OnePlay Family
http://ip96.uk:8080/shakeelmirza/4110440/303830
#EXTINF:-1 tvg-id="" tvg-name="AL: OnePlay Netflix" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: OnePlay Netflix
http://ip96.uk:8080/shakeelmirza/4110440/303831
#EXTINF:-1 tvg-id="" tvg-name="AL: OnePlay Premium" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: OnePlay Premium
http://ip96.uk:8080/shakeelmirza/4110440/303832
#EXTINF:-1 tvg-id="" tvg-name="AL: OnePlay prime 1" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: OnePlay prime 1
http://ip96.uk:8080/shakeelmirza/4110440/303833
#EXTINF:-1 tvg-id="" tvg-name="AL: OnePlay prime 2" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: OnePlay prime 2
http://ip96.uk:8080/shakeelmirza/4110440/303834
#EXTINF:-1 tvg-id="" tvg-name="AL: OnePlay prime 3" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: OnePlay prime 3
http://ip96.uk:8080/shakeelmirza/4110440/303835
#EXTINF:-1 tvg-id="" tvg-name="AL: OnePlay prime 4" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: OnePlay prime 4
http://ip96.uk:8080/shakeelmirza/4110440/303836
#EXTINF:-1 tvg-id="" tvg-name="AL: Panorama TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2024-01/493e89dbf04666ce3522689074fd83f9.png" group-title="Albania",AL: Panorama TV
http://ip96.uk:8080/shakeelmirza/4110440/303837
#EXTINF:-1 tvg-id="" tvg-name="AL: Pollogu" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/c8314f63833192e4a9bf9c51c8081f5b.jpg" group-title="Albania",AL: Pollogu
http://ip96.uk:8080/shakeelmirza/4110440/303838
#EXTINF:-1 tvg-id="" tvg-name="AL: Rozafa" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/66f956374d354d9bd40704f13010f5c9.jpg" group-title="Albania",AL: Rozafa
http://ip96.uk:8080/shakeelmirza/4110440/303839
#EXTINF:-1 tvg-id="" tvg-name="AL: RTV Fontana" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/a67d5e2f46845ce13255e8d6dc631677.jpg" group-title="Albania",AL: RTV Fontana
http://ip96.uk:8080/shakeelmirza/4110440/303840
#EXTINF:-1 tvg-id="" tvg-name="AL: RTV Ilirida" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-06/7d3c6b889ece36d060a2e4cb6fa7194c.jpg" group-title="Albania",AL: RTV Ilirida
http://ip96.uk:8080/shakeelmirza/4110440/303841
#EXTINF:-1 tvg-id="" tvg-name="AL: RTV Islam" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-06/21baa2e87813273da6e0bb0f6df6b094.png" group-title="Albania",AL: RTV Islam
http://ip96.uk:8080/shakeelmirza/4110440/303842
#EXTINF:-1 tvg-id="" tvg-name="AL: RTV Pendimi" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/14255559c4385fc106e11b98863b41b5.png" group-title="Albania",AL: RTV Pendimi
http://ip96.uk:8080/shakeelmirza/4110440/303843
#EXTINF:-1 tvg-id="" tvg-name="AL: Shenja TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-06/4f26930437a04b6f5635cbd51cdcd597.jpg" group-title="Albania",AL: Shenja TV
http://ip96.uk:8080/shakeelmirza/4110440/303844
#EXTINF:-1 tvg-id="" tvg-name="AL: Shota TV" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: Shota TV
http://ip96.uk:8080/shakeelmirza/4110440/303845
#EXTINF:-1 tvg-id="" tvg-name="AL: Sky Aksion" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Sky Aksion
http://ip96.uk:8080/shakeelmirza/4110440/303846
#EXTINF:-1 tvg-id="" tvg-name="AL: Sky Comedy" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Sky Comedy
http://ip96.uk:8080/shakeelmirza/4110440/303847
#EXTINF:-1 tvg-id="" tvg-name="AL: Sky Drama" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Sky Drama
http://ip96.uk:8080/shakeelmirza/4110440/303848
#EXTINF:-1 tvg-id="" tvg-name="AL: Sky Max" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Sky Max
http://ip96.uk:8080/shakeelmirza/4110440/303849
#EXTINF:-1 tvg-id="" tvg-name="AL: Sky Novela" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Sky Novela
http://ip96.uk:8080/shakeelmirza/4110440/303850
#EXTINF:-1 tvg-id="" tvg-name="AL: Sky Shqip" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: Sky Shqip
http://ip96.uk:8080/shakeelmirza/4110440/303851
#EXTINF:-1 tvg-id="" tvg-name="AL: Sky Star" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Sky Star
http://ip96.uk:8080/shakeelmirza/4110440/303852
#EXTINF:-1 tvg-id="" tvg-name="AL: Sofia" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-06/f4321c4b3f2b6b952484e0dafe2c2f79.png" group-title="Albania",AL: Sofia
http://ip96.uk:8080/shakeelmirza/4110440/303853
#EXTINF:-1 tvg-id="" tvg-name="AL: Syri TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-06/6f20fe69d514a9d0174c2b47bfeab307.jpg" group-title="Albania",AL: Syri TV
http://ip96.uk:8080/shakeelmirza/4110440/303854
#EXTINF:-1 tvg-id="" tvg-name="AL: Syri Vizion" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-06/ab27229691e40672d4bed48c79b7209a.png" group-title="Albania",AL: Syri Vizion
http://ip96.uk:8080/shakeelmirza/4110440/303855
#EXTINF:-1 tvg-id="" tvg-name="AL: T Channel" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/467332097ca9cb8ee909414e4c46ad8c.png" group-title="Albania",AL: T Channel
http://ip96.uk:8080/shakeelmirza/4110440/303856
#EXTINF:-1 tvg-id="" tvg-name="AL: TDC" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: TDC
http://ip96.uk:8080/shakeelmirza/4110440/303857
#EXTINF:-1 tvg-id="" tvg-name="AL: Tele One 1" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Tele One 1
http://ip96.uk:8080/shakeelmirza/4110440/303858
#EXTINF:-1 tvg-id="" tvg-name="AL: Tele One 2" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Tele One 2
http://ip96.uk:8080/shakeelmirza/4110440/303859
#EXTINF:-1 tvg-id="" tvg-name="AL: Tele One 3" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Tele One 3
http://ip96.uk:8080/shakeelmirza/4110440/303860
#EXTINF:-1 tvg-id="" tvg-name="AL: Tele One 4" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Tele One 4
http://ip96.uk:8080/shakeelmirza/4110440/303861
#EXTINF:-1 tvg-id="" tvg-name="AL: Tele One 5" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Tele One 5
http://ip96.uk:8080/shakeelmirza/4110440/303862
#EXTINF:-1 tvg-id="" tvg-name="AL: Tele One 6" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Tele One 6
http://ip96.uk:8080/shakeelmirza/4110440/303863
#EXTINF:-1 tvg-id="" tvg-name="AL: Tele One Aksion" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Tele One Aksion
http://ip96.uk:8080/shakeelmirza/4110440/303864
#EXTINF:-1 tvg-id="" tvg-name="AL: Tele One Crime" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Tele One Crime
http://ip96.uk:8080/shakeelmirza/4110440/303865
#EXTINF:-1 tvg-id="" tvg-name="AL: Tele One Drama" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Tele One Drama
http://ip96.uk:8080/shakeelmirza/4110440/303866
#EXTINF:-1 tvg-id="" tvg-name="AL: Tele One Epik" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Tele One Epik
http://ip96.uk:8080/shakeelmirza/4110440/303867
#EXTINF:-1 tvg-id="" tvg-name="AL: Tele One Fantazi" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Tele One Fantazi
http://ip96.uk:8080/shakeelmirza/4110440/303868
#EXTINF:-1 tvg-id="" tvg-name="AL: Tele One Gold Collection" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Tele One Gold Collection
http://ip96.uk:8080/shakeelmirza/4110440/303869
#EXTINF:-1 tvg-id="" tvg-name="AL: Televizija 5" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Televizija 5
http://ip96.uk:8080/shakeelmirza/4110440/303870
#EXTINF:-1 tvg-id="" tvg-name="AL: Tema TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-06/daf495b8c3cdc589507ea2c265276313.jpg" group-title="Albania",AL: Tema TV
http://ip96.uk:8080/shakeelmirza/4110440/303871
#EXTINF:-1 tvg-id="" tvg-name="AL: Terra" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: Terra
http://ip96.uk:8080/shakeelmirza/4110440/303872
#EXTINF:-1 tvg-id="" tvg-name="AL: Teuta" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-06/266e2b70af63c6ff133f48d7a30f05df.png" group-title="Albania",AL: Teuta
http://ip96.uk:8080/shakeelmirza/4110440/303873
#EXTINF:-1 tvg-id="" tvg-name="AL: Teve Aksion" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Teve Aksion
http://ip96.uk:8080/shakeelmirza/4110440/303874
#EXTINF:-1 tvg-id="" tvg-name="AL: Teve Comedy" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Teve Comedy
http://ip96.uk:8080/shakeelmirza/4110440/303875
#EXTINF:-1 tvg-id="" tvg-name="AL: Teve Drame" tvg-logo="" group-title="Albania",AL: Teve Drame
http://ip96.uk:8080/shakeelmirza/4110440/303876
#EXTINF:-1 tvg-id="" tvg-name="AL: Teve Fantasy" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Teve Fantasy
http://ip96.uk:8080/shakeelmirza/4110440/303877
#EXTINF:-1 tvg-id="" tvg-name="AL: Teve Shqip" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Teve Shqip
http://ip96.uk:8080/shakeelmirza/4110440/303878
#EXTINF:-1 tvg-id="" tvg-name="AL: Tirana" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania",AL: Tirana
http://ip96.uk:8080/shakeelmirza/4110440/303879
#EXTINF:-1 tvg-id="" tvg-name="AL: Tom & Jerry" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: Tom & Jerry
http://ip96.uk:8080/shakeelmirza/4110440/303880
#EXTINF:-1 tvg-id="" tvg-name="AL: TOP Estrada" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-06/fec89bed74110b33f5749de83b0d9088.png" group-title="Albania",AL: TOP Estrada
http://ip96.uk:8080/shakeelmirza/4110440/303881
#EXTINF:-1 tvg-id="" tvg-name="AL: Tropoja" tvg-logo="" group-title="Albania",AL: Tropoja
http://ip96.uk:8080/shakeelmirza/4110440/303882
#EXTINF:-1 tvg-id="" tvg-name="AL: Turbo Channel" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-06/0bdf077edf9f205d7800794a87c99b35.png" group-title="Albania",AL: Turbo Channel
http://ip96.uk:8080/shakeelmirza/4110440/303883
#EXTINF:-1 tvg-id="" tvg-name="AL: TV 7 Albania" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-06/51eb803884779e9133a759ca77d143b0.png" group-title="Albania",AL: TV 7 Albania
http://ip96.uk:8080/shakeelmirza/4110440/303884
#EXTINF:-1 tvg-id="" tvg-name="AL: TV Diaspora" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: TV Diaspora
http://ip96.uk:8080/shakeelmirza/4110440/303885
#EXTINF:-1 tvg-id="" tvg-name="AL: TV Dielli" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-06/fe3b554c186d7250608586118d158ffc.png" group-title="Albania",AL: TV Dielli
http://ip96.uk:8080/shakeelmirza/4110440/303886
#EXTINF:-1 tvg-id="" tvg-name="AL: TV Festina" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-06/288907e30468430bbb12800e16cd6c71.png" group-title="Albania",AL: TV Festina
http://ip96.uk:8080/shakeelmirza/4110440/303887
#EXTINF:-1 tvg-id="" tvg-name="AL: TV Kopliku" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/27a583c58d8f59b668672b6e56878ee8.jpg" group-title="Albania",AL: TV Kopliku
http://ip96.uk:8080/shakeelmirza/4110440/303888
#EXTINF:-1 tvg-id="" tvg-name="AL: TV Lobi Korç" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: TV Lobi Korç
http://ip96.uk:8080/shakeelmirza/4110440/303889
#EXTINF:-1 tvg-id="" tvg-name="AL: TV Mitrovica" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/ac3961e6a01fb2835eaf8d2e37294eb9.jpg" group-title="Albania",AL: TV Mitrovica
http://ip96.uk:8080/shakeelmirza/4110440/303890
#EXTINF:-1 tvg-id="" tvg-name="AL: TV Opoja" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/6b8e20e7506a44c0e98dafdcfec30c35.jpg" group-title="Albania",AL: TV Opoja
http://ip96.uk:8080/shakeelmirza/4110440/303891
#EXTINF:-1 tvg-id="" tvg-name="AL: TV Uskana" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/4e3321ac3a41d9c75471c2c4f590bd35.jpg" group-title="Albania",AL: TV Uskana
http://ip96.uk:8080/shakeelmirza/4110440/303892
#EXTINF:-1 tvg-id="" tvg-name="AL: TV2 Gostivar" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-08/6576c7426082974b845a6efaaad378e5.jpg" group-title="Albania",AL: TV2 Gostivar
http://ip96.uk:8080/shakeelmirza/4110440/303893
#EXTINF:-1 tvg-id="" tvg-name="AL: Ulqini TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-06/ee01d1a99027efc24690efee61da8574.jpg" group-title="Albania",AL: Ulqini TV
http://ip96.uk:8080/shakeelmirza/4110440/303894
#EXTINF:-1 tvg-id="" tvg-name="AL: WebStar Aksion" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: WebStar Aksion
http://ip96.uk:8080/shakeelmirza/4110440/303895
#EXTINF:-1 tvg-id="" tvg-name="AL: WebStar Baby" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: WebStar Baby
http://ip96.uk:8080/shakeelmirza/4110440/303896
#EXTINF:-1 tvg-id="" tvg-name="AL: WebStar ChuChu" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: WebStar ChuChu
http://ip96.uk:8080/shakeelmirza/4110440/303897
#EXTINF:-1 tvg-id="" tvg-name="AL: WebStar Film 1" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: WebStar Film 1
http://ip96.uk:8080/shakeelmirza/4110440/303898
#EXTINF:-1 tvg-id="" tvg-name="AL: WebStar Film 2" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: WebStar Film 2
http://ip96.uk:8080/shakeelmirza/4110440/303899
#EXTINF:-1 tvg-id="" tvg-name="AL: WebStar Film 3" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: WebStar Film 3
http://ip96.uk:8080/shakeelmirza/4110440/303900
#EXTINF:-1 tvg-id="" tvg-name="AL: WebStar Film Cinema" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: WebStar Film Cinema
http://ip96.uk:8080/shakeelmirza/4110440/303901
#EXTINF:-1 tvg-id="" tvg-name="AL: WebStar Film Drame" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: WebStar Film Drame
http://ip96.uk:8080/shakeelmirza/4110440/303902
#EXTINF:-1 tvg-id="" tvg-name="AL: WebStar Film Komedi" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: WebStar Film Komedi
http://ip96.uk:8080/shakeelmirza/4110440/303903
#EXTINF:-1 tvg-id="" tvg-name="AL: WebStar Film Thriller" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: WebStar Film Thriller
http://ip96.uk:8080/shakeelmirza/4110440/303904
#EXTINF:-1 tvg-id="" tvg-name="AL: WebStar Hisrori" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: WebStar Hisrori
http://ip96.uk:8080/shakeelmirza/4110440/303905
#EXTINF:-1 tvg-id="" tvg-name="AL: WebStar Music CH" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: WebStar Music CH
http://ip96.uk:8080/shakeelmirza/4110440/303906
#EXTINF:-1 tvg-id="" tvg-name="AL: WebStar Muzic" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: WebStar Muzic
http://ip96.uk:8080/shakeelmirza/4110440/303907
#EXTINF:-1 tvg-id="" tvg-name="AL: WebStar Natyr" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: WebStar Natyr
http://ip96.uk:8080/shakeelmirza/4110440/303908
#EXTINF:-1 tvg-id="" tvg-name="AL: WebStar Popullore" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: WebStar Popullore
http://ip96.uk:8080/shakeelmirza/4110440/303909
#EXTINF:-1 tvg-id="" tvg-name="AL: WebStar Qifteli" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: WebStar Qifteli
http://ip96.uk:8080/shakeelmirza/4110440/303910
#EXTINF:-1 tvg-id="" tvg-name="AL: X Premiere 2" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania",AL: X Premiere 2
http://ip96.uk:8080/shakeelmirza/4110440/303911
#EXTINF:-1 tvg-id="" tvg-name="AL: 24 Kitchen" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-06/0bc804a09638d8aec9bfa209a7fa027a.png" group-title="Albania ➾ LifeStyle",AL: 24 Kitchen
http://ip96.uk:8080/shakeelmirza/4110440/303912
#EXTINF:-1 tvg-id="" tvg-name="AL: Alsat M" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-10/adee17a578829aa62d64e795ae7c20f5.png" group-title="Albania ➾ LifeStyle",AL: Alsat M
http://ip96.uk:8080/shakeelmirza/4110440/303913
#EXTINF:-1 tvg-id="" tvg-name="AL: ATV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-04/fc491afbd5e05e744fa0d4d257780b36.png" group-title="Albania ➾ LifeStyle",AL: ATV
http://ip96.uk:8080/shakeelmirza/4110440/303914
#EXTINF:-1 tvg-id="" tvg-name="AL: Big Brother 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2024-01/227305c0b48a4feb46d3eee53a30a808.jpg" group-title="Albania ➾ LifeStyle",AL: Big Brother 1
http://ip96.uk:8080/shakeelmirza/4110440/303915
#EXTINF:-1 tvg-id="" tvg-name="AL: Big Brother 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2024-01/54d1c9185f0f0baf213073e01f1cbfee.jpg" group-title="Albania ➾ LifeStyle",AL: Big Brother 2
http://ip96.uk:8080/shakeelmirza/4110440/303916
#EXTINF:-1 tvg-id="" tvg-name="AL: Elrodi TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-06/a0a4ddd17042ba3635b68af08c08c370.png" group-title="Albania ➾ LifeStyle",AL: Elrodi TV
http://ip96.uk:8080/shakeelmirza/4110440/303917
#EXTINF:-1 tvg-id="" tvg-name="AL: Explorer Shkence" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-02/7a79ebe3df2d6efb9fb670aedcc397d0.png" group-title="Albania ➾ LifeStyle",AL: Explorer Shkence
http://ip96.uk:8080/shakeelmirza/4110440/303918
#EXTINF:-1 tvg-id="" tvg-name="AL: Fashion TV" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania ➾ LifeStyle",AL: Fashion TV
http://ip96.uk:8080/shakeelmirza/4110440/303919
#EXTINF:-1 tvg-id="" tvg-name="AL: Ferma Vip 1" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania ➾ LifeStyle",AL: Ferma Vip 1
http://ip96.uk:8080/shakeelmirza/4110440/303920
#EXTINF:-1 tvg-id="" tvg-name="AL: Ferma Vip 2" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="Albania ➾ LifeStyle",AL: Ferma Vip 2
http://ip96.uk:8080/shakeelmirza/4110440/303921
#EXTINF:-1 tvg-id="" tvg-name="AL: First Channel" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/c7fd10691cc843f95f0908905480eea0.png" group-title="Albania ➾ LifeStyle",AL: First Channel
http://ip96.uk:8080/shakeelmirza/4110440/303922
#EXTINF:-1 tvg-id="" tvg-name="AL: Kanali 7" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/55138217ab079c60497daf3f4f722a44.png" group-title="Albania ➾ LifeStyle",AL: Kanali 7
http://ip96.uk:8080/shakeelmirza/4110440/303923
#EXTINF:-1 tvg-id="" tvg-name="AL: Klan Kosova" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/f5069fbc944f9b037859da85c68e725e.png" group-title="Albania ➾ LifeStyle",AL: Klan Kosova
http://ip96.uk:8080/shakeelmirza/4110440/303924
#EXTINF:-1 tvg-id="" tvg-name="AL: Klan Macedonia" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-07/281a31d9f421e66d8c66fdb3be008957.png" group-title="Albania ➾ LifeStyle",AL: Klan Macedonia
http://ip96.uk:8080/shakeelmirza/4110440/303925
#EXTINF:-1 tvg-id="" tvg-name="AL: Klan Plus" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/f366c3269e64ff77d0a400580951a96e.png" group-title="Albania ➾ LifeStyle",AL: Klan Plus
http://ip96.uk:8080/shakeelmirza/4110440/303926
#EXTINF:-1 tvg-id="" tvg-name="AL: Koha TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/e2ced51fa8b30b734ccf765b85b7f2f8.jpg" group-title="Albania ➾ LifeStyle",AL: Koha TV
http://ip96.uk:8080/shakeelmirza/4110440/303927
#EXTINF:-1 tvg-id="" tvg-name="AL: KTV Kohavision" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/35bb4fd82d973921030f0189694522fa.jpg" group-title="Albania ➾ LifeStyle",AL: KTV Kohavision
http://ip96.uk:8080/shakeelmirza/4110440/303928
#EXTINF:-1 tvg-id="" tvg-name="AL: Living" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/e2d646e5b32546a6dbe83001b0414e56.png" group-title="Albania ➾ LifeStyle",AL: Living
http://ip96.uk:8080/shakeelmirza/4110440/303929
#EXTINF:-1 tvg-id="" tvg-name="AL: MCN TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-01/84328831fa19ad420ea7f1520d33bfa3.png" group-title="Albania ➾ LifeStyle",AL: MCN TV
http://ip96.uk:8080/shakeelmirza/4110440/303930
#EXTINF:-1 tvg-id="" tvg-name="AL: Muse TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/8c1c24c42cedcc683029fe78e86f2b2f.png" group-title="Albania ➾ LifeStyle",AL: Muse TV
http://ip96.uk:8080/shakeelmirza/4110440/303931
#EXTINF:-1 tvg-id="" tvg-name="AL: Ora" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-07/eef7666644595f5e056adf5620d97a4d.png" group-title="Albania ➾ LifeStyle",AL: Ora
http://ip96.uk:8080/shakeelmirza/4110440/303932
#EXTINF:-1 tvg-id="" tvg-name="AL: Peace TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/127fed99e14527d5771aee47da055db8.jpeg" group-title="Albania ➾ LifeStyle",AL: Peace TV
http://ip96.uk:8080/shakeelmirza/4110440/303933
#EXTINF:-1 tvg-id="" tvg-name="AL: Portokalli" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2024-01/61ffee2b6ea8debc7b912197efb3ff04.jpg" group-title="Albania ➾ LifeStyle",AL: Portokalli
http://ip96.uk:8080/shakeelmirza/4110440/303934
#EXTINF:-1 tvg-id="" tvg-name="AL: RTK 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/baf7bf76cef98f2e6f0d3fa9e836f896.png" group-title="Albania ➾ LifeStyle",AL: RTK 1
http://ip96.uk:8080/shakeelmirza/4110440/303935
#EXTINF:-1 tvg-id="" tvg-name="AL: RTK 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/3620d8e55b1b27057d07e50b7d83aa72.png" group-title="Albania ➾ LifeStyle",AL: RTK 2
http://ip96.uk:8080/shakeelmirza/4110440/303936
#EXTINF:-1 tvg-id="" tvg-name="AL: RTK 3" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/4bf5e68cebdfd6adfbbba71cacef99b0.png" group-title="Albania ➾ LifeStyle",AL: RTK 3
http://ip96.uk:8080/shakeelmirza/4110440/303937
#EXTINF:-1 tvg-id="" tvg-name="AL: RTK 4" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/7a736f678334e0caec808dca464e5c95.png" group-title="Albania ➾ LifeStyle",AL: RTK 4
http://ip96.uk:8080/shakeelmirza/4110440/303938
#EXTINF:-1 tvg-id="" tvg-name="AL: RTSH 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-07/0f9e089f10181b4032a1060569407a01.svg" group-title="Albania ➾ LifeStyle",AL: RTSH 1
http://ip96.uk:8080/shakeelmirza/4110440/303939
#EXTINF:-1 tvg-id="" tvg-name="AL: RTSH 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-07/35773f95678e4a4dfdc623c9bb0c77fa.svg" group-title="Albania ➾ LifeStyle",AL: RTSH 2
http://ip96.uk:8080/shakeelmirza/4110440/303940
#EXTINF:-1 tvg-id="" tvg-name="AL: RTSH 3" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-07/96aa53d22c69879794fb269ab38caf92.svg" group-title="Albania ➾ LifeStyle",AL: RTSH 3
http://ip96.uk:8080/shakeelmirza/4110440/303941
#EXTINF:-1 tvg-id="" tvg-name="AL: RTSH Agro" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-07/2220440114a101fd1eaa2e69b4e2d4a3.svg" group-title="Albania ➾ LifeStyle",AL: RTSH Agro
http://ip96.uk:8080/shakeelmirza/4110440/303942
#EXTINF:-1 tvg-id="" tvg-name="AL: RTSH Femije" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-06/1fb8b7d702106a0099b78893f5b696ee.svg" group-title="Albania ➾ LifeStyle",AL: RTSH Femije
http://ip96.uk:8080/shakeelmirza/4110440/303943
#EXTINF:-1 tvg-id="" tvg-name="AL: RTSH Gjirokastra" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-07/74abeaf2819ce0729b7f00581b28e62e.svg" group-title="Albania ➾ LifeStyle",AL: RTSH Gjirokastra
http://ip96.uk:8080/shakeelmirza/4110440/303944
#EXTINF:-1 tvg-id="" tvg-name="AL: RTSH Korca" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-06/11be00f9db7f484c48609adfb297238f.svg" group-title="Albania ➾ LifeStyle",AL: RTSH Korca
http://ip96.uk:8080/shakeelmirza/4110440/303945
#EXTINF:-1 tvg-id="" tvg-name="AL: RTSH Kukesi" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-07/19a49e326e628155a8d7a8db1a20e3a5.svg" group-title="Albania ➾ LifeStyle",AL: RTSH Kukesi
http://ip96.uk:8080/shakeelmirza/4110440/303946
#EXTINF:-1 tvg-id="" tvg-name="AL: RTSH Kuvend" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-07/877ce84eca21eea5cc4cc52043c73cdc.svg" group-title="Albania ➾ LifeStyle",AL: RTSH Kuvend
http://ip96.uk:8080/shakeelmirza/4110440/303947
#EXTINF:-1 tvg-id="" tvg-name="AL: RTSH Plus" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-07/b6f004251405caa3b5c1aa3d2426a15c.svg" group-title="Albania ➾ LifeStyle",AL: RTSH Plus
http://ip96.uk:8080/shakeelmirza/4110440/303948
#EXTINF:-1 tvg-id="" tvg-name="AL: RTSH Satelit" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-07/903acb92b2b1674561636bd877d9adc3.png" group-title="Albania ➾ LifeStyle",AL: RTSH Satelit
http://ip96.uk:8080/shakeelmirza/4110440/303949
#EXTINF:-1 tvg-id="" tvg-name="AL: RTSH Shkodra" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-07/24bd976221001ff80c027daa5b7ac8e4.png" group-title="Albania ➾ LifeStyle",AL: RTSH Shkodra
http://ip96.uk:8080/shakeelmirza/4110440/303950
#EXTINF:-1 tvg-id="" tvg-name="AL: RTSH Shkolle" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-04/174d4bcd7f28a11ac1f7542675c1e961.svg" group-title="Albania ➾ LifeStyle",AL: RTSH Shkolle
http://ip96.uk:8080/shakeelmirza/4110440/303951
#EXTINF:-1 tvg-id="" tvg-name="AL: RTV 21" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/2c4f7f62b27a589f916baedaacdd3882.png" group-title="Albania ➾ LifeStyle",AL: RTV 21
http://ip96.uk:8080/shakeelmirza/4110440/303952
#EXTINF:-1 tvg-id="" tvg-name="AL: RTV 21 Mix" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-06/950f993e563b9f14c58e8a4db540ed37.png" group-title="Albania ➾ LifeStyle",AL: RTV 21 Mix
http://ip96.uk:8080/shakeelmirza/4110440/303953
#EXTINF:-1 tvg-id="" tvg-name="AL: RTV 21 Plus" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/1b4040b73ebd15c45debb44748c4bf59.png" group-title="Albania ➾ LifeStyle",AL: RTV 21 Plus
http://ip96.uk:8080/shakeelmirza/4110440/303954
#EXTINF:-1 tvg-id="" tvg-name="AL: RTV 21 Popullore" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/7eb2ffd0462211537a78abc809bd6ab7.png" group-title="Albania ➾ LifeStyle",AL: RTV 21 Popullore
http://ip96.uk:8080/shakeelmirza/4110440/303955
#EXTINF:-1 tvg-id="" tvg-name="AL: RTV Dukagjini" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/fa3c38ea620be6656c37ec59faa83bdd.png" group-title="Albania ➾ LifeStyle",AL: RTV Dukagjini
http://ip96.uk:8080/shakeelmirza/4110440/303956
#EXTINF:-1 tvg-id="" tvg-name="AL: Star Plus" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/aeb4d3ba777598eb409ebf6d6a1f7e2f.png" group-title="Albania ➾ LifeStyle",AL: Star Plus
http://ip96.uk:8080/shakeelmirza/4110440/303957
#EXTINF:-1 tvg-id="" tvg-name="AL: T7" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-01/e51ec8d204406e82257fc581fca5616a.png" group-title="Albania ➾ LifeStyle",AL: T7
http://ip96.uk:8080/shakeelmirza/4110440/303958
#EXTINF:-1 tvg-id="" tvg-name="AL: Teve 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-06/8973cd61db359bdb4c411314127da4a0.png" group-title="Albania ➾ LifeStyle",AL: Teve 1
http://ip96.uk:8080/shakeelmirza/4110440/303959
#EXTINF:-1 tvg-id="" tvg-name="AL: Tip TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/4d9ee786fddd6132b4f5954940f272dd.png" group-title="Albania ➾ LifeStyle",AL: Tip TV
http://ip96.uk:8080/shakeelmirza/4110440/303960
#EXTINF:-1 tvg-id="" tvg-name="AL: TOP Channel" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/ccdd2ccdf1cface8d5a14186566daf84.png" group-title="Albania ➾ LifeStyle",AL: TOP Channel
http://ip96.uk:8080/shakeelmirza/4110440/303961
#EXTINF:-1 tvg-id="" tvg-name="AL: TV 21 Macedonia" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/ed5d29ea9bb9627a5c7b0e419c74c204.png" group-title="Albania ➾ LifeStyle",AL: TV 21 Macedonia
http://ip96.uk:8080/shakeelmirza/4110440/303962
#EXTINF:-1 tvg-id="" tvg-name="AL: Vizion Plus" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/81af6d3489034eab2c610279a903cd4f.png" group-title="Albania ➾ LifeStyle",AL: Vizion Plus
http://ip96.uk:8080/shakeelmirza/4110440/303963
#EXTINF:-1 tvg-id="" tvg-name="AL: Zico TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2024-01/d9787e2b70742d7ec34b647d46f0568d.png" group-title="Albania ➾ LifeStyle",AL: Zico TV
http://ip96.uk:8080/shakeelmirza/4110440/303964
#EXTINF:-1 tvg-id="" tvg-name="AL: A2 CNN" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-07/e6134662a6df54df16e72f147a19a565.svg" group-title="Albania ➾ News",AL: A2 CNN
http://ip96.uk:8080/shakeelmirza/4110440/303965
#EXTINF:-1 tvg-id="" tvg-name="AL: ABC" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/fb31ad95ec4bbc4be881e750ea856a89.png" group-title="Albania ➾ News",AL: ABC
http://ip96.uk:8080/shakeelmirza/4110440/303966
#EXTINF:-1 tvg-id="" tvg-name="AL: City News Albania" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2024-01/5a46a23979689721e285c906ad2e004b.svg" group-title="Albania ➾ News",AL: City News Albania
http://ip96.uk:8080/shakeelmirza/4110440/303967
#EXTINF:-1 tvg-id="" tvg-name="AL: euronews" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/cee60d23cf0e39f75c012c4e67bc1985.png" group-title="Albania ➾ News",AL: euronews
http://ip96.uk:8080/shakeelmirza/4110440/303968
#EXTINF:-1 tvg-id="" tvg-name="AL: Fax News" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/65259128a7f8d93d9f19f846179231fe.png" group-title="Albania ➾ News",AL: Fax News
http://ip96.uk:8080/shakeelmirza/4110440/303969
#EXTINF:-1 tvg-id="" tvg-name="AL: Kanal 10" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/c655613efc4c5e1acbb02c59c874c2fb.png" group-title="Albania ➾ News",AL: Kanal 10
http://ip96.uk:8080/shakeelmirza/4110440/303970
#EXTINF:-1 tvg-id="" tvg-name="AL: Klan News" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-07/0d8ad0f34c08fc3c2c450416dce507c6.png" group-title="Albania ➾ News",AL: Klan News
http://ip96.uk:8080/shakeelmirza/4110440/303971
#EXTINF:-1 tvg-id="" tvg-name="AL: News 24" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-09/ab1944806491152eb48a5538c89394ee.png" group-title="Albania ➾ News",AL: News 24
http://ip96.uk:8080/shakeelmirza/4110440/303972
#EXTINF:-1 tvg-id="" tvg-name="AL: Ora News" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/d4ac2713819e179c78c678ae6c1636bb.png" group-title="Albania ➾ News",AL: Ora News
http://ip96.uk:8080/shakeelmirza/4110440/303973
#EXTINF:-1 tvg-id="" tvg-name="AL: Report TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/144beb981ee21f4b042307d63fb10d30.png" group-title="Albania ➾ News",AL: Report TV
http://ip96.uk:8080/shakeelmirza/4110440/303974
#EXTINF:-1 tvg-id="" tvg-name="AL: RTSH 24" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-07/cdb42292d9c45ae1db8241b4fdcc0dd2.svg" group-title="Albania ➾ News",AL: RTSH 24
http://ip96.uk:8080/shakeelmirza/4110440/303975
#EXTINF:-1 tvg-id="" tvg-name="AL: Scan" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-06/385c653e4f513cf21f7aca72c7b3cba7.png" group-title="Albania ➾ News",AL: Scan
http://ip96.uk:8080/shakeelmirza/4110440/303976
#EXTINF:-1 tvg-id="" tvg-name="AL: Syri News" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-09/d58c84750f77c5262213449c1c108db7.jpg" group-title="Albania ➾ News",AL: Syri News
http://ip96.uk:8080/shakeelmirza/4110440/303977
#EXTINF:-1 tvg-id="" tvg-name="AL: TOP News" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/eba7a81a10dcbc247ee6245ced118cf8.png" group-title="Albania ➾ News",AL: TOP News
http://ip96.uk:8080/shakeelmirza/4110440/303978
#EXTINF:-1 tvg-id="" tvg-name="AL: Tring Sport News" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/d336e84b188eca200534666d82b422c9.png" group-title="Albania ➾ News",AL: Tring Sport News
http://ip96.uk:8080/shakeelmirza/4110440/303979
#EXTINF:-1 tvg-id="" tvg-name="AL: TV Klan" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/46595988f0083f19afd11068bd05c6d0.png" group-title="Albania ➾ News",AL: TV Klan
http://ip96.uk:8080/shakeelmirza/4110440/303980
#EXTINF:-1 tvg-id="" tvg-name="AL: Alb Swiss" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/06509b8b29e26f2b34a0a0c28e2128c3.png" group-title="Albania ➾ Music",AL: Alb Swiss
http://ip96.uk:8080/shakeelmirza/4110440/303981
#EXTINF:-1 tvg-id="" tvg-name="AL: Albkanale Muzik" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2024-04/6c96f3fcc71c4e2bf06a51cf86b47cdf.jpg" group-title="Albania ➾ Music",AL: Albkanale Muzik
http://ip96.uk:8080/shakeelmirza/4110440/303982
#EXTINF:-1 tvg-id="" tvg-name="AL: Arti TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-04/0003ac6f8756aff13f094d45596c2802.png" group-title="Albania ➾ Music",AL: Arti TV
http://ip96.uk:8080/shakeelmirza/4110440/303983
#EXTINF:-1 tvg-id="" tvg-name="AL: BBF Music TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-06/4153e6d9d92367e3d7faf527c32c8f34.png" group-title="Albania ➾ Music",AL: BBF Music TV
http://ip96.uk:8080/shakeelmirza/4110440/303984
#EXTINF:-1 tvg-id="" tvg-name="AL: Click" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/b93f3ea577764cf67133258c8902ccca.png" group-title="Albania ➾ Music",AL: Click
http://ip96.uk:8080/shakeelmirza/4110440/303985
#EXTINF:-1 tvg-id="" tvg-name="AL: Folk+" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/abbd8b8bd69bc1f6881e45c60d238ad9.jpg" group-title="Albania ➾ Music",AL: Folk+
http://ip96.uk:8080/shakeelmirza/4110440/303986
#EXTINF:-1 tvg-id="" tvg-name="AL: Folklorit" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-08/36a7fecfaad1576730e88ef51e6003a1.jpg" group-title="Albania ➾ Music",AL: Folklorit
http://ip96.uk:8080/shakeelmirza/4110440/303987
#EXTINF:-1 tvg-id="" tvg-name="AL: Klan Music" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/3fefb1cce7c6c660ebe0d8d1443f0fbe.jpg" group-title="Albania ➾ Music",AL: Klan Music
http://ip96.uk:8080/shakeelmirza/4110440/303988
#EXTINF:-1 tvg-id="" tvg-name="AL: MTV Kosova" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/8c62bf6c87574289bf103877b09ee901.jpg" group-title="Albania ➾ Music",AL: MTV Kosova
http://ip96.uk:8080/shakeelmirza/4110440/303989
#EXTINF:-1 tvg-id="" tvg-name="AL: My Music" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/e59d0fb982c4fa1155a269326360887f.png" group-title="Albania ➾ Music",AL: My Music
http://ip96.uk:8080/shakeelmirza/4110440/303990
#EXTINF:-1 tvg-id="" tvg-name="AL: RTSH Muzike" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-07/3c11cc7a5c9ed8aae2ea089ceefa2c57.svg" group-title="Albania ➾ Music",AL: RTSH Muzike
http://ip96.uk:8080/shakeelmirza/4110440/303991
#EXTINF:-1 tvg-id="" tvg-name="AL: STV Folk" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-06/5ccc5f550f20534191effbb884106bb6.png" group-title="Albania ➾ Music",AL: STV Folk
http://ip96.uk:8080/shakeelmirza/4110440/303992
#EXTINF:-1 tvg-id="" tvg-name="AL: Super Sonic TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/780ca28c4b7d72fbb4584650714e9012.png" group-title="Albania ➾ Music",AL: Super Sonic TV
http://ip96.uk:8080/shakeelmirza/4110440/303993
#EXTINF:-1 tvg-id="" tvg-name="AL: TV Sharri" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/03bf7ee22afa23be577be153f1748038.png" group-title="Albania ➾ Music",AL: TV Sharri
http://ip96.uk:8080/shakeelmirza/4110440/303994
#EXTINF:-1 tvg-id="" tvg-name="AL: ANIMAL PLANET" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/9afa447ec356f42e26e6a01e01774e0f.png" group-title="Albania ➾ Nature",AL: ANIMAL PLANET
http://ip96.uk:8080/shakeelmirza/4110440/303995
#EXTINF:-1 tvg-id="" tvg-name="AL: Tring Planet" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/afc0149ae70eca0a72841295dbb499ea.png" group-title="Albania ➾ Nature",AL: Tring Planet
http://ip96.uk:8080/shakeelmirza/4110440/303996
#EXTINF:-1 tvg-id="" tvg-name="AL: Arena Sport 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/577d05bbbff32984817bb5651dc77549.png" group-title="Albania ➾ Sports",AL: Arena Sport 1
http://ip96.uk:8080/shakeelmirza/4110440/303997
#EXTINF:-1 tvg-id="" tvg-name="AL: Arena Sport 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/14078476ccd04f73e80473edc0a0037c.png" group-title="Albania ➾ Sports",AL: Arena Sport 2
http://ip96.uk:8080/shakeelmirza/4110440/303998
#EXTINF:-1 tvg-id="" tvg-name="AL: Arena Sport 4" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/0b368e483f287a3f3e07bab3dd8f652f.png" group-title="Albania ➾ Sports",AL: Arena Sport 4
http://ip96.uk:8080/shakeelmirza/4110440/303999
#EXTINF:-1 tvg-id="" tvg-name="AL: Arena Sport 5" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/d5681f9e3564d378ff7769b8037581dc.png" group-title="Albania ➾ Sports",AL: Arena Sport 5
http://ip96.uk:8080/shakeelmirza/4110440/304000
#EXTINF:-1 tvg-id="" tvg-name="AL: ART Sport 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-06/d016a2c0dd5d33df89a4f85a016b9299.png" group-title="Albania ➾ Sports",AL: ART Sport 1
http://ip96.uk:8080/shakeelmirza/4110440/304001
#EXTINF:-1 tvg-id="" tvg-name="AL: ART Sport 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-06/1f3685cf082119f422fe1bd584cbb48c.png" group-title="Albania ➾ Sports",AL: ART Sport 2
http://ip96.uk:8080/shakeelmirza/4110440/304002
#EXTINF:-1 tvg-id="" tvg-name="AL: ART Sport 3" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/7977d0e43fed7b4efd627df97b1a4e29.png" group-title="Albania ➾ Sports",AL: ART Sport 3
http://ip96.uk:8080/shakeelmirza/4110440/304003
#EXTINF:-1 tvg-id="" tvg-name="AL: ART Sport 4" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/29bd2d194a584b18ac79234629e0e7d3.png" group-title="Albania ➾ Sports",AL: ART Sport 4
http://ip96.uk:8080/shakeelmirza/4110440/304004
#EXTINF:-1 tvg-id="" tvg-name="AL: ART Sport 5" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/8b1c9902f40ad05adb08639c21185942.png" group-title="Albania ➾ Sports",AL: ART Sport 5
http://ip96.uk:8080/shakeelmirza/4110440/304005
#EXTINF:-1 tvg-id="" tvg-name="AL: Eurosport 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/f1cecaaf5d587858aabdde39a3a50e15.png" group-title="Albania ➾ Sports",AL: Eurosport 1
http://ip96.uk:8080/shakeelmirza/4110440/304006
#EXTINF:-1 tvg-id="" tvg-name="AL: Eurosport 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/58c261282f835c1c845666c27004ad9c.png" group-title="Albania ➾ Sports",AL: Eurosport 2
http://ip96.uk:8080/shakeelmirza/4110440/304007
#EXTINF:-1 tvg-id="" tvg-name="AL: Kujtesa Sport 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/7b4d3d4bcb7f01fc9d9d633995198bff.jpg" group-title="Albania ➾ Sports",AL: Kujtesa Sport 1
http://ip96.uk:8080/shakeelmirza/4110440/304008
#EXTINF:-1 tvg-id="" tvg-name="AL: Kujtesa Sport 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/0bcdad89b4447a2a1a50f8b6e6f27d2b.jpg" group-title="Albania ➾ Sports",AL: Kujtesa Sport 2
http://ip96.uk:8080/shakeelmirza/4110440/304009
#EXTINF:-1 tvg-id="" tvg-name="AL: Kujtesa Sport 3" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/374268c45e28a927265cafd3d15bca99.jpg" group-title="Albania ➾ Sports",AL: Kujtesa Sport 3
http://ip96.uk:8080/shakeelmirza/4110440/304010
#EXTINF:-1 tvg-id="" tvg-name="AL: Kujtesa Sport 4" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/e97db585bf968f9c3df5945b962726d1.jpg" group-title="Albania ➾ Sports",AL: Kujtesa Sport 4
http://ip96.uk:8080/shakeelmirza/4110440/304011
#EXTINF:-1 tvg-id="" tvg-name="AL: RTSH Sport" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-07/bf23238a743c9feae86249cae1e285d3.svg" group-title="Albania ➾ Sports",AL: RTSH Sport
http://ip96.uk:8080/shakeelmirza/4110440/304012
#EXTINF:-1 tvg-id="" tvg-name="AL: SuperSport 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/dd40a0c54e5a3acb0ffce128dc90de94.png" group-title="Albania ➾ Sports",AL: SuperSport 1
http://ip96.uk:8080/shakeelmirza/4110440/304013
#EXTINF:-1 tvg-id="" tvg-name="AL: SuperSport 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/9519a058698941aadb6473f8721e58b1.png" group-title="Albania ➾ Sports",AL: SuperSport 2
http://ip96.uk:8080/shakeelmirza/4110440/304014
#EXTINF:-1 tvg-id="" tvg-name="AL: SuperSport 3" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/dd3c9c967ec530a8b19978ca6aac4588.png" group-title="Albania ➾ Sports",AL: SuperSport 3
http://ip96.uk:8080/shakeelmirza/4110440/304015
#EXTINF:-1 tvg-id="" tvg-name="AL: SuperSport 4" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/e0c350049cb9584a4a13c63aaf405857.png" group-title="Albania ➾ Sports",AL: SuperSport 4
http://ip96.uk:8080/shakeelmirza/4110440/304016
#EXTINF:-1 tvg-id="" tvg-name="AL: SuperSport 5" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-04/c6be34175b71784909e9493c29135344.png" group-title="Albania ➾ Sports",AL: SuperSport 5
http://ip96.uk:8080/shakeelmirza/4110440/304017
#EXTINF:-1 tvg-id="" tvg-name="AL: SuperSport 6" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/f2f8128ce788087140b3d84a313fe6e8.png" group-title="Albania ➾ Sports",AL: SuperSport 6
http://ip96.uk:8080/shakeelmirza/4110440/304018
#EXTINF:-1 tvg-id="" tvg-name="AL: SuperSport 7" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-06/90b0f1e0b931a25f5257b5ff05e96fe5.png" group-title="Albania ➾ Sports",AL: SuperSport 7
http://ip96.uk:8080/shakeelmirza/4110440/304019
#EXTINF:-1 tvg-id="" tvg-name="AL: SuperSport News" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-11/dff061a1127ec25516208e9610bd550d.jpg" group-title="Albania ➾ Sports",AL: SuperSport News
http://ip96.uk:8080/shakeelmirza/4110440/304020
#EXTINF:-1 tvg-id="" tvg-name="AL: Tring Sport 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/159a3e53a509523324405a783571860a.png" group-title="Albania ➾ Sports",AL: Tring Sport 1
http://ip96.uk:8080/shakeelmirza/4110440/304021
#EXTINF:-1 tvg-id="" tvg-name="AL: Tring Sport 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/43c29acadbe04ba7cccb93430e73d373.png" group-title="Albania ➾ Sports",AL: Tring Sport 2
http://ip96.uk:8080/shakeelmirza/4110440/304022
#EXTINF:-1 tvg-id="" tvg-name="AL: Tring Sport 3" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/85de7720019eb796d9dfe20898807b36.png" group-title="Albania ➾ Sports",AL: Tring Sport 3
http://ip96.uk:8080/shakeelmirza/4110440/304023
#EXTINF:-1 tvg-id="" tvg-name="AL: Tring Sport 4" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-09/6a7cf8d9da4b44e4a17d4874a96de13f.png" group-title="Albania ➾ Sports",AL: Tring Sport 4
http://ip96.uk:8080/shakeelmirza/4110440/304024
#EXTINF:-1 tvg-id="" tvg-name="AL: Baby TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-06/bfffd3dcc537580d993145acb49d47d4.png" group-title="Albania ➾ Kids",AL: Baby TV
http://ip96.uk:8080/shakeelmirza/4110440/304025
#EXTINF:-1 tvg-id="" tvg-name="AL: Bang Bang" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-06/96e9592c36c5590a5503a86aa8c84042.png" group-title="Albania ➾ Kids",AL: Bang Bang
http://ip96.uk:8080/shakeelmirza/4110440/304026
#EXTINF:-1 tvg-id="" tvg-name="AL: Boomerang" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-06/18f4f54f7148e2049f237e8b2a2ed8ba.png" group-title="Albania ➾ Kids",AL: Boomerang
http://ip96.uk:8080/shakeelmirza/4110440/304027
#EXTINF:-1 tvg-id="" tvg-name="AL: Bubble" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-09/700669332184c7ec53f9fe104f6b285b.png" group-title="Albania ➾ Kids",AL: Bubble
http://ip96.uk:8080/shakeelmirza/4110440/304028
#EXTINF:-1 tvg-id="" tvg-name="AL: Cufo" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-06/4fe3cc13a7cd65569e49171ad91e51ee.png" group-title="Albania ➾ Kids",AL: Cufo
http://ip96.uk:8080/shakeelmirza/4110440/304029
#EXTINF:-1 tvg-id="" tvg-name="AL: Disney Junior" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-06/218b80728b2371099f57f0b9a8caf84c.png" group-title="Albania ➾ Kids",AL: Disney Junior
http://ip96.uk:8080/shakeelmirza/4110440/304030
#EXTINF:-1 tvg-id="" tvg-name="AL: Junior" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/7ea9318cd70c5d2660473316c5394844.jpg" group-title="Albania ➾ Kids",AL: Junior
http://ip96.uk:8080/shakeelmirza/4110440/304031
#EXTINF:-1 tvg-id="" tvg-name="AL: RTV 21 Junior" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-05/9ab1585b7bfce829faff255183eaadd3.png" group-title="Albania ➾ Kids",AL: RTV 21 Junior
http://ip96.uk:8080/shakeelmirza/4110440/304032
#EXTINF:-1 tvg-id="" tvg-name="AL: Tring Kids" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/7f798ebf0224602cf264275c9922602d.png" group-title="Albania ➾ Kids",AL: Tring Kids
http://ip96.uk:8080/shakeelmirza/4110440/304033
#EXTINF:-1 tvg-id="" tvg-name="AL: Tring Tring" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/a7c16d47b5668b4e414829112d1198f8.png" group-title="Albania ➾ Kids",AL: Tring Tring
http://ip96.uk:8080/shakeelmirza/4110440/304034
#EXTINF:-1 tvg-id="" tvg-name="AL: Cinemax 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-07/94c83bd97c74751ea618bbb516c80a85.png" group-title="Albania ➾ Movie",AL: Cinemax 2
http://ip96.uk:8080/shakeelmirza/4110440/304035
#EXTINF:-1 tvg-id="" tvg-name="AL: CineStar TV 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-01/cd291c39df78dfe5f52e0e08d251c723.png" group-title="Albania ➾ Movie",AL: CineStar TV 1
http://ip96.uk:8080/shakeelmirza/4110440/304036
#EXTINF:-1 tvg-id="" tvg-name="AL: CineStar TV 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-01/eb1edcc1daa957427d2949026885dd00.png" group-title="Albania ➾ Movie",AL: CineStar TV 2
http://ip96.uk:8080/shakeelmirza/4110440/304037
#EXTINF:-1 tvg-id="" tvg-name="AL: CineStar TV Action" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-01/00766e77c98d14b7ebc058f5bc518b1e.png" group-title="Albania ➾ Movie",AL: CineStar TV Action
http://ip96.uk:8080/shakeelmirza/4110440/304038
#EXTINF:-1 tvg-id="" tvg-name="AL: CineStar TV Comedy" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-06/8ec037df3b11b7468b0d1dd5bb5007bd.png" group-title="Albania ➾ Movie",AL: CineStar TV Comedy
http://ip96.uk:8080/shakeelmirza/4110440/304039
#EXTINF:-1 tvg-id="" tvg-name="AL: CineStar TV Premiere 1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-01/c58bee426c97015fe68762a3026a514d.png" group-title="Albania ➾ Movie",AL: CineStar TV Premiere 1
http://ip96.uk:8080/shakeelmirza/4110440/304040
#EXTINF:-1 tvg-id="" tvg-name="AL: CineStar TV Premiere 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-01/466bc8acf4ce9bcd0a7eaafeb6dd6ced.png" group-title="Albania ➾ Movie",AL: CineStar TV Premiere 2
http://ip96.uk:8080/shakeelmirza/4110440/304041
#EXTINF:-1 tvg-id="" tvg-name="AL: Dizi Channel" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-06/d5bfb51db01479c076cb8a6a4c902d05.jpg" group-title="Albania ➾ Movie",AL: Dizi Channel
http://ip96.uk:8080/shakeelmirza/4110440/304042
#EXTINF:-1 tvg-id="" tvg-name="AL: Eurofilm" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/79aa3642c99a124bafc4d22b5221699b.png" group-title="Albania ➾ Movie",AL: Eurofilm
http://ip96.uk:8080/shakeelmirza/4110440/304043
#EXTINF:-1 tvg-id="" tvg-name="AL: Film Aksion" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/beaf84d6b29cd990d3809d7398ddaba3.png" group-title="Albania ➾ Movie",AL: Film Aksion
http://ip96.uk:8080/shakeelmirza/4110440/304044
#EXTINF:-1 tvg-id="" tvg-name="AL: Film Autor" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/e16b653c615b5edfde75936d7c1390cb.png" group-title="Albania ➾ Movie",AL: Film Autor
http://ip96.uk:8080/shakeelmirza/4110440/304045
#EXTINF:-1 tvg-id="" tvg-name="AL: Film Drame" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/9f640745f5d13a1a2cd8ec2088f9d716.png" group-title="Albania ➾ Movie",AL: Film Drame
http://ip96.uk:8080/shakeelmirza/4110440/304046
#EXTINF:-1 tvg-id="" tvg-name="AL: Film Gold" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-04/8c5e3cde05f17fce53338bfc0cf52709.png" group-title="Albania ➾ Movie",AL: Film Gold
http://ip96.uk:8080/shakeelmirza/4110440/304047
#EXTINF:-1 tvg-id="" tvg-name="AL: Film Hits" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/2056af42bfede55def9433e27e7c9a2d.png" group-title="Albania ➾ Movie",AL: Film Hits
http://ip96.uk:8080/shakeelmirza/4110440/304048
#EXTINF:-1 tvg-id="" tvg-name="AL: Film Komedi" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/1f9d633d207c14503547c47cbe5b217a.png" group-title="Albania ➾ Movie",AL: Film Komedi
http://ip96.uk:8080/shakeelmirza/4110440/304049
#EXTINF:-1 tvg-id="" tvg-name="AL: Film Max" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/3ed4911d4408efb8e81506bc4d3a48eb.png" group-title="Albania ➾ Movie",AL: Film Max
http://ip96.uk:8080/shakeelmirza/4110440/304050
#EXTINF:-1 tvg-id="" tvg-name="AL: Film Stinet" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/a850dafc10aea99f3c2d743d9dd77c2a.png" group-title="Albania ➾ Movie",AL: Film Stinet
http://ip96.uk:8080/shakeelmirza/4110440/304051
#EXTINF:-1 tvg-id="" tvg-name="AL: Film Thriller" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/a841fc5895554026a19ba23d20421304.png" group-title="Albania ➾ Movie",AL: Film Thriller
http://ip96.uk:8080/shakeelmirza/4110440/304052
#EXTINF:-1 tvg-id="" tvg-name="AL: Filma24 Action" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: Filma24 Action
http://ip96.uk:8080/shakeelmirza/4110440/304053
#EXTINF:-1 tvg-id="" tvg-name="AL: Filma24 Adventure" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: Filma24 Adventure
http://ip96.uk:8080/shakeelmirza/4110440/304054
#EXTINF:-1 tvg-id="" tvg-name="AL: Filma24 Animation" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: Filma24 Animation
http://ip96.uk:8080/shakeelmirza/4110440/304055
#EXTINF:-1 tvg-id="" tvg-name="AL: Filma24 Animuar" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: Filma24 Animuar
http://ip96.uk:8080/shakeelmirza/4110440/304056
#EXTINF:-1 tvg-id="" tvg-name="AL: Filma24 Aventure" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: Filma24 Aventure
http://ip96.uk:8080/shakeelmirza/4110440/304057
#EXTINF:-1 tvg-id="" tvg-name="AL: Filma24 Aziatik" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: Filma24 Aziatik
http://ip96.uk:8080/shakeelmirza/4110440/304058
#EXTINF:-1 tvg-id="" tvg-name="AL: Filma24 Biografi" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: Filma24 Biografi
http://ip96.uk:8080/shakeelmirza/4110440/304059
#EXTINF:-1 tvg-id="" tvg-name="AL: Filma24 Dokumentar" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: Filma24 Dokumentar
http://ip96.uk:8080/shakeelmirza/4110440/304060
#EXTINF:-1 tvg-id="" tvg-name="AL: Filma24 Drame" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: Filma24 Drame
http://ip96.uk:8080/shakeelmirza/4110440/304061
#EXTINF:-1 tvg-id="" tvg-name="AL: Filma24 Family" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: Filma24 Family
http://ip96.uk:8080/shakeelmirza/4110440/304062
#EXTINF:-1 tvg-id="" tvg-name="AL: Filma24 Fantazi" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: Filma24 Fantazi
http://ip96.uk:8080/shakeelmirza/4110440/304063
#EXTINF:-1 tvg-id="" tvg-name="AL: Filma24 Hindi" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: Filma24 Hindi
http://ip96.uk:8080/shakeelmirza/4110440/304064
#EXTINF:-1 tvg-id="" tvg-name="AL: Filma24 History" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: Filma24 History
http://ip96.uk:8080/shakeelmirza/4110440/304065
#EXTINF:-1 tvg-id="" tvg-name="AL: Filma24 Hits" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: Filma24 Hits
http://ip96.uk:8080/shakeelmirza/4110440/304066
#EXTINF:-1 tvg-id="" tvg-name="AL: Filma24 Horror" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: Filma24 Horror
http://ip96.uk:8080/shakeelmirza/4110440/304067
#EXTINF:-1 tvg-id="" tvg-name="AL: Filma24 Komedi" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: Filma24 Komedi
http://ip96.uk:8080/shakeelmirza/4110440/304068
#EXTINF:-1 tvg-id="" tvg-name="AL: Filma24 Krim" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: Filma24 Krim
http://ip96.uk:8080/shakeelmirza/4110440/304069
#EXTINF:-1 tvg-id="" tvg-name="AL: Filma24 Mister" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: Filma24 Mister
http://ip96.uk:8080/shakeelmirza/4110440/304070
#EXTINF:-1 tvg-id="" tvg-name="AL: Filma24 Premiere" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: Filma24 Premiere
http://ip96.uk:8080/shakeelmirza/4110440/304071
#EXTINF:-1 tvg-id="" tvg-name="AL: Filma24 Premium" tvg-logo="" group-title="Albania ➾ Movie",AL: Filma24 Premium
http://ip96.uk:8080/shakeelmirza/4110440/304072
#EXTINF:-1 tvg-id="" tvg-name="AL: Filma24 Romance" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: Filma24 Romance
http://ip96.uk:8080/shakeelmirza/4110440/304073
#EXTINF:-1 tvg-id="" tvg-name="AL: Filma24 SCI-Fi" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: Filma24 SCI-Fi
http://ip96.uk:8080/shakeelmirza/4110440/304074
#EXTINF:-1 tvg-id="" tvg-name="AL: Filma24 Triller" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: Filma24 Triller
http://ip96.uk:8080/shakeelmirza/4110440/304075
#EXTINF:-1 tvg-id="" tvg-name="AL: Filma24 Turk" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: Filma24 Turk
http://ip96.uk:8080/shakeelmirza/4110440/304076
#EXTINF:-1 tvg-id="" tvg-name="AL: Filma24 Western" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: Filma24 Western
http://ip96.uk:8080/shakeelmirza/4110440/304077
#EXTINF:-1 tvg-id="" tvg-name="AL: FilmBox Arthouse" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/c0c1373a50dcc5d542848c614bb7e1b2.png" group-title="Albania ➾ Movie",AL: FilmBox Arthouse
http://ip96.uk:8080/shakeelmirza/4110440/304078
#EXTINF:-1 tvg-id="" tvg-name="AL: FilmBox Extra" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/e573ad1433a230b358a8095be1164351.png" group-title="Albania ➾ Movie",AL: FilmBox Extra
http://ip96.uk:8080/shakeelmirza/4110440/304079
#EXTINF:-1 tvg-id="" tvg-name="AL: FilmBox Premium" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/c77104eab4777aada326742c6724d53b.jpg" group-title="Albania ➾ Movie",AL: FilmBox Premium
http://ip96.uk:8080/shakeelmirza/4110440/304080
#EXTINF:-1 tvg-id="" tvg-name="AL: FilmBox Stars" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2024-04/5fac980f8234472353a35461630c9a45.png" group-title="Albania ➾ Movie",AL: FilmBox Stars
http://ip96.uk:8080/shakeelmirza/4110440/304081
#EXTINF:-1 tvg-id="" tvg-name="AL: FOX" tvg-logo="http://s3.i3ns.net/portal/picon/2020-07/8ee2e1172fc51f015ad925c15485cfcf.png" group-title="Albania ➾ Movie",AL: FOX
http://ip96.uk:8080/shakeelmirza/4110440/304082
#EXTINF:-1 tvg-id="" tvg-name="AL: Fox Crime" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/9aa21e733f137a5526791fddec3f4810.png" group-title="Albania ➾ Movie",AL: Fox Crime
http://ip96.uk:8080/shakeelmirza/4110440/304083
#EXTINF:-1 tvg-id="" tvg-name="AL: Fox Life" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/30d2125bd2a9b95aa37d432aa55d314e.png" group-title="Albania ➾ Movie",AL: Fox Life
http://ip96.uk:8080/shakeelmirza/4110440/304084
#EXTINF:-1 tvg-id="" tvg-name="AL: Fox Movies" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/f2aee728753182282d3b8fe502bbc978.png" group-title="Albania ➾ Movie",AL: Fox Movies
http://ip96.uk:8080/shakeelmirza/4110440/304085
#EXTINF:-1 tvg-id="" tvg-name="AL: HBO" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/01fb3c74d58f9d37b24700124bcdb048.png" group-title="Albania ➾ Movie",AL: HBO
http://ip96.uk:8080/shakeelmirza/4110440/304086
#EXTINF:-1 tvg-id="" tvg-name="AL: HBO 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/e4d71274884261995916467241a66d8d.png" group-title="Albania ➾ Movie",AL: HBO 2
http://ip96.uk:8080/shakeelmirza/4110440/304087
#EXTINF:-1 tvg-id="" tvg-name="AL: HBO 3" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/948e628c670df382770d30ab57fab8a4.png" group-title="Albania ➾ Movie",AL: HBO 3
http://ip96.uk:8080/shakeelmirza/4110440/304088
#EXTINF:-1 tvg-id="" tvg-name="AL: Kanal D Drama" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/0a43ac4e7afac393bd3c378011eff512.png" group-title="Albania ➾ Movie",AL: Kanal D Drama
http://ip96.uk:8080/shakeelmirza/4110440/304089
#EXTINF:-1 tvg-id="" tvg-name="AL: KS Filma24 Aksion" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: KS Filma24 Aksion
http://ip96.uk:8080/shakeelmirza/4110440/304090
#EXTINF:-1 tvg-id="" tvg-name="AL: KS Filma24 Animacion" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: KS Filma24 Animacion
http://ip96.uk:8080/shakeelmirza/4110440/304091
#EXTINF:-1 tvg-id="" tvg-name="AL: KS Filma24 Aventure" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: KS Filma24 Aventure
http://ip96.uk:8080/shakeelmirza/4110440/304092
#EXTINF:-1 tvg-id="" tvg-name="AL: KS Filma24 Aziatika" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: KS Filma24 Aziatika
http://ip96.uk:8080/shakeelmirza/4110440/304093
#EXTINF:-1 tvg-id="" tvg-name="AL: KS Filma24 Biografi" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: KS Filma24 Biografi
http://ip96.uk:8080/shakeelmirza/4110440/304094
#EXTINF:-1 tvg-id="" tvg-name="AL: KS Filma24 Drame" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: KS Filma24 Drame
http://ip96.uk:8080/shakeelmirza/4110440/304095
#EXTINF:-1 tvg-id="" tvg-name="AL: KS Filma24 Family" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: KS Filma24 Family
http://ip96.uk:8080/shakeelmirza/4110440/304096
#EXTINF:-1 tvg-id="" tvg-name="AL: KS Filma24 Horror" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: KS Filma24 Horror
http://ip96.uk:8080/shakeelmirza/4110440/304097
#EXTINF:-1 tvg-id="" tvg-name="AL: KS Filma24 Krim" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: KS Filma24 Krim
http://ip96.uk:8080/shakeelmirza/4110440/304098
#EXTINF:-1 tvg-id="" tvg-name="AL: KS Filma24 Mister" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: KS Filma24 Mister
http://ip96.uk:8080/shakeelmirza/4110440/304099
#EXTINF:-1 tvg-id="" tvg-name="AL: KS Filma24 Oscars" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: KS Filma24 Oscars
http://ip96.uk:8080/shakeelmirza/4110440/304100
#EXTINF:-1 tvg-id="" tvg-name="AL: KS Filma24 Premiere" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: KS Filma24 Premiere
http://ip96.uk:8080/shakeelmirza/4110440/304101
#EXTINF:-1 tvg-id="" tvg-name="AL: KS Filma24 Romance" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: KS Filma24 Romance
http://ip96.uk:8080/shakeelmirza/4110440/304102
#EXTINF:-1 tvg-id="" tvg-name="AL: KS Filma24 SCI-Fi" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: KS Filma24 SCI-Fi
http://ip96.uk:8080/shakeelmirza/4110440/304103
#EXTINF:-1 tvg-id="" tvg-name="AL: KS Filma24 Triller" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: KS Filma24 Triller
http://ip96.uk:8080/shakeelmirza/4110440/304104
#EXTINF:-1 tvg-id="" tvg-name="AL: RTSH Film" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-07/f0a071a1e164071dfea41777e3ef6781.svg" group-title="Albania ➾ Movie",AL: RTSH Film
http://ip96.uk:8080/shakeelmirza/4110440/304105
#EXTINF:-1 tvg-id="" tvg-name="AL: RTSH Shqip" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-07/6988c74f94ed84d769b514ee22b72256.svg" group-title="Albania ➾ Movie",AL: RTSH Shqip
http://ip96.uk:8080/shakeelmirza/4110440/304106
#EXTINF:-1 tvg-id="" tvg-name="AL: Tring 3 Plus" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/334e9b6f9375aa39e5883948275850d6.jpg" group-title="Albania ➾ Movie",AL: Tring 3 Plus
http://ip96.uk:8080/shakeelmirza/4110440/304107
#EXTINF:-1 tvg-id="" tvg-name="AL: Tring Action" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/9e6071e3273a53b9e66dfc99f89fa264.png" group-title="Albania ➾ Movie",AL: Tring Action
http://ip96.uk:8080/shakeelmirza/4110440/304108
#EXTINF:-1 tvg-id="" tvg-name="AL: Tring Classic" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-01/cd697f7f4114b005023485a924cc1951.png" group-title="Albania ➾ Movie",AL: Tring Classic
http://ip96.uk:8080/shakeelmirza/4110440/304109
#EXTINF:-1 tvg-id="" tvg-name="AL: Tring Collection" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-06/4508378dbfe05e72dbbfc56a83d6711f.png" group-title="Albania ➾ Movie",AL: Tring Collection
http://ip96.uk:8080/shakeelmirza/4110440/304110
#EXTINF:-1 tvg-id="" tvg-name="AL: Tring Comedy" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/15f347a715450c9fd7bdad3f88c2095c.png" group-title="Albania ➾ Movie",AL: Tring Comedy
http://ip96.uk:8080/shakeelmirza/4110440/304111
#EXTINF:-1 tvg-id="" tvg-name="AL: Tring Family" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-09/124db68b51c5e8d199b5080693ab9023.png" group-title="Albania ➾ Movie",AL: Tring Family
http://ip96.uk:8080/shakeelmirza/4110440/304112
#EXTINF:-1 tvg-id="" tvg-name="AL: Tring Fantasy" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/ab00f2f37ac3229fd0848ac48d53b7b9.png" group-title="Albania ➾ Movie",AL: Tring Fantasy
http://ip96.uk:8080/shakeelmirza/4110440/304113
#EXTINF:-1 tvg-id="" tvg-name="AL: Tring Life" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/d00e09b01730e8508e41db3e72f2f04c.jpg" group-title="Albania ➾ Movie",AL: Tring Life
http://ip96.uk:8080/shakeelmirza/4110440/304114
#EXTINF:-1 tvg-id="" tvg-name="AL: Tring Novelas" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-06/9f55b689df0873edd74466b594bb58ee.png" group-title="Albania ➾ Movie",AL: Tring Novelas
http://ip96.uk:8080/shakeelmirza/4110440/304115
#EXTINF:-1 tvg-id="" tvg-name="AL: Tring Original" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="Albania ➾ Movie",AL: Tring Original
http://ip96.uk:8080/shakeelmirza/4110440/304116
#EXTINF:-1 tvg-id="" tvg-name="AL: Tring Series" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2023-06/4311bd0bde74920c88cec0af2da386c4.png" group-title="Albania ➾ Movie",AL: Tring Series
http://ip96.uk:8080/shakeelmirza/4110440/304117
#EXTINF:-1 tvg-id="" tvg-name="AL: Tring Shqip" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/169f8a4c444563e3c490d92a886cb487.png" group-title="Albania ➾ Movie",AL: Tring Shqip
http://ip96.uk:8080/shakeelmirza/4110440/304118
#EXTINF:-1 tvg-id="" tvg-name="AL: Tring Smile" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/9cde1e4e258b128a544f7f7c3a8a5b37.png" group-title="Albania ➾ Movie",AL: Tring Smile
http://ip96.uk:8080/shakeelmirza/4110440/304119
#EXTINF:-1 tvg-id="" tvg-name="AL: Tring Super" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/841e40fc4581a7d0668fa892ee975757.png" group-title="Albania ➾ Movie",AL: Tring Super
http://ip96.uk:8080/shakeelmirza/4110440/304120
#EXTINF:-1 tvg-id="" tvg-name="AL: Tring Turkish Stories" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2024-01/24da71afb30b0a51f33218126d49a770.png" group-title="Albania ➾ Movie",AL: Tring Turkish Stories
http://ip96.uk:8080/shakeelmirza/4110440/304121
#EXTINF:-1 tvg-id="" tvg-name="AL: Zjarr TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/72835de4dabb3cfe6d8543b3c818fbb3.png" group-title="Albania ➾ Movie",AL: Zjarr TV
http://ip96.uk:8080/shakeelmirza/4110440/304122
#EXTINF:-1 tvg-id="" tvg-name="AL: Discovery Science" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/a7d06d7d3e50a7d0083022428489eef0.png" group-title="Albania ➾ Documentary",AL: Discovery Science
http://ip96.uk:8080/shakeelmirza/4110440/304123
#EXTINF:-1 tvg-id="" tvg-name="AL: DocuBox" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-01/896b4847e09ffae7e2d4ab67bdabd118.png" group-title="Albania ➾ Documentary",AL: DocuBox
http://ip96.uk:8080/shakeelmirza/4110440/304124
#EXTINF:-1 tvg-id="" tvg-name="AL: Explorer Histori" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/f9e77d5547d8e675d2793fd8b2f99747.png" group-title="Albania ➾ Documentary",AL: Explorer Histori
http://ip96.uk:8080/shakeelmirza/4110440/304125
#EXTINF:-1 tvg-id="" tvg-name="AL: Explorer Natyra" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/4aec94ce4233b555af20339d1a9fb49d.png" group-title="Albania ➾ Documentary",AL: Explorer Natyra
http://ip96.uk:8080/shakeelmirza/4110440/304126
#EXTINF:-1 tvg-id="" tvg-name="AL: Investigation Discovery" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-01/add91d2361cd07c4f8a8a6a59afe6298.png" group-title="Albania ➾ Documentary",AL: Investigation Discovery
http://ip96.uk:8080/shakeelmirza/4110440/304127
#EXTINF:-1 tvg-id="" tvg-name="AL: NAT GEO" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/a03f99967979ee5b44560a41b66fd0ee.png" group-title="Albania ➾ Documentary",AL: NAT GEO
http://ip96.uk:8080/shakeelmirza/4110440/304128
#EXTINF:-1 tvg-id="" tvg-name="AL: Travel Channel" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-02/fa40a5f67e2c05623cd5e49d24ae2b17.png" group-title="Albania ➾ Documentary",AL: Travel Channel
http://ip96.uk:8080/shakeelmirza/4110440/304129
#EXTINF:-1 tvg-id="" tvg-name="AL: Tring History" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2020-07/a81d374e125c00c3bedd06afe18904fd.png" group-title="Albania ➾ Documentary",AL: Tring History
http://ip96.uk:8080/shakeelmirza/4110440/304130
#EXTINF:-1 tvg-id="" tvg-name="AL: Tring World" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/34c55c1b943922779da04d17f001fa41.png" group-title="Albania ➾ Documentary",AL: Tring World
http://ip96.uk:8080/shakeelmirza/4110440/304131
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ¹" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ¹
http://ip96.uk:8080/shakeelmirza/4110440/457014
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ²" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ²
http://ip96.uk:8080/shakeelmirza/4110440/457015
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ³" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ³
http://ip96.uk:8080/shakeelmirza/4110440/457016
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ⁴" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ⁴
http://ip96.uk:8080/shakeelmirza/4110440/457017
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ⁵" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ⁵
http://ip96.uk:8080/shakeelmirza/4110440/457018
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ⁶" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ⁶
http://ip96.uk:8080/shakeelmirza/4110440/457019
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ⁷" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ⁷
http://ip96.uk:8080/shakeelmirza/4110440/457020
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ⁸" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ⁸
http://ip96.uk:8080/shakeelmirza/4110440/457021
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ⁹" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ⁹
http://ip96.uk:8080/shakeelmirza/4110440/457022
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ¹⁰" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ¹⁰
http://ip96.uk:8080/shakeelmirza/4110440/457023
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ¹¹" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ¹¹
http://ip96.uk:8080/shakeelmirza/4110440/457024
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ¹²" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ¹²
http://ip96.uk:8080/shakeelmirza/4110440/457025
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ¹³" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ¹³
http://ip96.uk:8080/shakeelmirza/4110440/457026
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ¹⁴" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ¹⁴
http://ip96.uk:8080/shakeelmirza/4110440/457027
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ¹⁵" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ¹⁵
http://ip96.uk:8080/shakeelmirza/4110440/457028
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ¹⁶" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ¹⁶
http://ip96.uk:8080/shakeelmirza/4110440/457029
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ¹⁷" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ¹⁷
http://ip96.uk:8080/shakeelmirza/4110440/457030
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ¹⁸" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ¹⁸
http://ip96.uk:8080/shakeelmirza/4110440/457031
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ¹⁹" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ¹⁹
http://ip96.uk:8080/shakeelmirza/4110440/457032
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ²⁰" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ²⁰
http://ip96.uk:8080/shakeelmirza/4110440/457033
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ²¹" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ²¹
http://ip96.uk:8080/shakeelmirza/4110440/457034
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ²²" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ²²
http://ip96.uk:8080/shakeelmirza/4110440/477537
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ²³" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ²³
http://ip96.uk:8080/shakeelmirza/4110440/477545
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ²⁴" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ²⁴
http://ip96.uk:8080/shakeelmirza/4110440/477546
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ²⁵" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ²⁵
http://ip96.uk:8080/shakeelmirza/4110440/477550
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ²⁶" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ²⁶
http://ip96.uk:8080/shakeelmirza/4110440/477553
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ²⁷" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ²⁷
http://ip96.uk:8080/shakeelmirza/4110440/477559
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ²⁸" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ²⁸
http://ip96.uk:8080/shakeelmirza/4110440/477560
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ²⁹" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ²⁹
http://ip96.uk:8080/shakeelmirza/4110440/477561
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ³⁰" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ³⁰
http://ip96.uk:8080/shakeelmirza/4110440/477562
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ³¹" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ³¹
http://ip96.uk:8080/shakeelmirza/4110440/477736
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ³²" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ³²
http://ip96.uk:8080/shakeelmirza/4110440/477737
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ³³" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ³³
http://ip96.uk:8080/shakeelmirza/4110440/477738
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ³⁴" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ³⁴
http://ip96.uk:8080/shakeelmirza/4110440/477739
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ³⁵" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ³⁵
http://ip96.uk:8080/shakeelmirza/4110440/477740
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ³⁶" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ³⁶
http://ip96.uk:8080/shakeelmirza/4110440/477741
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ³⁷" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ³⁷
http://ip96.uk:8080/shakeelmirza/4110440/477742
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ³⁸" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ³⁸
http://ip96.uk:8080/shakeelmirza/4110440/477743
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ³⁹" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ³⁹
http://ip96.uk:8080/shakeelmirza/4110440/477744
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ⁴⁰" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ⁴⁰
http://ip96.uk:8080/shakeelmirza/4110440/477745
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ⁴¹" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ⁴¹
http://ip96.uk:8080/shakeelmirza/4110440/477748
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ⁴²" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ⁴²
http://ip96.uk:8080/shakeelmirza/4110440/477749
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ⁴³" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ⁴³
http://ip96.uk:8080/shakeelmirza/4110440/477750
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ⁴⁴" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ⁴⁴
http://ip96.uk:8080/shakeelmirza/4110440/477751
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ⁴⁵" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ⁴⁵
http://ip96.uk:8080/shakeelmirza/4110440/477752
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ⁴⁶" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ⁴⁶
http://ip96.uk:8080/shakeelmirza/4110440/477753
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ⁴⁷" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ⁴⁷
http://ip96.uk:8080/shakeelmirza/4110440/477754
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ⁴⁸" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ⁴⁸
http://ip96.uk:8080/shakeelmirza/4110440/477755
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ⁴⁹" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ⁴⁹
http://ip96.uk:8080/shakeelmirza/4110440/477756
#EXTINF:-1 tvg-id="" tvg-name="JP : XXX ⁵⁰" tvg-logo="" group-title="JP : ADULT XXX",JP : XXX ⁵⁰
http://ip96.uk:8080/shakeelmirza/4110440/477757
#EXTINF:-1 tvg-id="" tvg-name="HINDI ADULT (1) 24/7" tvg-logo="" group-title="HINDI ADULT XX",HINDI ADULT (1) 24/7
http://ip96.uk:8080/shakeelmirza/4110440/499584
#EXTINF:-1 tvg-id="" tvg-name="HINDI ADULT (2) 24/7" tvg-logo="" group-title="HINDI ADULT XX",HINDI ADULT (2) 24/7
http://ip96.uk:8080/shakeelmirza/4110440/499585
#EXTINF:-1 tvg-id="" tvg-name="XXM: 21 Sextury" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: 21 Sextury
http://ip96.uk:8080/shakeelmirza/4110440/291729
#EXTINF:-1 tvg-id="" tvg-name="XXM: 4K EVILANGEL CUM4K" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: 4K EVILANGEL CUM4K
http://ip96.uk:8080/shakeelmirza/4110440/291730
#EXTINF:-1 tvg-id="" tvg-name="XXM: ANAL TIME" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: ANAL TIME
http://ip96.uk:8080/shakeelmirza/4110440/291731
#EXTINF:-1 tvg-id="" tvg-name="XXM: ANAL4K" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: ANAL4K
http://ip96.uk:8080/shakeelmirza/4110440/291732
#EXTINF:-1 tvg-id="" tvg-name="XXM: ANALMOM" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: ANALMOM
http://ip96.uk:8080/shakeelmirza/4110440/291733
#EXTINF:-1 tvg-id="" tvg-name="XXM: ANALONLY" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: ANALONLY
http://ip96.uk:8080/shakeelmirza/4110440/291734
#EXTINF:-1 tvg-id="" tvg-name="XXM: Asian Porn" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: Asian Porn
http://ip96.uk:8080/shakeelmirza/4110440/291735
#EXTINF:-1 tvg-id="" tvg-name="XXM: BANG BROS +1" tvg-logo="" group-title="ADULTS+18",XXM: BANG BROS +1
http://ip96.uk:8080/shakeelmirza/4110440/291736
#EXTINF:-1 tvg-id="" tvg-name="XXM: BANG BROS +2" tvg-logo="" group-title="ADULTS+18",XXM: BANG BROS +2
http://ip96.uk:8080/shakeelmirza/4110440/291737
#EXTINF:-1 tvg-id="" tvg-name="XXM: BANG BROS +3" tvg-logo="" group-title="ADULTS+18",XXM: BANG BROS +3
http://ip96.uk:8080/shakeelmirza/4110440/291738
#EXTINF:-1 tvg-id="" tvg-name="XXM: BANG BROS 4K" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: BANG BROS 4K
http://ip96.uk:8080/shakeelmirza/4110440/291739
#EXTINF:-1 tvg-id="" tvg-name="XXM: Black White Porn 1" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: Black White Porn 1
http://ip96.uk:8080/shakeelmirza/4110440/291740
#EXTINF:-1 tvg-id="" tvg-name="XXM: Black White Porn 2" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: Black White Porn 2
http://ip96.uk:8080/shakeelmirza/4110440/291741
#EXTINF:-1 tvg-id="" tvg-name="XXM: BLACKED" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: BLACKED
http://ip96.uk:8080/shakeelmirza/4110440/291742
#EXTINF:-1 tvg-id="" tvg-name="XXM: Bratty Sis" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: Bratty Sis
http://ip96.uk:8080/shakeelmirza/4110440/291743
#EXTINF:-1 tvg-id="" tvg-name="XXM: Bratty Sis +1" tvg-logo="" group-title="ADULTS+18",XXM: Bratty Sis +1
http://ip96.uk:8080/shakeelmirza/4110440/291744
#EXTINF:-1 tvg-id="" tvg-name="XXM: BRAZZERS" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: BRAZZERS
http://ip96.uk:8080/shakeelmirza/4110440/291745
#EXTINF:-1 tvg-id="" tvg-name="XXM: BRAZZERS +1" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: BRAZZERS +1
http://ip96.uk:8080/shakeelmirza/4110440/291746
#EXTINF:-1 tvg-id="" tvg-name="XXM: BRAZZERS +2" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: BRAZZERS +2
http://ip96.uk:8080/shakeelmirza/4110440/291747
#EXTINF:-1 tvg-id="" tvg-name="XXM: BRAZZERS +3" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: BRAZZERS +3
http://ip96.uk:8080/shakeelmirza/4110440/291748
#EXTINF:-1 tvg-id="" tvg-name="XXM: BRAZZERS en ESPANOL.COM" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: BRAZZERS en ESPANOL.COM
http://ip96.uk:8080/shakeelmirza/4110440/291749
#EXTINF:-1 tvg-id="" tvg-name="XXM: BumsBus" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: BumsBus
http://ip96.uk:8080/shakeelmirza/4110440/291750
#EXTINF:-1 tvg-id="" tvg-name="XXM: CUM 4K" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: CUM 4K
http://ip96.uk:8080/shakeelmirza/4110440/291751
#EXTINF:-1 tvg-id="" tvg-name="XXM: Czech Gang Bang" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: Czech Gang Bang
http://ip96.uk:8080/shakeelmirza/4110440/291752
#EXTINF:-1 tvg-id="" tvg-name="XXM: DAUGHTER SWAP" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: DAUGHTER SWAP
http://ip96.uk:8080/shakeelmirza/4110440/291753
#EXTINF:-1 tvg-id="" tvg-name="XXM: DORCEL CLUB" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: DORCEL CLUB
http://ip96.uk:8080/shakeelmirza/4110440/291754
#EXTINF:-1 tvg-id="" tvg-name="XXM: EVIL ANGEL +1" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: EVIL ANGEL +1
http://ip96.uk:8080/shakeelmirza/4110440/291755
#EXTINF:-1 tvg-id="" tvg-name="XXM: EVIL ANGEL +2" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: EVIL ANGEL +2
http://ip96.uk:8080/shakeelmirza/4110440/291756
#EXTINF:-1 tvg-id="" tvg-name="XXM: EVIL ANGEL +4" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: EVIL ANGEL +4
http://ip96.uk:8080/shakeelmirza/4110440/291757
#EXTINF:-1 tvg-id="" tvg-name="XXM: EVIL ANGEL +49" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: EVIL ANGEL +49
http://ip96.uk:8080/shakeelmirza/4110440/291758
#EXTINF:-1 tvg-id="" tvg-name="XXM: EVIL ANGEL +5" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: EVIL ANGEL +5
http://ip96.uk:8080/shakeelmirza/4110440/291759
#EXTINF:-1 tvg-id="" tvg-name="XXM: EVIL ANGEL +7" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: EVIL ANGEL +7
http://ip96.uk:8080/shakeelmirza/4110440/291760
#EXTINF:-1 tvg-id="" tvg-name="XXM: EXCLUSIVE AUTUMN FALLS" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: EXCLUSIVE AUTUMN FALLS
http://ip96.uk:8080/shakeelmirza/4110440/291761
#EXTINF:-1 tvg-id="" tvg-name="XXM: FAKE TAXI" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: FAKE TAXI
http://ip96.uk:8080/shakeelmirza/4110440/291762
#EXTINF:-1 tvg-id="" tvg-name="XXM: Family Strokes" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: Family Strokes
http://ip96.uk:8080/shakeelmirza/4110440/291763
#EXTINF:-1 tvg-id="" tvg-name="XXM: French Lover" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: French Lover
http://ip96.uk:8080/shakeelmirza/4110440/291764
#EXTINF:-1 tvg-id="" tvg-name="XXM: Hard X" tvg-logo="" group-title="ADULTS+18",XXM: Hard X
http://ip96.uk:8080/shakeelmirza/4110440/291765
#EXTINF:-1 tvg-id="" tvg-name="XXM: Holly Randall" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: Holly Randall
http://ip96.uk:8080/shakeelmirza/4110440/291766
#EXTINF:-1 tvg-id="" tvg-name="XXM: HOT KINKY JO" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: HOT KINKY JO
http://ip96.uk:8080/shakeelmirza/4110440/291767
#EXTINF:-1 tvg-id="" tvg-name="XXM: Japan HDV" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: Japan HDV
http://ip96.uk:8080/shakeelmirza/4110440/291768
#EXTINF:-1 tvg-id="" tvg-name="XXM: JASMIN.TV" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: JASMIN.TV
http://ip96.uk:8080/shakeelmirza/4110440/291769
#EXTINF:-1 tvg-id="" tvg-name="XXM: MiaKhalifa" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: MiaKhalifa
http://ip96.uk:8080/shakeelmirza/4110440/291770
#EXTINF:-1 tvg-id="" tvg-name="XXM: MOFOS" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: MOFOS
http://ip96.uk:8080/shakeelmirza/4110440/291771
#EXTINF:-1 tvg-id="" tvg-name="XXM: MY PERVY FAMILY" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: MY PERVY FAMILY
http://ip96.uk:8080/shakeelmirza/4110440/291772
#EXTINF:-1 tvg-id="" tvg-name="XXM: NAUGHTY CAT" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: NAUGHTY CAT
http://ip96.uk:8080/shakeelmirza/4110440/291773
#EXTINF:-1 tvg-id="" tvg-name="XXM: NETIP Asian Porn" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: NETIP Asian Porn
http://ip96.uk:8080/shakeelmirza/4110440/291774
#EXTINF:-1 tvg-id="" tvg-name="XXM: Nubiles TV" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: Nubiles TV
http://ip96.uk:8080/shakeelmirza/4110440/291775
#EXTINF:-1 tvg-id="" tvg-name="XXM: PENTHOUSE" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/44766506a37f3b088907703a0da4b7a8.png" group-title="ADULTS+18",XXM: PENTHOUSE
http://ip96.uk:8080/shakeelmirza/4110440/291776
#EXTINF:-1 tvg-id="" tvg-name="XXM: PERV CITY" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: PERV CITY
http://ip96.uk:8080/shakeelmirza/4110440/291777
#EXTINF:-1 tvg-id="" tvg-name="XXM: PornHub Por DORCEL CLUB" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: PornHub Por DORCEL CLUB
http://ip96.uk:8080/shakeelmirza/4110440/291944
#EXTINF:-1 tvg-id="" tvg-name="XXM: PornHub PRIVATE" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: PornHub PRIVATE
http://ip96.uk:8080/shakeelmirza/4110440/291945
#EXTINF:-1 tvg-id="" tvg-name="XXM: Primafila Hotclub 1" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: Primafila Hotclub 1
http://ip96.uk:8080/shakeelmirza/4110440/291946
#EXTINF:-1 tvg-id="" tvg-name="XXM: Primafila Hotclub 2" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: Primafila Hotclub 2
http://ip96.uk:8080/shakeelmirza/4110440/291947
#EXTINF:-1 tvg-id="" tvg-name="XXM: Primafila Hotclub 3" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: Primafila Hotclub 3
http://ip96.uk:8080/shakeelmirza/4110440/291948
#EXTINF:-1 tvg-id="" tvg-name="XXM: Primafila Hotclub 4" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: Primafila Hotclub 4
http://ip96.uk:8080/shakeelmirza/4110440/291949
#EXTINF:-1 tvg-id="" tvg-name="XXM: Primafila Hotclub 5" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: Primafila Hotclub 5
http://ip96.uk:8080/shakeelmirza/4110440/291950
#EXTINF:-1 tvg-id="" tvg-name="XXM: Primafila Hotclub 6" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: Primafila Hotclub 6
http://ip96.uk:8080/shakeelmirza/4110440/291951
#EXTINF:-1 tvg-id="" tvg-name="XXM: Primafila Hotclub 7" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: Primafila Hotclub 7
http://ip96.uk:8080/shakeelmirza/4110440/291952
#EXTINF:-1 tvg-id="" tvg-name="XXM: Primafila Hotclub 8" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: Primafila Hotclub 8
http://ip96.uk:8080/shakeelmirza/4110440/291953
#EXTINF:-1 tvg-id="" tvg-name="XXM: Private Spice" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: Private Spice
http://ip96.uk:8080/shakeelmirza/4110440/291954
#EXTINF:-1 tvg-id="" tvg-name="XXM: PRONBOX EXCLUSIVE MADISON IVY" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: PRONBOX EXCLUSIVE MADISON IVY
http://ip96.uk:8080/shakeelmirza/4110440/291955
#EXTINF:-1 tvg-id="" tvg-name="XXM: PUBLIC AGENT" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: PUBLIC AGENT
http://ip96.uk:8080/shakeelmirza/4110440/291956
#EXTINF:-1 tvg-id="" tvg-name="XXM: PURE TABOO" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: PURE TABOO
http://ip96.uk:8080/shakeelmirza/4110440/291957
#EXTINF:-1 tvg-id="" tvg-name="XXM: PutaLocura" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: PutaLocura
http://ip96.uk:8080/shakeelmirza/4110440/291958
#EXTINF:-1 tvg-id="" tvg-name="XXM: SEX WITH MUSLIMS" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: SEX WITH MUSLIMS
http://ip96.uk:8080/shakeelmirza/4110440/291996
#EXTINF:-1 tvg-id="" tvg-name="XXM: STARS EXCLUSIVE ADRIANA CHECHIK" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: STARS EXCLUSIVE ADRIANA CHECHIK
http://ip96.uk:8080/shakeelmirza/4110440/291997
#EXTINF:-1 tvg-id="" tvg-name="XXM: STARS EXCLUSIVE EVA LOVIA" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: STARS EXCLUSIVE EVA LOVIA
http://ip96.uk:8080/shakeelmirza/4110440/291998
#EXTINF:-1 tvg-id="" tvg-name="XXM: TRUE ANAL" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: TRUE ANAL
http://ip96.uk:8080/shakeelmirza/4110440/291999
#EXTINF:-1 tvg-id="" tvg-name="XXM: TRUE ANAL +1" tvg-logo="" group-title="ADULTS+18",XXM: TRUE ANAL +1
http://ip96.uk:8080/shakeelmirza/4110440/292000
#EXTINF:-1 tvg-id="" tvg-name="XXM: TUSHY" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: TUSHY
http://ip96.uk:8080/shakeelmirza/4110440/292001
#EXTINF:-1 tvg-id="" tvg-name="XXM: Vera DEEPER" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: Vera DEEPER
http://ip96.uk:8080/shakeelmirza/4110440/292002
#EXTINF:-1 tvg-id="" tvg-name="XXM: VERIFIED AMATEURS NYNA FERRAGNI" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: VERIFIED AMATEURS NYNA FERRAGNI
http://ip96.uk:8080/shakeelmirza/4110440/292003
#EXTINF:-1 tvg-id="" tvg-name="XXM: VERIFIED AMATEURS PURPLE BITCH" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: VERIFIED AMATEURS PURPLE BITCH
http://ip96.uk:8080/shakeelmirza/4110440/292004
#EXTINF:-1 tvg-id="" tvg-name="XXM: VERIFIED AMATEURS REISLIN" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: VERIFIED AMATEURS REISLIN
http://ip96.uk:8080/shakeelmirza/4110440/292005
#EXTINF:-1 tvg-id="" tvg-name="XXM: VERIFIED AMATEURS SHAIDEN ROUGE" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: VERIFIED AMATEURS SHAIDEN ROUGE
http://ip96.uk:8080/shakeelmirza/4110440/292006
#EXTINF:-1 tvg-id="" tvg-name="XXM: VIP Asian" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: VIP Asian
http://ip96.uk:8080/shakeelmirza/4110440/292007
#EXTINF:-1 tvg-id="" tvg-name="XXM: VIP Japanese" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: VIP Japanese
http://ip96.uk:8080/shakeelmirza/4110440/292008
#EXTINF:-1 tvg-id="" tvg-name="XXM: VIP SOLO" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="ADULTS+18",XXM: VIP SOLO
http://ip96.uk:8080/shakeelmirza/4110440/292009
#EXTINF:-1 tvg-id="" tvg-name="XXX: Alba XXX HD1" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Alba XXX HD1
http://ip96.uk:8080/shakeelmirza/4110440/292010
#EXTINF:-1 tvg-id="" tvg-name="XXX: Alba XXX HD1 +1" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Alba XXX HD1 +1
http://ip96.uk:8080/shakeelmirza/4110440/292011
#EXTINF:-1 tvg-id="" tvg-name="XXX: Alba XXX HD2" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Alba XXX HD2
http://ip96.uk:8080/shakeelmirza/4110440/292012
#EXTINF:-1 tvg-id="" tvg-name="XXX: Alba XXX HD2 +1" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Alba XXX HD2 +1
http://ip96.uk:8080/shakeelmirza/4110440/292013
#EXTINF:-1 tvg-id="" tvg-name="XXX: Alba XXX HD2 +2" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Alba XXX HD2 +2
http://ip96.uk:8080/shakeelmirza/4110440/292014
#EXTINF:-1 tvg-id="" tvg-name="XXX: Alba XXX HD3" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Alba XXX HD3
http://ip96.uk:8080/shakeelmirza/4110440/292015
#EXTINF:-1 tvg-id="" tvg-name="XXX: Alba XXX HD4" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Alba XXX HD4
http://ip96.uk:8080/shakeelmirza/4110440/292016
#EXTINF:-1 tvg-id="" tvg-name="XXX: Alba XXX HD5" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Alba XXX HD5
http://ip96.uk:8080/shakeelmirza/4110440/292017
#EXTINF:-1 tvg-id="" tvg-name="XXX: Alba XXX HD6" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Alba XXX HD6
http://ip96.uk:8080/shakeelmirza/4110440/292018
#EXTINF:-1 tvg-id="" tvg-name="XXX: Alba XXX HD7" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Alba XXX HD7
http://ip96.uk:8080/shakeelmirza/4110440/292019
#EXTINF:-1 tvg-id="" tvg-name="XXX: Alba XXX HD8" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Alba XXX HD8
http://ip96.uk:8080/shakeelmirza/4110440/292020
#EXTINF:-1 tvg-id="" tvg-name="XXX: ANALIZED" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: ANALIZED
http://ip96.uk:8080/shakeelmirza/4110440/292021
#EXTINF:-1 tvg-id="" tvg-name="XXX: ATK EXOTICS" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: ATK EXOTICS
http://ip96.uk:8080/shakeelmirza/4110440/292022
#EXTINF:-1 tvg-id="" tvg-name="XXX: ATK Galleria" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: ATK Galleria
http://ip96.uk:8080/shakeelmirza/4110440/292023
#EXTINF:-1 tvg-id="" tvg-name="XXX: ATK Hairy" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: ATK Hairy
http://ip96.uk:8080/shakeelmirza/4110440/292024
#EXTINF:-1 tvg-id="" tvg-name="XXX: babes" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: babes
http://ip96.uk:8080/shakeelmirza/4110440/292025
#EXTINF:-1 tvg-id="" tvg-name="XXX: BALKAN EROTIC" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: BALKAN EROTIC
http://ip96.uk:8080/shakeelmirza/4110440/292026
#EXTINF:-1 tvg-id="" tvg-name="XXX: BANANA FEVER" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: BANANA FEVER
http://ip96.uk:8080/shakeelmirza/4110440/292027
#EXTINF:-1 tvg-id="" tvg-name="XXX: BANG U" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: BANG U
http://ip96.uk:8080/shakeelmirza/4110440/292028
#EXTINF:-1 tvg-id="" tvg-name="XXX: Bangerz" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Bangerz
http://ip96.uk:8080/shakeelmirza/4110440/292029
#EXTINF:-1 tvg-id="" tvg-name="XXX: BARELY LEGAL" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: BARELY LEGAL
http://ip96.uk:8080/shakeelmirza/4110440/292030
#EXTINF:-1 tvg-id="" tvg-name="XXX: BEATE UHSE" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: BEATE UHSE
http://ip96.uk:8080/shakeelmirza/4110440/292031
#EXTINF:-1 tvg-id="" tvg-name="XXX: Blue Hustler" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Blue Hustler
http://ip96.uk:8080/shakeelmirza/4110440/292032
#EXTINF:-1 tvg-id="" tvg-name="XXX: Blue Hustler +1" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Blue Hustler +1
http://ip96.uk:8080/shakeelmirza/4110440/292033
#EXTINF:-1 tvg-id="" tvg-name="XXX: BRAZZERS" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: BRAZZERS
http://ip96.uk:8080/shakeelmirza/4110440/292034
#EXTINF:-1 tvg-id="" tvg-name="XXX: BRAZZERS +1" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: BRAZZERS +1
http://ip96.uk:8080/shakeelmirza/4110440/292035
#EXTINF:-1 tvg-id="" tvg-name="XXX: BRAZZERS +2" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: BRAZZERS +2
http://ip96.uk:8080/shakeelmirza/4110440/292036
#EXTINF:-1 tvg-id="" tvg-name="XXX: BRAZZERS +4" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: BRAZZERS +4
http://ip96.uk:8080/shakeelmirza/4110440/292037
#EXTINF:-1 tvg-id="" tvg-name="XXX: BRAZZERS TV Europe" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: BRAZZERS TV Europe
http://ip96.uk:8080/shakeelmirza/4110440/292038
#EXTINF:-1 tvg-id="" tvg-name="XXX: BRAZZERZ +3" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: BRAZZERZ +3
http://ip96.uk:8080/shakeelmirza/4110440/292039
#EXTINF:-1 tvg-id="" tvg-name="XXX: Cento X Cento" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Cento X Cento
http://ip96.uk:8080/shakeelmirza/4110440/292040
#EXTINF:-1 tvg-id="" tvg-name="XXX: Cherry Pimps" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Cherry Pimps
http://ip96.uk:8080/shakeelmirza/4110440/292041
#EXTINF:-1 tvg-id="" tvg-name="XXX: CUM LOUDER" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: CUM LOUDER
http://ip96.uk:8080/shakeelmirza/4110440/292042
#EXTINF:-1 tvg-id="" tvg-name="XXX: danejones" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: danejones
http://ip96.uk:8080/shakeelmirza/4110440/292043
#EXTINF:-1 tvg-id="" tvg-name="XXX: Darling TV2" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Darling TV2
http://ip96.uk:8080/shakeelmirza/4110440/292044
#EXTINF:-1 tvg-id="" tvg-name="XXX: DDF Network" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: DDF Network
http://ip96.uk:8080/shakeelmirza/4110440/292045
#EXTINF:-1 tvg-id="" tvg-name="XXX: Desire" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Desire
http://ip96.uk:8080/shakeelmirza/4110440/292046
#EXTINF:-1 tvg-id="" tvg-name="XXX: DORCEL TV" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: DORCEL TV
http://ip96.uk:8080/shakeelmirza/4110440/292047
#EXTINF:-1 tvg-id="" tvg-name="XXX: DORCEL XXX" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: DORCEL XXX
http://ip96.uk:8080/shakeelmirza/4110440/292048
#EXTINF:-1 tvg-id="" tvg-name="XXX: DUSK" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/eca5ed8af4d5a989426f9763e793ba63.png" group-title="ADULTS+18",XXX: DUSK
http://ip96.uk:8080/shakeelmirza/4110440/292049
#EXTINF:-1 tvg-id="" tvg-name="XXX: Emanuelle" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Emanuelle
http://ip96.uk:8080/shakeelmirza/4110440/292050
#EXTINF:-1 tvg-id="" tvg-name="XXX: erotic" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/0cc88b5e1837a574d9afd4c0b5548666.png" group-title="ADULTS+18",XXX: erotic
http://ip96.uk:8080/shakeelmirza/4110440/292051
#EXTINF:-1 tvg-id="" tvg-name="XXX: erotic 2" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/e3ecf142562fb0dd76722e5a3f3af9f5.png" group-title="ADULTS+18",XXX: erotic 2
http://ip96.uk:8080/shakeelmirza/4110440/292052
#EXTINF:-1 tvg-id="" tvg-name="XXX: erotic 3" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/cb3e377994e967a278f87247ac8d4090.png" group-title="ADULTS+18",XXX: erotic 3
http://ip96.uk:8080/shakeelmirza/4110440/292053
#EXTINF:-1 tvg-id="" tvg-name="XXX: erotic 4" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/73b032b563fc35327ae7fe71903d64b3.png" group-title="ADULTS+18",XXX: erotic 4
http://ip96.uk:8080/shakeelmirza/4110440/292054
#EXTINF:-1 tvg-id="" tvg-name="XXX: erotic 5" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/d784f6c8cc3da5b4f5a70e3fc0754145.png" group-title="ADULTS+18",XXX: erotic 5
http://ip96.uk:8080/shakeelmirza/4110440/292055
#EXTINF:-1 tvg-id="" tvg-name="XXX: erotic 6" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/ad731974dee83ee4da6cadbfe518b414.png" group-title="ADULTS+18",XXX: erotic 6
http://ip96.uk:8080/shakeelmirza/4110440/292056
#EXTINF:-1 tvg-id="" tvg-name="XXX: erotic 7" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/00837055688d2ce5957bb86611dfcd43.png" group-title="ADULTS+18",XXX: erotic 7
http://ip96.uk:8080/shakeelmirza/4110440/292057
#EXTINF:-1 tvg-id="" tvg-name="XXX: erotic 8" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/60782fcb30648b1df7389d5351a3f0e5.png" group-title="ADULTS+18",XXX: erotic 8
http://ip96.uk:8080/shakeelmirza/4110440/292058
#EXTINF:-1 tvg-id="" tvg-name="XXX: Erotic Spice" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Erotic Spice
http://ip96.uk:8080/shakeelmirza/4110440/292059
#EXTINF:-1 tvg-id="" tvg-name="XXX: EROX" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/e72bd471b8065c856a5bce7de14fc471.png" group-title="ADULTS+18",XXX: EROX
http://ip96.uk:8080/shakeelmirza/4110440/292060
#EXTINF:-1 tvg-id="" tvg-name="XXX: EROXXX" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/3911eb41a72af8e58d98221401182480.png" group-title="ADULTS+18",XXX: EROXXX
http://ip96.uk:8080/shakeelmirza/4110440/292061
#EXTINF:-1 tvg-id="" tvg-name="XXX: EVIL ANGEL" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/69d3c688eed474f0dcfa9157d718e31d.png" group-title="ADULTS+18",XXX: EVIL ANGEL
http://ip96.uk:8080/shakeelmirza/4110440/292062
#EXTINF:-1 tvg-id="" tvg-name="XXX: EVIL ANGEL +1" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: EVIL ANGEL +1
http://ip96.uk:8080/shakeelmirza/4110440/292063
#EXTINF:-1 tvg-id="" tvg-name="XXX: EXPO EROX" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: EXPO EROX
http://ip96.uk:8080/shakeelmirza/4110440/292064
#EXTINF:-1 tvg-id="" tvg-name="XXX: EXTASY" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-01/8d7833a7af9700e7a01d8b3475f8ed9c.png" group-title="ADULTS+18",XXX: EXTASY
http://ip96.uk:8080/shakeelmirza/4110440/292065
#EXTINF:-1 tvg-id="" tvg-name="XXX: EXTREME" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: EXTREME
http://ip96.uk:8080/shakeelmirza/4110440/292066
#EXTINF:-1 tvg-id="" tvg-name="XXX: Exxxotica TV" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Exxxotica TV
http://ip96.uk:8080/shakeelmirza/4110440/292067
#EXTINF:-1 tvg-id="" tvg-name="XXX: Fantazzy TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-06/73a0c0934dab32d4122d9bb858302204.png" group-title="ADULTS+18",XXX: Fantazzy TV
http://ip96.uk:8080/shakeelmirza/4110440/292068
#EXTINF:-1 tvg-id="" tvg-name="XXX: GAY MEN" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: GAY MEN
http://ip96.uk:8080/shakeelmirza/4110440/292069
#EXTINF:-1 tvg-id="" tvg-name="XXX: GAY TV" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: GAY TV
http://ip96.uk:8080/shakeelmirza/4110440/292070
#EXTINF:-1 tvg-id="" tvg-name="XXX: HITZEFREI" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: HITZEFREI
http://ip96.uk:8080/shakeelmirza/4110440/292071
#EXTINF:-1 tvg-id="" tvg-name="XXX: Horny Hostel" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Horny Hostel
http://ip96.uk:8080/shakeelmirza/4110440/292072
#EXTINF:-1 tvg-id="" tvg-name="XXX: HOT" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/9393de8ffa8c943b09bec0d2371b7eeb.png" group-title="ADULTS+18",XXX: HOT
http://ip96.uk:8080/shakeelmirza/4110440/292073
#EXTINF:-1 tvg-id="" tvg-name="XXX: HOT 1+" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: HOT 1+
http://ip96.uk:8080/shakeelmirza/4110440/292074
#EXTINF:-1 tvg-id="" tvg-name="XXX: HOT Gold" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: HOT Gold
http://ip96.uk:8080/shakeelmirza/4110440/292075
#EXTINF:-1 tvg-id="" tvg-name="XXX: HOT GUYS FUCK" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: HOT GUYS FUCK
http://ip96.uk:8080/shakeelmirza/4110440/292076
#EXTINF:-1 tvg-id="" tvg-name="XXX: HOT GUYS FUCK +1" tvg-logo="" group-title="ADULTS+18",XXX: HOT GUYS FUCK +1
http://ip96.uk:8080/shakeelmirza/4110440/292077
#EXTINF:-1 tvg-id="" tvg-name="XXX: HOT Pleasure" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: HOT Pleasure
http://ip96.uk:8080/shakeelmirza/4110440/292078
#EXTINF:-1 tvg-id="" tvg-name="XXX: HOT XXL" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: HOT XXL
http://ip96.uk:8080/shakeelmirza/4110440/292079
#EXTINF:-1 tvg-id="" tvg-name="XXX: HUSTLER HD" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-08/1161b5609e8639fa7922c371e25c63c2.png" group-title="ADULTS+18",XXX: HUSTLER HD
http://ip96.uk:8080/shakeelmirza/4110440/292080
#EXTINF:-1 tvg-id="" tvg-name="XXX: Hustler TV RED" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-01/39f670616f23f6bfb21d6f0aed98de65.png" group-title="ADULTS+18",XXX: Hustler TV RED
http://ip96.uk:8080/shakeelmirza/4110440/292081
#EXTINF:-1 tvg-id="" tvg-name="XXX: IPPA" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: IPPA
http://ip96.uk:8080/shakeelmirza/4110440/292082
#EXTINF:-1 tvg-id="" tvg-name="XXX: IPPA +1" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: IPPA +1
http://ip96.uk:8080/shakeelmirza/4110440/292083
#EXTINF:-1 tvg-id="" tvg-name="XXX: LEO TV" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: LEO TV
http://ip96.uk:8080/shakeelmirza/4110440/292084
#EXTINF:-1 tvg-id="" tvg-name="XXX: LEO TV Gold" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: LEO TV Gold
http://ip96.uk:8080/shakeelmirza/4110440/292085
#EXTINF:-1 tvg-id="" tvg-name="XXX: Little Caprice" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Little Caprice
http://ip96.uk:8080/shakeelmirza/4110440/292086
#EXTINF:-1 tvg-id="" tvg-name="XXX: Meiden Van Holland" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Meiden Van Holland
http://ip96.uk:8080/shakeelmirza/4110440/292087
#EXTINF:-1 tvg-id="" tvg-name="XXX: MI Interracial" tvg-logo="" group-title="ADULTS+18",XXX: MI Interracial
http://ip96.uk:8080/shakeelmirza/4110440/292088
#EXTINF:-1 tvg-id="" tvg-name="XXX: Miami TV" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Miami TV
http://ip96.uk:8080/shakeelmirza/4110440/292089
#EXTINF:-1 tvg-id="" tvg-name="XXX: Miami TV Colombia" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Miami TV Colombia
http://ip96.uk:8080/shakeelmirza/4110440/292090
#EXTINF:-1 tvg-id="" tvg-name="XXX: Miami TV International" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Miami TV International
http://ip96.uk:8080/shakeelmirza/4110440/292091
#EXTINF:-1 tvg-id="" tvg-name="XXX: Miami TV Mexico" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Miami TV Mexico
http://ip96.uk:8080/shakeelmirza/4110440/292092
#EXTINF:-1 tvg-id="" tvg-name="XXX: MILF TV" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: MILF TV
http://ip96.uk:8080/shakeelmirza/4110440/292093
#EXTINF:-1 tvg-id="" tvg-name="XXX: MILFED" tvg-logo="" group-title="ADULTS+18",XXX: MILFED
http://ip96.uk:8080/shakeelmirza/4110440/292094
#EXTINF:-1 tvg-id="" tvg-name="XXX: MOFOS" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: MOFOS
http://ip96.uk:8080/shakeelmirza/4110440/292095
#EXTINF:-1 tvg-id="" tvg-name="XXX: MOM TEACH SEX" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: MOM TEACH SEX
http://ip96.uk:8080/shakeelmirza/4110440/292096
#EXTINF:-1 tvg-id="" tvg-name="XXX: NAKED NEWS" tvg-logo="" group-title="ADULTS+18",XXX: NAKED NEWS
http://ip96.uk:8080/shakeelmirza/4110440/292097
#EXTINF:-1 tvg-id="" tvg-name="XXX: NET XX" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: NET XX
http://ip96.uk:8080/shakeelmirza/4110440/292098
#EXTINF:-1 tvg-id="" tvg-name="XXX: NET XXL" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: NET XXL
http://ip96.uk:8080/shakeelmirza/4110440/292099
#EXTINF:-1 tvg-id="" tvg-name="XXX: NF Busty" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: NF Busty
http://ip96.uk:8080/shakeelmirza/4110440/292100
#EXTINF:-1 tvg-id="" tvg-name="XXX: Nubile Films" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Nubile Films
http://ip96.uk:8080/shakeelmirza/4110440/292101
#EXTINF:-1 tvg-id="" tvg-name="XXX: O.La.La" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/89cbca28208f364ef1b47c06315afd71.png" group-title="ADULTS+18",XXX: O.La.La
http://ip96.uk:8080/shakeelmirza/4110440/292102
#EXTINF:-1 tvg-id="" tvg-name="XXX: Passie XXX" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/f8712b8aa05c4d22e29838d4eefe9e03.png" group-title="ADULTS+18",XXX: Passie XXX
http://ip96.uk:8080/shakeelmirza/4110440/292103
#EXTINF:-1 tvg-id="" tvg-name="XXX: Passion XXX" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/db94ebdf2fe455251214a0f15a9ea99a.png" group-title="ADULTS+18",XXX: Passion XXX
http://ip96.uk:8080/shakeelmirza/4110440/292104
#EXTINF:-1 tvg-id="" tvg-name="XXX: Passion XXX +1" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-05/9f800e42bd55fb7fe94baeebcb69f7b0.png" group-title="ADULTS+18",XXX: Passion XXX +1
http://ip96.uk:8080/shakeelmirza/4110440/292105
#EXTINF:-1 tvg-id="" tvg-name="XXX: PENTHOUSE Gold" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/ae248ced9cd536ee1723ab55d0a3e7c2.png" group-title="ADULTS+18",XXX: PENTHOUSE Gold
http://ip96.uk:8080/shakeelmirza/4110440/292106
#EXTINF:-1 tvg-id="" tvg-name="XXX: PENTHOUSE Passion" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: PENTHOUSE Passion
http://ip96.uk:8080/shakeelmirza/4110440/292107
#EXTINF:-1 tvg-id="" tvg-name="XXX: PENTHOUSE REALITY TV" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: PENTHOUSE REALITY TV
http://ip96.uk:8080/shakeelmirza/4110440/292108
#EXTINF:-1 tvg-id="" tvg-name="XXX: Perv Mom" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Perv Mom
http://ip96.uk:8080/shakeelmirza/4110440/292109
#EXTINF:-1 tvg-id="" tvg-name="XXX: PINKO CLUB" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: PINKO CLUB
http://ip96.uk:8080/shakeelmirza/4110440/292110
#EXTINF:-1 tvg-id="" tvg-name="XXX: PLAYBOY" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/d6dd1f934c75182cb6ac60b311ad8183.png" group-title="ADULTS+18",XXX: PLAYBOY
http://ip96.uk:8080/shakeelmirza/4110440/292111
#EXTINF:-1 tvg-id="" tvg-name="XXX: PLAYBOY Brasil" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: PLAYBOY Brasil
http://ip96.uk:8080/shakeelmirza/4110440/292112
#EXTINF:-1 tvg-id="" tvg-name="XXX: PLAYBOY Latino" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: PLAYBOY Latino
http://ip96.uk:8080/shakeelmirza/4110440/292113
#EXTINF:-1 tvg-id="" tvg-name="XXX: PLAYBOY USA" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: PLAYBOY USA
http://ip96.uk:8080/shakeelmirza/4110440/292114
#EXTINF:-1 tvg-id="" tvg-name="XXX: PLAYHOUSE" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: PLAYHOUSE
http://ip96.uk:8080/shakeelmirza/4110440/292115
#EXTINF:-1 tvg-id="" tvg-name="XXX: Private TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-05/9150f35348b9d8da4226de2b9ce6c9b2.png" group-title="ADULTS+18",XXX: Private TV
http://ip96.uk:8080/shakeelmirza/4110440/292116
#EXTINF:-1 tvg-id="" tvg-name="XXX: Reality Kings TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/e1a65ebbea073d02a2e015181b94f4a3.png" group-title="ADULTS+18",XXX: Reality Kings TV
http://ip96.uk:8080/shakeelmirza/4110440/292117
#EXTINF:-1 tvg-id="" tvg-name="XXX: Reality Kings TV +1" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Reality Kings TV +1
http://ip96.uk:8080/shakeelmirza/4110440/292118
#EXTINF:-1 tvg-id="" tvg-name="XXX: RED LIPS" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: RED LIPS
http://ip96.uk:8080/shakeelmirza/4110440/292119
#EXTINF:-1 tvg-id="" tvg-name="XXX: REDLIGHT" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/8bf9a9c45c6293b91fc1f144f40e898e.png" group-title="ADULTS+18",XXX: REDLIGHT
http://ip96.uk:8080/shakeelmirza/4110440/292120
#EXTINF:-1 tvg-id="" tvg-name="XXX: Russkaya Noch" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2024-03/1559fdf457a6aa36a9cf1c0d17313547.png" group-title="ADULTS+18",XXX: Russkaya Noch
http://ip96.uk:8080/shakeelmirza/4110440/292121
#EXTINF:-1 tvg-id="" tvg-name="XXX: Secret Circle" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Secret Circle
http://ip96.uk:8080/shakeelmirza/4110440/292122
#EXTINF:-1 tvg-id="" tvg-name="XXX: Sexart" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Sexart
http://ip96.uk:8080/shakeelmirza/4110440/292123
#EXTINF:-1 tvg-id="" tvg-name="XXX: SeXation" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: SeXation
http://ip96.uk:8080/shakeelmirza/4110440/292124
#EXTINF:-1 tvg-id="" tvg-name="XXX: SEXTREME" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: SEXTREME
http://ip96.uk:8080/shakeelmirza/4110440/292125
#EXTINF:-1 tvg-id="" tvg-name="XXX: Sexy HOT" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Sexy HOT
http://ip96.uk:8080/shakeelmirza/4110440/292126
#EXTINF:-1 tvg-id="" tvg-name="XXX: SINEMATICA" tvg-logo="http://s3.i3ns.net/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: SINEMATICA
http://ip96.uk:8080/shakeelmirza/4110440/292127
#EXTINF:-1 tvg-id="" tvg-name="XXX: Sugar Street" tvg-logo="" group-title="ADULTS+18",XXX: Sugar Street
http://ip96.uk:8080/shakeelmirza/4110440/292128
#EXTINF:-1 tvg-id="" tvg-name="XXX: SuperOne" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: SuperOne
http://ip96.uk:8080/shakeelmirza/4110440/292129
#EXTINF:-1 tvg-id="" tvg-name="XXX: TRANS ANGELS" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: TRANS ANGELS
http://ip96.uk:8080/shakeelmirza/4110440/292130
#EXTINF:-1 tvg-id="" tvg-name="XXX: TRANS ANGELS PornBox" tvg-logo="" group-title="ADULTS+18",XXX: TRANS ANGELS PornBox
http://ip96.uk:8080/shakeelmirza/4110440/292131
#EXTINF:-1 tvg-id="" tvg-name="XXX: TRANS PICCANTE" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: TRANS PICCANTE
http://ip96.uk:8080/shakeelmirza/4110440/292132
#EXTINF:-1 tvg-id="" tvg-name="XXX: VENUS" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/b6d6e0bb58bd4e3c2b4874c609918a94.png" group-title="ADULTS+18",XXX: VENUS
http://ip96.uk:8080/shakeelmirza/4110440/292133
#EXTINF:-1 tvg-id="" tvg-name="XXX: VISIT-X TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/80ca765246e54cb9c7f6744b550ccd21.png" group-title="ADULTS+18",XXX: VISIT-X TV
http://ip96.uk:8080/shakeelmirza/4110440/292134
#EXTINF:-1 tvg-id="" tvg-name="XXX: VIVID Red" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: VIVID Red
http://ip96.uk:8080/shakeelmirza/4110440/292135
#EXTINF:-1 tvg-id="" tvg-name="XXX: VIVID Touch" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: VIVID Touch
http://ip96.uk:8080/shakeelmirza/4110440/292136
#EXTINF:-1 tvg-id="" tvg-name="XXX: VIVID TV" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/57f0394829c11df6816fc99acd551126.png" group-title="ADULTS+18",XXX: VIVID TV
http://ip96.uk:8080/shakeelmirza/4110440/292137
#EXTINF:-1 tvg-id="" tvg-name="XXX: VIXEN" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2022-01/5412f754d84f76d71e0af50dd73b23b1.png" group-title="ADULTS+18",XXX: VIXEN
http://ip96.uk:8080/shakeelmirza/4110440/292138
#EXTINF:-1 tvg-id="" tvg-name="XXX: WHITE BOXXX" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: WHITE BOXXX
http://ip96.uk:8080/shakeelmirza/4110440/292139
#EXTINF:-1 tvg-id="" tvg-name="XXX: X Bizarre" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: X Bizarre
http://ip96.uk:8080/shakeelmirza/4110440/292140
#EXTINF:-1 tvg-id="" tvg-name="XXX: X Bunga Bunga" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: X Bunga Bunga
http://ip96.uk:8080/shakeelmirza/4110440/292141
#EXTINF:-1 tvg-id="" tvg-name="XXX: XXL" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/fa06cef9ac1eb267ae04ff8d77250e85.png" group-title="ADULTS+18",XXX: XXL
http://ip96.uk:8080/shakeelmirza/4110440/292142
#EXTINF:-1 tvg-id="" tvg-name="XXX: XY Max" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/1e02585dc3ba3c59be105d4156fc0de3.png" group-title="ADULTS+18",XXX: XY Max
http://ip96.uk:8080/shakeelmirza/4110440/292143
#EXTINF:-1 tvg-id="" tvg-name="XXX: XY Mix" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: XY Mix
http://ip96.uk:8080/shakeelmirza/4110440/292144
#EXTINF:-1 tvg-id="" tvg-name="XXX: XY Plus" tvg-logo="http://s3.i3ns.net:2052/portal/picon/2021-07/14e860767c8196bb366ffddc6ad1ff80.png" group-title="ADULTS+18",XXX: XY Plus
http://ip96.uk:8080/shakeelmirza/4110440/292145
#EXTINF:-1 tvg-id="" tvg-name="XXX: Щёлк" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="ADULTS+18",XXX: Щёлк
http://ip96.uk:8080/shakeelmirza/4110440/292146
#EXTINF:-1 tvg-id="" tvg-name="XXM: PORNBOX 4K BAEB" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="GOLDEN+18",XXM: PORNBOX 4K BAEB
http://ip96.uk:8080/shakeelmirza/4110440/291778
#EXTINF:-1 tvg-id="" tvg-name="XXM: PORNBOX 4K TINY 4K" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="GOLDEN+18",XXM: PORNBOX 4K TINY 4K
http://ip96.uk:8080/shakeelmirza/4110440/291779
#EXTINF:-1 tvg-id="" tvg-name="XXM: Pornbox A girl Knows" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="GOLDEN+18",XXM: Pornbox A girl Knows
http://ip96.uk:8080/shakeelmirza/4110440/291780
#EXTINF:-1 tvg-id="" tvg-name="XXM: Pornbox Adult Time" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="GOLDEN+18",XXM: Pornbox Adult Time
http://ip96.uk:8080/shakeelmirza/4110440/291781
#EXTINF:-1 tvg-id="" tvg-name="XXM: PORNBOX ALICE REDLIPS" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="GOLDEN+18",XXM: PORNBOX ALICE REDLIPS
http://ip96.uk:8080/shakeelmirza/4110440/291782
#EXTINF:-1 tvg-id="" tvg-name="XXM: PORNBOX ALL BLACK X" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="GOLDEN+18",XXM: PORNBOX ALL BLACK X
http://ip96.uk:8080/shakeelmirza/4110440/291783
#EXTINF:-1 tvg-id="" tvg-name="XXM: PORNBOX ALL GROUP SEX" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="GOLDEN+18",XXM: PORNBOX ALL GROUP SEX
http://ip96.uk:8080/shakeelmirza/4110440/291784
#EXTINF:-1 tvg-id="" tvg-name="XXM: Pornbox Amateur Euro" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="GOLDEN+18",XXM: Pornbox Amateur Euro
http://ip96.uk:8080/shakeelmirza/4110440/291785
#EXTINF:-1 tvg-id="" tvg-name="XXM: Pornbox Amateurs Bigittygothgg" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="GOLDEN+18",XXM: Pornbox Amateurs Bigittygothgg
http://ip96.uk:8080/shakeelmirza/4110440/291786
#EXTINF:-1 tvg-id="" tvg-name="XXM: PORNBOX ANALIZED" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="GOLDEN+18",XXM: PORNBOX ANALIZED
http://ip96.uk:8080/shakeelmirza/4110440/291787
#EXTINF:-1 tvg-id="" tvg-name="XXM: PORNBOX BABES" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="GOLDEN+18",XXM: PORNBOX BABES
http://ip96.uk:8080/shakeelmirza/4110440/291788
#EXTINF:-1 tvg-id="" tvg-name="XXM: PORNBOX BANG BROS NETWORK" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="GOLDEN+18",XXM: PORNBOX BANG BROS NETWORK
http://ip96.uk:8080/shakeelmirza/4110440/291789
#EXTINF:-1 tvg-id="" tvg-name="XXM: PORNBOX BANG BROS NETWORK +1" tvg-logo="" group-title="GOLDEN+18",XXM: PORNBOX BANG BROS NETWORK +1
http://ip96.uk:8080/shakeelmirza/4110440/291790
#EXTINF:-1 tvg-id="" tvg-name="XXM: PORNBOX BANGBUS" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="GOLDEN+18",XXM: PORNBOX BANGBUS
http://ip96.uk:8080/shakeelmirza/4110440/291791
#EXTINF:-1 tvg-id="" tvg-name="XXM: Pornbox Biphoria" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="GOLDEN+18",XXM: Pornbox Biphoria
http://ip96.uk:8080/shakeelmirza/4110440/291792
#EXTINF:-1 tvg-id="" tvg-name="XXM: PORNBOX BLACKED" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="GOLDEN+18",XXM: PORNBOX BLACKED
http://ip96.uk:8080/shakeelmirza/4110440/291793
#EXTINF:-1 tvg-id="" tvg-name="XXM: PORNBOX BLOW ME POV" tvg-logo="http://s3.i3ns.net:2052/cs/etc/blank-icon.png" group-title="GOLDEN+18",XXM: PORNBOX BLOW ME POV
http://ip96.uk:8080/shakeelmirza/4110440/291794`);
}
